<?php
/*
Plugin Name: Voicer Core
*
Description: Some Voicer Core functions
Version: 1.0
Author: p-themes
Author URI: https://themeforest.net/user/p-themes/
 * Text Domain: theme-core
 * Domain Path: /languages/
*/

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
load_plugin_textdomain('theme-core', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

function rsgallery_vc_map_dependencies() {
	if ( ! defined( 'WPB_VC_VERSION' ) ) {
		$plugin_data = get_plugin_data(__FILE__);
        echo '
        <div class="updated">
          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>
        </div>';
	}
}
add_action( 'admin_notices', 'rsgallery_vc_map_dependencies' );

function rsgallery_vc_map_init() {
    $settings_gallery = array (
            'name'                    => esc_html__( 'Voicer Gallery', 'theme-core' ),
            'base'                    => 'voicer_gallery_element',
            'category'                => esc_html__( 'Voicer Elements', 'theme-core' ),
            'description'             => esc_html__( 'Different types of Gallery', 'theme-core' ),
            'show_settings_on_create' => false,
            'weight'                  => - 5,
            'html_template'           => dirname( __FILE__ ) . '/vc_templates/voicer_gallery_element.php',
            'admin_enqueue_js'        => preg_replace( '/\s/', '%20', plugins_url( 'assets/admin_enqueue_js.js', __FILE__ ) ),

        'admin_enqueue_css'       => preg_replace( '/\s/', '%20', plugins_url( 'assets/voicer_vc.css', __FILE__ ) ),

        'front_enqueue_js'        => preg_replace( '/\s/', '%20', plugins_url( 'assets/front_enqueue_js.js', __FILE__ ) ),
            'front_enqueue_css'       => preg_replace( '/\s/', '%20', plugins_url( 'assets/front_enqueue_css.css', __FILE__ ) ),
            'js_view'                 => 'ViewVoicerGalleryElement',

            'icon' => get_template_directory_uri().'/favicon.png',
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Widget title', 'theme-core' ),
                    'param_name' => 'title',
                    'description' => esc_html__( 'Enter text used as widget title (Note: located above content element).', 'theme-core' ),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'Gallery type', 'theme-core' ),
                    'param_name' => 'type',
                    'value' => array(
                        esc_html__( 'Image grid', 'theme-core' ) => 'image_grid',
                        esc_html__( 'Tabbed Image grid', 'theme-core' ) => 'image_tgrid',
                        esc_html__( 'Tabbed Music Image grid', 'theme-core' ) => 'image_tgrid_m',
                    ),
                    'description' => esc_html__( 'Select gallery type.', 'theme-core' ),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'Image source', 'theme-core' ),
                    'param_name' => 'source',
                    'value' => array(
                        esc_html__( 'Media library', 'theme-core' ) => 'media_library',
                        esc_html__( 'External links', 'theme-core' ) => 'external_link',
                    ),
                    'std' => 'media_library',
                    'description' => esc_html__( 'Select image source.', 'theme-core' ),
                ),
                array(
                    'type' => 'attach_images',
                    'heading' => esc_html__( 'Images', 'theme-core' ),
                    'param_name' => 'images',
                    'value' => '',
                    'description' => esc_html__( 'Select images from media library.', 'theme-core' ),
                    'dependency' => array(
                        'element' => 'source',
                        'value' => 'media_library',
                    ),
                ),
                array(
                    'type' => 'exploded_textarea_safe',
                    'heading' => esc_html__( 'External links', 'theme-core' ),
                    'param_name' => 'custom_srcs',
                    'description' => esc_html__( 'Enter external link for each gallery image (Note: divide links with linebreaks (Enter)).', 'theme-core' ),
                    'dependency' => array(
                        'element' => 'source',
                        'value' => 'external_link',
                    ),
                ),
                array(
                    'type' => 'exploded_textarea_safe',
                    'heading' => esc_html__( 'Titles of Tabs', 'theme-core' ),
                    'param_name' => 'custom_ttitles',
                    'description' => esc_html__( 'Enter title for each tab (Note: divide links with linebreaks (Enter)). Tab "All" is added automatically', 'theme-core' ),
                    'dependency' => array(
                        'element' => 'type',
                        'value' => array(
                            'image_tgrid',
                            'image_tgrid_m'
                        ),
                    ),
                ),
                array(
                    'type' => 'exploded_textarea_safe',
                    'heading' => esc_html__( 'Binding image with tab', 'theme-core' ),
                    'param_name' => 'image_bind',
                    'description' => esc_html__( 'Enter tab number to bind each image with some tab (Note: divide links with linebreaks (Enter)). Don\'t forget that bind numbers has to be the same as images number', 'theme-core' ),
                    'dependency' => array(
                        'element' => 'type',
                        'value' => array(
                            'image_tgrid',
                            'image_tgrid_m'
                        ),
                    ),
                ),
                array(
                    'type' => 'exploded_textarea_safe',
                    'heading' => esc_html__( 'Titles of images grids', 'theme-core' ),
                    'param_name' => 'custom_titles',
                    'description' => esc_html__( 'Enter title for each gallery image (Note: divide links with linebreaks (Enter)).', 'theme-core' ),
                ),
                array(
                    'type' => 'exploded_textarea_safe',
                    'heading' => esc_html__( 'Artists names for music tracks', 'theme-core' ),
                    'param_name' => 'artists',
                    'description' => esc_html__( 'Enter artists names of each music track (Note: divide links with linebreaks (Enter)).', 'theme-core' ),
                    'dependency' => array(
                        'element' => 'type',
                        'value' => array(
                            'image_tgrid_m'
                        ),
                    ),
                ),
                array(
                    'type' => 'exploded_textarea_safe',
                    'heading' => esc_html__( 'Urls of music tracks', 'theme-core' ),
                    'param_name' => 'track_urls',
                    'description' => esc_html__( 'Enter links to music tracks (Note: divide links with linebreaks (Enter)).', 'theme-core' ),
                    'dependency' => array(
                        'element' => 'type',
                        'value' => array(
                            'image_tgrid_m'
                        ),
                    ),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Image size', 'theme-core' ),
                    'param_name' => 'img_size',
                    'value' => 'thumbnail',
                    'description' => esc_html__( 'Enter image size. Example: thumbnail, medium, large, full or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use "thumbnail" size.', 'theme-core' ),
                    'dependency' => array(
                        'element' => 'source',
                        'value' => 'media_library',
                    ),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Image size', 'theme-core' ),
                    'param_name' => 'external_img_size',
                    'value' => '',
                    'description' => esc_html__( 'Enter image size in pixels. Example: 200x100 (Width x Height).', 'theme-core' ),
                    'dependency' => array(
                        'element' => 'source',
                        'value' => 'external_link',
                    ),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'On click action', 'theme-core' ),
                    'param_name' => 'onclick',
                    'value' => array(
                        esc_html__( 'None', 'theme-core' ) => '',
                        esc_html__( 'Link to large image', 'theme-core' ) => 'img_link_large',
                        esc_html__( 'Open in MagnificPopup Gallery', 'theme-core' ) => 'link_image',
                        esc_html__( 'Open custom link', 'theme-core' ) => 'custom_link',
                    ),
                    'description' => esc_html__( 'Select action for click action.', 'theme-core' ),
                    'std' => 'link_image',
                    'dependency' => array(
                        'element' => 'type',
                        'value' => array(
                            'flexslider_fade',
                            'flexslider_slide',
                            'image_grid',
                            'image_tgrid',
                        ),
                    ),

                ),
                array(
                    'type' => 'exploded_textarea_safe',
                    'heading' => esc_html__( 'Custom links', 'theme-core' ),
                    'param_name' => 'custom_links',
                    'description' => esc_html__( 'Enter links for each slide (Note: divide links with linebreaks (Enter)).', 'theme-core' ),
                    'dependency' => array(
                        'element' => 'onclick',
                        'value' => array( 'custom_link' ),
                    ),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'Custom link target', 'theme-core' ),
                    'param_name' => 'custom_links_target',
                    'description' => esc_html__( 'Select where to open  custom links.', 'theme-core' ),
                    'dependency' => array(
                        'element' => 'onclick',
                        'value' => array(
                            'custom_link',
                            'img_link_large',
                        ),
                    ),
                    'value' => vc_target_param_list(),
                ),
                array(
                    'type' => 'el_id',
                    'heading' => esc_html__( 'Element ID', 'theme-core' ),
                    'param_name' => 'el_id',
                    'description' => sprintf(wp_kses( __('Enter element ID (Note: make sure it is unique and valid according to <a href="%s" target="_blank">w3c specification</a>).', 'theme-core' ), array( 'span' => array('class' => true), 'a' => array('href' => true, 'target' => true))), 'http://www.w3schools.com/tags/att_global_id.asp'),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Extra class name', 'theme-core' ),
                    'param_name' => 'el_class',
                    'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'theme-core' ),
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__( 'CSS box', 'theme-core' ),
                    'param_name' => 'css',
                    'group' => esc_html__( 'Design Options', 'theme-core' ),
                ),
                array(
                    'type' => 'textarea_html',
                    'holder' => 'div',
                    'heading' => esc_html__( 'Custom HTML (will be located below image grids)', 'theme-core' ),
                    'param_name' => 'content',
                ),
            ),
    );
    vc_map( $settings_gallery );

    $settings_instagram = array (
        'name'                    => esc_html__( 'Voicer Instagram Widget', 'theme-core' ),
        'base'                    => 'voicer_instagram_element',
        'category'                => esc_html__( 'Voicer Elements', 'theme-core' ),
        'description'             => esc_html__( 'Instagram', 'theme-core' ),
        'show_settings_on_create' => false,
        'weight'                  => - 7,
        'html_template'           => dirname( __FILE__ ) . '/vc_templates/voicer_instagram_element.php',
        'admin_enqueue_js'        => preg_replace( '/\s/', '%20', plugins_url( 'assets/admin_enqueue_js.js', __FILE__ ) ),
        'admin_enqueue_css'       => preg_replace( '/\s/', '%20', plugins_url( 'assets/voicer_vc.css', __FILE__ ) ),

        'front_enqueue_js'        => preg_replace( '/\s/', '%20', plugins_url( 'assets/front_enqueue_js.js', __FILE__ ) ),
        'front_enqueue_css'       => preg_replace( '/\s/', '%20', plugins_url( 'assets/front_enqueue_css.css', __FILE__ ) ),
        'js_view'                 => 'ViewVoicerInstagramElement',
        'icon' => get_template_directory_uri().'/favicon.png',

        'params'                  => array(
            array(
                "type"        => "textfield",
                "heading"     => esc_html__( "Access token", 'theme-core' ),
                "param_name"  => "access_token",
                "value"  => "8334873284.661c303.3ef2f563e7884f528d2493122ba21311",
            ),

            array(
                "type"        => "textfield",
                "heading"     => esc_html__( "Limit of images in your widget", 'theme-core' ),
                "param_name"  => "limit",
                "value"  => "9",
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__( "Resolution", 'theme-core' ),
                "param_name"  => "resolution",
                "value"  => "low_resolution",
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__( "Sorting", 'theme-core' ),
                "param_name"  => "sort_by",
                "value"  => "most-recent",
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__( "User id", 'theme-core' ),
                "param_name"  => "user_id",
                "value"  => "self",
            ),
            array(
                'type' => 'el_id',
                'heading' => esc_html__( 'Element ID', 'theme-core' ),
                'param_name' => 'el_id',
                'description' => sprintf(wp_kses( __('Enter element ID (Note: make sure it is unique and valid according to <a href="%s" target="_blank">w3c specification</a>).', 'theme-core' ), array( 'span' => array('class' => true), 'a' => array('href' => true, 'target' => true))), 'http://www.w3schools.com/tags/att_global_id.asp'),
                'value' => 'instafeed'
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Outer wrapper block class name', 'theme-core' ),
                'param_name' => 'el_class',
                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'theme-core' ),
                'value' => 'instagram-grid-full'
            ),
        )
    );
    vc_map($settings_instagram);

    $settings_twitter = array (
        'name'                    => esc_html__( 'Voicer Twitter Widget', 'theme-core' ),
        'base'                    => 'voicer_twitter_element',
        'category'                => esc_html__( 'Voicer Elements', 'theme-core' ),
        'description'             => esc_html__( 'Voicer Twitter Widget', 'theme-core' ),
        'show_settings_on_create' => false,
        'weight'                  => - 6,
        'html_template'           => dirname( __FILE__ ) . '/vc_templates/voicer_twitter_element.php',
        'admin_enqueue_css'       => preg_replace( '/\s/', '%20', plugins_url( 'assets/voicer_vc.css', __FILE__ ) ),

        'admin_enqueue_js'        => preg_replace( '/\s/', '%20', plugins_url( 'assets/admin_enqueue_js.js', __FILE__ ) ),
        'front_enqueue_js'        => preg_replace( '/\s/', '%20', plugins_url( 'assets/front_enqueue_js.js', __FILE__ ) ),
        'front_enqueue_css'       => preg_replace( '/\s/', '%20', plugins_url( 'assets/front_enqueue_css.css', __FILE__ ) ),
        'js_view'                 => 'ViewVoicerTwitterElement',
        'icon' => get_template_directory_uri().'/favicon.png',

        'params'                  => array(
            array(
                "type"        => "textfield",
                "heading"     => esc_html__( "Twitter Account", 'theme-core' ),
                "param_name"  => "twitter_account",
                "value"       => "envato",
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__( "Limit of posts in your widget", 'theme-core' ),
                "param_name"  => "limit",
                "value"       => "1",
            ),
            array(
                'type' => 'el_id',
                'heading' => esc_html__( 'Element ID', 'theme-core' ),
                'param_name' => 'el_id',
                'description' => sprintf(wp_kses( __('Enter element ID (Note: make sure it is unique and valid according to <a href="%s" target="_blank">w3c specification</a>).', 'theme-core' ), array( 'span' => array('class' => true), 'a' => array('href' => true, 'target' => true))), 'http://www.w3schools.com/tags/att_global_id.asp'),
                'value' => 'twitter'
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Outer wrapper block class name', 'theme-core' ),
                'param_name' => 'el_class',
                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'theme-core' ),
                'value' => 'text-center social-wrap'
            ),
        )
    );
    vc_map($settings_twitter);

    $settings_facebook = array (
        'name'                    => esc_html__( 'Voicer Facebook Widget', 'theme-core' ),
        'base'                    => 'voicer_facebook_element',
        'category'                => esc_html__( 'Voicer Elements', 'theme-core' ),
        'description'             => esc_html__( 'Voicer Facebook widget', 'theme-core' ),
        'show_settings_on_create' => false,
        'weight'                  => - 5,
        'html_template'           => dirname( __FILE__ ) . '/vc_templates/voicer_facebook_element.php',
        'admin_enqueue_js'        => preg_replace( '/\s/', '%20', plugins_url( 'assets/admin_enqueue_js.js', __FILE__ ) ),
        'admin_enqueue_css'       => preg_replace( '/\s/', '%20', plugins_url( 'assets/voicer_vc.css', __FILE__ ) ),

        'front_enqueue_js'        => preg_replace( '/\s/', '%20', plugins_url( 'assets/front_enqueue_js.js', __FILE__ ) ),
        'front_enqueue_css'       => preg_replace( '/\s/', '%20', plugins_url( 'assets/front_enqueue_css.css', __FILE__ ) ),
        'js_view'                 => 'ViewVoicerFacebookElement',
        'icon' => get_template_directory_uri().'/favicon.png',

        'params'                  => array(
            array(
                "type"        => "textfield",
                "heading"     => esc_html__( "Facebook Account Name", 'theme-core' ),
                'description' => esc_html__( 'The only name of the Facebook Page, i.e. envato etc.', 'theme-core' ),
                "param_name"  => "facebook_account",
                "value"  => "envato",
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__( "Width", 'theme-core' ),
                'description' => esc_html__( 'The pixel width of the plugin. Min. is 180 & Max. is 500', 'theme-core' ),
                "param_name"  => "width",
                "value"  => "340",
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__( "Height", 'theme-core' ),
                'description' => esc_html__( 'The pixel height of the plugin. Min. is 70', 'theme-core' ),
                "param_name"  => "height",
                "value"  => "360",
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__( "Tabs", 'theme-core' ),
                'description' => esc_html__( 'Tabs to render i.e. timeline, events, messages. Use a comma-separated list to add multiple tabs, i.e. timeline, events.', 'theme-core' ),
                "param_name"  => "tabs",
                "value"  => "timeline",
            ),
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__( "Hide cover photo in the header", 'theme-core' ),
                "param_name"  => "hide_cover",
                'value' => array(
                    esc_html__( 'True', 'theme-core' ) => 'true',
                    esc_html__( 'False', 'theme-core' ) => 'false',
                ),
                'std' => 'false',
            ),

            array(
                "type"        => "dropdown",
                "heading"     => esc_html__( "Show profile photos when friends like this", 'theme-core' ),
                "param_name"  => "show_facepile",
                'value' => array(
                    esc_html__( 'True', 'theme-core' ) => 'true',
                    esc_html__( 'False', 'theme-core' ) => 'false',
                ),
                'std' => 'true',
            ),
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__( "Use the small header instead", 'theme-core' ),
                "param_name"  => "small_header",
                'value' => array(
                    esc_html__( 'True', 'theme-core' ) => 'true',
                    esc_html__( 'False', 'theme-core' ) => 'false',
                ),
                'std' => 'true',
            ),
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__( "Try to fit inside the container width", 'theme-core' ),
                "param_name"  => "adapt_container_width",
                'value' => array(
                    esc_html__( 'True', 'theme-core' ) => 'true',
                    esc_html__( 'False', 'theme-core' ) => 'false',
                ),
                'std' => 'true',
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Outer wrapper block class name', 'theme-core' ),
                'param_name' => 'el_class',
                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'theme-core' ),
                'value' => 'text-center social-wrap'
            ),

        )
    );
    vc_map($settings_facebook);

    $settings_rslider = array (
        'name'                    => esc_html__( 'Voicer Main Slider', 'theme-core' ),
        'base'                    => 'voicer_rslider_element',
        'category'                => esc_html__( 'Voicer Elements', 'theme-core' ),
        'description'             => esc_html__( 'Voicer Main Slider', 'theme-core' ),
        'show_settings_on_create' => false,
        'weight'                  => 0,
        'html_template'           => dirname( __FILE__ ) . '/vc_templates/voicer_rslider_element.php',
        'admin_enqueue_js'        => preg_replace( '/\s/', '%20', plugins_url( 'assets/admin_enqueue_js.js', __FILE__ ) ),
        'admin_enqueue_css'       => preg_replace( '/\s/', '%20', plugins_url( 'assets/admin_enqueue_css.css', __FILE__ ) ),

        'front_enqueue_js'        => preg_replace( '/\s/', '%20', plugins_url( 'assets/front_enqueue_js.js', __FILE__ ) ),
        'front_enqueue_css'       => preg_replace( '/\s/', '%20', plugins_url( 'assets/front_enqueue_css.css', __FILE__ ) ),
        'js_view'                 => 'ViewVoicerRsliderElement',

        'icon' => get_template_directory_uri().'/favicon.png',
        'params'                  => array(
            array(
                "type"        => "textfield",
                "heading"     => esc_html__( "Number of slides (integer: 1, 2, 3 etc)", 'theme-core' ),
                "param_name"  => "rs_num",
                "value"  => "2",
            ),
            array(
                'type' => 'attach_images',
                'heading' => esc_html__( 'Images', 'theme-core' ),
                'param_name' => 'rs_images',
                'description' => esc_html__( 'Select images from media library.', 'theme-core' ),
            ),

            array(
                'type' => 'textarea_html',
                'holder' => 'div',
                'admin_label' => false,
                'heading' => esc_html__('Content for all Slide', 'theme-core' ),
                'param_name' => 'content',
                'description' => wp_kses( __('<span style="color:red;font-weight:bold">IMPORTANT!!!</span> Separate your slides content with word <span style="font-style:initial;font-weight:bold;">{slide}</span>. <a href="http://websmirno.site/wp/studio/documentation/code-examples/main_slider.html" target="_blank">Example slides code</a>', 'theme-core' ), array( 'span' => array('style' => true), 'a' => array('href' => true, 'target' => true))),
                'value' => '',
            ),
            array(
                'type' => 'el_id',
                'heading' => esc_html__( 'Element ID', 'theme-core' ),
                'param_name' => 'el_id',
                'description' => sprintf(wp_kses( __('Enter element ID (Note: make sure it is unique and valid according to <a href="%s" target="_blank">w3c specification</a>).', 'theme-core' ), array( 'span' => array('class' => true), 'a' => array('href' => true, 'target' => true))), 'http://www.w3schools.com/tags/att_global_id.asp'),
                'value' => 'mainSlider'
            ),

            array(
                "type"        => "dropdown",
                "heading"     => esc_html__( "Display arrows for Desktop", 'theme-core' ),
                "param_name"  => "arrows",
                'value' => array(
                    esc_html__( 'Display', 'theme-core' ) => 'true',
                    esc_html__( 'Hide', 'theme-core' ) => 'false',
                ),
                'std' => 'true',
            ),
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__( "Display dots for Desktop", 'theme-core' ),
                "param_name"  => "dots",
                'value' => array(
                    esc_html__( 'Display', 'theme-core' ) => 'true',
                    esc_html__( 'Hide', 'theme-core' ) => 'false',
                ),
                'std' => 'true',
            ),
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__( "Autoplay of slides", 'theme-core' ),
                "param_name"  => "autoplay",
                'value' => array(
                    esc_html__( 'Autoplay', 'theme-core' ) => 'true',
                    esc_html__( 'Manual changing', 'theme-core' ) => 'false',
                ),
                'std' => 'true',
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__( "Speed of autoplay slides rotating", 'theme-core' ),
                "param_name"  => "autoplayspeed",
                "value"  => "7000",

                'dependency' => array(
                    'element' => 'autoplay',
                    'value' => 'true',
                ),
            ),
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__( "Fade effect of slides rotating", 'theme-core' ),
                "param_name"  => "fade",
                'value' => array(
                    esc_html__( 'Faded', 'theme-core' ) => 'true',
                    esc_html__( 'Not faded', 'theme-core' ) => 'false',
                ),
                'std' => 'true',
            ),


            array(
                "type"        => "textfield",
                "heading"     => esc_html__( "Speed of slides rotating", 'theme-core' ),
                "param_name"  => "speed",
                "value"  => "1000",
            ),









        )
    );
    vc_map($settings_rslider);


    if ( class_exists( "WPBakeryShortCode" ) ) {
        class WPBakeryShortCode_Voicer_Gallery_Element extends WPBakeryShortCode {
            public function __construct( $settings ) {
                parent::__construct( $settings );
                $this->jsCssScripts();
            }
            public function vcLoadIframeJsCss() {
                wp_enqueue_style( 'voicer_gallery_element_iframe' );
            }
            public function contentInline( $atts, $content ) {
                $this->vcLoadIframeJsCss();
            }
            public function jsCssScripts() {
                wp_register_style( 'voicer_gallery_element_iframe', plugins_url( 'assets/front_enqueue_iframe_css.css', __FILE__ ) );
            }
            public function checkBool( $in ) {
                if ( strlen( $in ) > 0 && in_array( strtolower( $in ), array(
                    "yes",
                    "true",
                    "1",
                    1
                ) )
                ) {
                    return true;
                }
                return false;
            }
        }
        class WPBakeryShortCode_Voicer_Instagram_Element extends WPBakeryShortCode {
            public function __construct( $settings ) {
                parent::__construct( $settings );
                $this->jsCssScripts();
            }
            public function vcLoadIframeJsCss() {
                wp_enqueue_style( 'voicer_gallery_element_iframe' );
                wp_enqueue_script('rtext_element_inst');
                wp_enqueue_script('voicer_gallery_element_scr');
            }
            public function contentInline( $atts, $content ) {
                $this->vcLoadIframeJsCss();
            }
            public function jsCssScripts() {
                wp_register_script('rtext_element_inst', plugins_url( 'assets/instafeed.min.js', __FILE__ ), array( 'jquery' ), false );
                wp_register_script('voicer_gallery_element_scr', plugins_url( 'assets/voicer_gallery_element.js', __FILE__ ), array( 'jquery' ), false );
                wp_register_style('voicer_gallery_element_iframe', plugins_url( 'assets/front_enqueue_iframe_css.css', __FILE__ ) );
            }
            public function checkBool( $in ) {
                if ( strlen( $in ) > 0 && in_array( strtolower( $in ), array(
                    "yes",
                    "true",
                    "1",
                    1
                ) )
                ) {
                    return true;
                }
                return false;
            }
        }
        class WPBakeryShortCode_Voicer_Twitter_element extends WPBakeryShortCode {
            public function __construct( $settings ) {
                parent::__construct( $settings );
                $this->jsCssScripts();
            }
            public function vcLoadIframeJsCss() {
                wp_enqueue_style( 'voicer_gallery_element_iframe' );
            }
            public function contentInline( $atts, $content ) {
                $this->vcLoadIframeJsCss();
            }
            public function jsCssScripts() {
                wp_register_style( 'voicer_gallery_element_iframe', plugins_url( 'assets/front_enqueue_iframe_css.css', __FILE__ ) );
            }
            public function checkBool( $in ) {
                if ( strlen( $in ) > 0 && in_array( strtolower( $in ), array(
                    "yes",
                    "true",
                    "1",
                    1
                ) )
                ) {
                    return true;
                }
                return false;
            }
        }
        class WPBakeryShortCode_Voicer_Facebook_Element extends WPBakeryShortCode {
            public function __construct( $settings ) {
                parent::__construct( $settings );
                $this->jsCssScripts();
            }
            public function vcLoadIframeJsCss() {
                wp_enqueue_style( 'voicer_gallery_element_iframe' );
            }
            public function contentInline( $atts, $content ) {
                $this->vcLoadIframeJsCss();
            }
            public function jsCssScripts() {
                wp_register_style( 'voicer_gallery_element_iframe', plugins_url( 'assets/front_enqueue_iframe_css.css', __FILE__ ) );
            }
            public function checkBool( $in ) {
                if ( strlen( $in ) > 0 && in_array( strtolower( $in ), array(
                    "yes",
                    "true",
                    "1",
                    1
                ) )
                ) {
                    return true;
                }
                return false;
            }
        }
        class WPBakeryShortCode_Voicer_Rslider_Element extends WPBakeryShortCode {
            public function __construct( $settings ) {
                parent::__construct( $settings );
                $this->jsCssScripts();
            }
            public function vcLoadIframeJsCss() {
                wp_enqueue_style( 'voicer_gallery_element_iframe' );
                wp_enqueue_script('voicer-rslider-element');
            }
            public function contentInline( $atts, $content ) {
                $this->vcLoadIframeJsCss();
            }
            public function jsCssScripts() {
                wp_register_script( 'voicer-rslider-element', plugins_url( 'assets/voicer_rslider_element.js', __FILE__ ), array( 'jquery' ), false );
                wp_register_style( 'voicer_gallery_element_iframe', plugins_url( 'assets/front_enqueue_iframe_css.css', __FILE__ ) );
            }
            public function checkBool( $in ) {
                if ( strlen( $in ) > 0 && in_array( strtolower( $in ), array(
                    "yes",
                    "true",
                    "1",
                    1
                ) )
                ) {
                    return true;
                }
                return false;
            }
        }
    }
}
add_action('vc_after_init', 'rsgallery_vc_map_init');



function voicer_add_menu_widgets() {
    $voicer_menu_items = array(
        1 => array(
            "tt-title" =>esc_html__('Home','voicer-layout'),
            "tt-classes" =>"tt-home",
            "tt-url" =>"/",
            "tt-item-position" => 1
        ),
        4 => array(
            "tt-title" =>esc_html__( 'Projects','voicer-layout'),
            "tt-classes" =>"tt-projects",
            "tt-url" =>"/projects/",
            "tt-item-position" => 3

        ),
        5 => array(
            "tt-title" =>esc_html__( 'Services','voicer-layout'),
            "tt-classes" =>"tt-services",
            "tt-url" =>"/services/",
            "tt-item-position" => 4

        ),
        6 => array(
            "tt-title" =>esc_html__( 'Testimonials','voicer-layout'),
            "tt-classes" =>"tt-testimonials",
            "tt-url" =>"/testimonials/",
            "tt-item-position" => 6

        ),
        8 => array(
            "tt-title" =>esc_html__( 'Rates','voicer-layout'),
            "tt-classes" =>"tt-rates",
            "tt-url" =>"/rates/",
            "tt-item-position" => 6

        ),
        9 => array(
            "tt-title" =>esc_html__( 'Gallery','voicer-layout'),
            "tt-classes" =>"tt-gallery",
            "tt-url" =>"/gallery/",
            "tt-item-position" => 8
        ),
        10 => array(
            "tt-title" =>esc_html__( 'Shop','voicer-layout'),
            "tt-classes" =>"tt-shop",
            "tt-url" =>"/shop/",
            "tt-item-position" => 9
        ),
        11 => array(
            "tt-title" =>esc_html__( 'Contact','voicer-layout'),
            "tt-classes" =>"tt-contact",
            "tt-url" =>"/contact-us/",
            "tt-item-position" => 10
        ),
        12 => array(
            "tt-title" =>esc_html__( 'My Account','voicer-layout'),
            "tt-classes" =>"tt-account",
            "tt-url" =>"/my-account/",
            "tt-item-position" => 11
        )

    );

    $menu_exists = wp_get_nav_menu_object(esc_html__('Theme Footer Menu','voicer-layout'));

    if( !$menu_exists){
        $menu_id = wp_create_nav_menu(esc_html__('Theme Footer Menu','voicer-layout'));

        foreach ($voicer_menu_items as $tt_menu_item) :
            $menu_item_title = $tt_menu_item['tt-title'];
            $menu_item_classes = $tt_menu_item['tt-classes'];
            $menu_item_url = $tt_menu_item['tt-url'];
            $menu_item_pos = $tt_menu_item['tt-item-position'];

            if ($menu_item_title != 'Shop' && $menu_item_title != 'Testimonials') :
                wp_update_nav_menu_item($menu_id, 0, array(
                        'menu-item-title' =>  $menu_item_title,
                        'menu-item-classes' => $menu_item_classes,
                        'menu-item-url' => home_url($menu_item_url),
                        'menu-item-status' => 'publish',
                        'menu-item-position' => $menu_item_pos
                    )
                );
            endif;
        endforeach;
        wp_update_nav_menu_item($menu_id, 0, array(
                'menu-item-title' =>  esc_html__('Blog','voicer-layout'),
                'menu-item-classes' => 'tt-blog',
                'menu-item-url' => home_url('/blog-page/'),
                'menu-item-status' => 'publish',
                'menu-item-position' => 7
            )
        );
    }

    $menu_name = 'Theme Header Menu';
    $menu_exists = wp_get_nav_menu_object($menu_name);

    if (!$menu_exists){
        $menu_id = wp_create_nav_menu($menu_name);
        foreach ($voicer_menu_items as $tt_menu_item) :
            $menu_item_title = $tt_menu_item['tt-title'];
            $menu_item_classes = $tt_menu_item['tt-classes'];
            $menu_link = home_url($tt_menu_item['tt-url']);
            $menu_item_position = $tt_menu_item['tt-item-position'];


            if ($menu_item_title != 'My Account') :
                wp_update_nav_menu_item($menu_id, 0, array(
                        'menu-item-title' =>  $menu_item_title,
                        'menu-item-classes' => $menu_item_classes,
                        'menu-item-url' => $menu_link,
                        'menu-item-status' => 'publish',
                        'menu-item-position' => $menu_item_position
                    )
                );
            endif;


        endforeach;
        $parent_item = wp_update_nav_menu_item($menu_id, 0, array(
                'menu-item-title' =>  esc_html__('Blog','voicer-layout'),
                'menu-item-classes' => 'tt-blog',
                'menu-item-url' => home_url('/blog-page/'),
                'menu-item-status' => 'publish',
                'menu-item-position' => 7
            )
        );
        wp_update_nav_menu_item($menu_id, 0, array(
                'menu-item-title' =>  esc_html__('Blog','voicer-layout'),
                'menu-item-url' => home_url( '/blog-page/' ),
                'menu-item-position' => 1,
                'menu-item-status' => 'publish',
                'menu-item-parent-id' => $parent_item
            )
        );
        wp_update_nav_menu_item($menu_id, 0, array(
                'menu-item-title' => esc_html__('Blog single post','voicer-layout'),
                'menu-item-url' => home_url( '/the-voicer-in-la-times/' ),
                'menu-item-position' => 2,
                'menu-item-status' => 'publish',
                'menu-item-parent-id' => $parent_item
            )
        );





        $parent_item_about = wp_update_nav_menu_item($menu_id, 0, array(
                'menu-item-title' =>  esc_html__('About','voicer-layout'),
                'menu-item-classes' => 'tt-about',
                'menu-item-url' => home_url('/about-us/'),
                'menu-item-status' => 'publish',
                'menu-item-position' => 2
            )
        );
        wp_update_nav_menu_item($menu_id, 0, array(
                'menu-item-title' =>  esc_html__('Equipment','voicer-layout'),
                'menu-item-url' => home_url( '/equipment/' ),
                'menu-item-classes' => 'tt-equipment',
                'menu-item-position' => 1,
                'menu-item-status' => 'publish',
                'menu-item-parent-id' => $parent_item_about
            )
        );



    }

    $menu_header = get_term_by('name', 'Theme Footer Menu', 'nav_menu');
    $menu_header_id = $menu_header->term_id;

    if ($menu_header_id == 0) {
        $menu_header_id = wp_create_nav_menu('Theme Footer Menu');
    }
    $locations = get_theme_mod('nav_menu_locations');
    $locations['voicer_footer_menu'] = $menu_header_id;
    set_theme_mod( 'nav_menu_locations', $locations );
    $menu_header = get_term_by('name', 'Theme Header Menu', 'nav_menu');
    $menu_header_id = $menu_header->term_id;
    if ($menu_header_id == 0) {
        $menu_header_id = wp_create_nav_menu('Theme Header Menu');
    }
    $locations = get_theme_mod('nav_menu_locations');
    $locations['voicer_header_navigation'] = $menu_header_id;
    set_theme_mod( 'nav_menu_locations', $locations );



    update_option('woocommerce_thumbnail_cropping', 'uncropped');
    update_option( 'woocommerce_catalog_columns', '3' );

    global $wp_rewrite;
    $wp_rewrite->set_permalink_structure('/%postname%/');

    update_option( 'date_format', 'j M, Y');
    update_option( 'posts_per_page', 6);
    update_option( '_wp_http_referer', '/%postname%/');




}

register_activation_hook( __FILE__, 'voicer_add_menu_widgets' );


function voicer_categories($atts,$echo = false) {
    $atts = shortcode_atts( array('show_count' => 1), $atts, 'voicer_categories' );
    $show_count = "{$atts['show_count']}";
    $args = array(
        'orderby' => 'id',
        'show_count' => $show_count,
        'title_li' => '',
        'echo'   => 0,
        'use_desc_for_title' => 1,
        'exclude' => 1
    );
    return '<ul class="category-list">'.wp_list_categories($args).'</ul>';
}
function voicer_featured_posts($atts){
    $widget_title = esc_html__( 'Recent Posts', 'voicer' );
    $atts = shortcode_atts( array('qty' => 2), $atts, 'voicer_featured_posts' );
    $posts_per_page = "{$atts['qty']}";
    $args = array(
        'posts_per_page' => $posts_per_page,
        'meta_key' => 'tt_post_state',
        'meta_query' => array(
            array(
                'key' => 'tt_post_state',
                'value' => 'true',
                'compare' => '=',
            )
        )
    );
    $featured = new WP_Query($args);
    echo '<div class="side-block"><h4>' . esc_html($widget_title). '</h4>';
    if ($featured->have_posts()) {
        while ($featured->have_posts()):
            $featured->the_post();
            echo '<div class="blog-post post-preview post-featured">';
            if (has_post_thumbnail()) :
                echo '<div class="post-image">';
                echo '<a href="'; the_permalink();  echo '">';  the_post_thumbnail(); echo '</a>';
                echo '</div>';
            endif;
            echo '<div class="post-info"><ul class="post-meta">';
            echo '<li class="post-meta-date">'.do_shortcode('[voicer_icon icon="icon-time"]'); echo get_the_date('m.d.Y'); echo '</li>';
            echo '</ul>';
            echo '<h4 class="post-title">';
            echo '<a href="'; the_permalink();  echo '">';  the_title(); echo '</a>';
            echo '</h4></div>';
            echo '</div>';
        endwhile;
        echo '</div> ';
    } else {
        esc_html_e('Set post(s) as "Featured" to see block ','voicer');
    }
    wp_reset_query();
}
function voicer_tagcloud($atts,$echo = false) {
    if (function_exists('wp_tag_cloud'))
        $atts = shortcode_atts( array('taxonomy' => 'post_tag'), $atts, 'voicer_tagcloud' );
    $taxonomy = "{$atts['taxonomy']}";
    $args = array(
        'smallest'                  => 15,
        'largest'                   => 22,
        'unit'                      => 'px',
        'number'                    => 45,
        'format'                    => 'list',
        'separator'                 => "\n",
        'orderby'                   => 'name',
        'order'                     => 'ASC',
        'exclude'                   => null,
        'link'                      => 'view',
        'taxonomy'                  => $taxonomy,
        'echo'                      => false,
        'child_of'                  => null,
    );
    return wp_tag_cloud( $args );
}

function voicer_backend_html($object) {
    wp_nonce_field(basename(__FILE__), "meta-box-nonce");
    ?>
<div style="overflow:hidden;">
    <div class="post-attributes-label-wrapper" style="width:30%;float:left">
        <label class="post-attributes-label" for="tt_block_css"><?php esc_html_e('Outer CSS class for block', 'voicer' ); ?></label>
        <p class="howto" id="tt_block_css"><?php esc_html_e('Left css class "block"', 'voicer' ); ?></p>
    </div>
    <div style="width:65%;float:left">
        <input name="tt_block_css" type="text" style="width:100%" value="<?php echo esc_attr(get_post_meta($object->ID, "tt_block_css", true)); ?>">
    </div>
</div>
<hr>
<div style="overflow:hidden;">
    <div class="post-attributes-label-wrapper" style="width:30%;float:left">
        <label class="post-attributes-label" for="tt_title_state"><?php esc_html_e('Not display title from admin field "Title"', 'voicer' ); ?></label>
    </div>
    <div style="width:65%;float:left">
        <?php
        $checkbox_value = esc_attr(get_post_meta($object->ID, "tt_title_state", true));
        if ($checkbox_value) {
            ?>
            <input name="tt_title_state" type="checkbox" value="true" checked>
            <?php
        } else {
            ?>
            <input name="tt_title_state" type="checkbox" value="true">
            <?php  }
        ?>
    </div>
</div>
<hr>
<div style="overflow:hidden;">
    <div class="post-attributes-label-wrapper" style="width:30%;float:left">
        <label class="post-attributes-label" for="tt_title_class_outer"><?php esc_html_e('Outer CSS class for title block', 'voicer' ); ?></label>
    </div>
    <div style="width:65%;float:left">
        <input name="tt_title_class_outer" type="text" style="width:100%" value="<?php echo esc_attr(get_post_meta($object->ID, "tt_title_class_outer", true)); ?>">
    </div>
</div>
<hr>
<div style="overflow:hidden;">
    <div class="post-attributes-label-wrapper" style="width:30%;float:left">
        <label class="post-attributes-label" for="tt_title_class"><?php esc_html_e('CSS class for title tag', 'voicer' ); ?></label>
    </div>
    <div style="width:65%;float:left">
        <input name="tt_title_class" type="text" style="width:100%" value="<?php echo esc_attr(get_post_meta($object->ID, "tt_title_class", true)); ?>">
    </div>
</div>
<hr>
<p class="post-attributes-label-wrapper"><label class="post-attributes-label" for="tt_promo_content"><?php esc_html_e('Page Promo Content', 'voicer' ); ?></label></p>
<p><?php wp_editor(get_post_meta($object->ID, "tt_promo_content", true), 'tt_promo_content' ); ?></p>
<p class="howto" id="tt_promo_content"><?php esc_html_e('Comes after page title (you may left it empty)', 'voicer' ); ?></p>
<?php
}
function voicer_add_mbox(){
    add_meta_box("demo-mbox", "Page Format Options", "voicer_backend_html", "page", "normal", "high", null);
}
add_action("add_meta_boxes", "voicer_add_mbox");


function voicer_backend_save_mbox($post_id, $post, $update) {
    if (!isset($_POST["meta-box-nonce"]) || !wp_verify_nonce($_POST["meta-box-nonce"], basename(__FILE__)))
        return $post_id;
    if (!current_user_can("edit_post", $post_id))
        return $post_id;
    if (defined("DOING_AUTOSAVE") && DOING_AUTOSAVE)
        return $post_id;
    $slug = "page";
    if ($slug != $post->post_type)
        return $post_id;
    $tt_block_css = "";
    $tt_title_class_outer = "";
    $tt_title_class = "";
    $tt_title_state = "";
    $tt_promo_content = "";

    if (isset($_POST["tt_block_css"])) {$tt_block_css = sanitize_text_field($_POST["tt_block_css"]);}
    update_post_meta($post_id, "tt_block_css", $tt_block_css);

    if (isset($_POST["tt_title_class_outer"])) {$tt_title_class_outer = sanitize_text_field($_POST["tt_title_class_outer"]);}
    update_post_meta($post_id, "tt_title_class_outer", $tt_title_class_outer);

    if (isset($_POST["tt_title_class"])) {$tt_title_class = sanitize_text_field($_POST["tt_title_class"]);}
    update_post_meta($post_id, "tt_title_class", $tt_title_class);

    if (isset($_POST["tt_title_state"])) {$tt_title_state = sanitize_text_field($_POST["tt_title_state"]);}
    update_post_meta($post_id, "tt_title_state", $tt_title_state);

    if (isset($_POST["tt_promo_content"])) {$tt_promo_content = wp_kses($_POST["tt_promo_content"] , voicer_tags());}
    update_post_meta($post_id, "tt_promo_content", $tt_promo_content);
}
add_action("save_post", "voicer_backend_save_mbox", 10, 3);


function voicer_backend_add_to_post($object) {
    wp_nonce_field(basename(__FILE__), "meta-box-nonce");
    ?>
<hr>
<p class="post-attributes-label-wrapper"><label class="post-attributes-label" for="tt_post_add_content"><?php esc_html_e('Post Additional Content', 'voicer' ); ?></label></p>
<p><?php wp_editor(get_post_meta($object->ID, "tt_post_add_content", true), 'tt_post_add_content' ); ?></p>
<p class="howto" id="tt_post_add_content"><?php esc_html_e('Comes on Blog Posts Page (you may enter gallery shortcode, iframes etc.)', 'voicer' ); ?></p>
<hr>
<div style="overflow:hidden;">
    <div class="post-attributes-label-wrapper" style="width:30%;float:left">
        <label class="post-attributes-label" for="tt_post_state"><?php esc_html_e('Featured this post', 'voicer' ); ?></label>
    </div>
    <div style="width:65%;float:left">
        <?php
        $checkbox_value = esc_attr(get_post_meta($object->ID, "tt_post_state", true));
        if ($checkbox_value == "") : ?>
            <input name="tt_post_state" type="checkbox" value="true">
            <?php  elseif ($checkbox_value == "true"): ?>
            <input name="tt_post_state" type="checkbox" value="true" checked>
            <?php endif;  ?>
    </div>
</div>
<hr>
<div style="overflow:hidden;">
    <div class="post-attributes-label-wrapper" style="width:30%;float:left">
        <label class="post-attributes-label" for="tt_post_fstate"><?php esc_html_e('Disable Featured Image in Blog Posts Page', 'voicer' ); ?></label>
    </div>
    <div style="width:65%;float:left">
        <?php
        $checkbox_value = esc_attr(get_post_meta($object->ID, "tt_post_fstate", true));
        if ($checkbox_value == "") : ?>
            <input name="tt_post_fstate" type="checkbox" value="true">
            <?php  elseif ($checkbox_value == "true"): ?>
            <input name="tt_post_fstate" type="checkbox" value="true" checked>
            <?php endif;  ?>
    </div>
</div>
<hr>
<div style="overflow:hidden;">
    <div class="post-attributes-label-wrapper" style="width:30%;float:left">
        <label class="post-attributes-label" for="tt_post_s_fstate"><?php esc_html_e('Disable Featured Image in Single Post', 'voicer' ); ?></label>
    </div>
    <div style="width:65%;float:left">
        <?php
        $checkbox_value = esc_attr(get_post_meta($object->ID, "tt_post_s_fstate", true));
        if ($checkbox_value == "") : ?>
            <input name="tt_post_s_fstate" type="checkbox" value="true">
            <?php  elseif ($checkbox_value == "true"): ?>
            <input name="tt_post_s_fstate" type="checkbox" value="true" checked>
            <?php endif;  ?>
    </div>
</div>
<hr>
<div style="overflow:hidden;">
    <div class="post-attributes-label-wrapper" style="width:30%;float:left">
        <label class="post-attributes-label" for="voicer_add_content"><?php esc_html_e('Disable Post Additional Content in Blog Pages', 'voicer' ); ?></label>
    </div>
    <div style="width:65%;float:left">
        <?php
        $checkbox_value = esc_attr(get_post_meta($object->ID, "voicer_add_content", true));
        if ($checkbox_value == "") : ?>
            <input name="voicer_add_content" type="checkbox" value="true">
            <?php  elseif ($checkbox_value == "true"): ?>
            <input name="voicer_add_content" type="checkbox" value="true" checked>
            <?php endif;  ?>
    </div>
</div>

<?php
}
function voicer_full_insert(){
    add_meta_box("demo-mbox", "Post Format Options", "voicer_backend_add_to_post", "post", "normal", "high", null);
}
add_action("add_meta_boxes", "voicer_full_insert");


function voicer_front_save_mbox($post_id, $post, $update) {
    if (!isset($_POST["meta-box-nonce"]) || !wp_verify_nonce($_POST["meta-box-nonce"], basename(__FILE__)))
        return $post_id;
    if (!current_user_can("edit_post", $post_id))
        return $post_id;
    if (defined("DOING_AUTOSAVE") && DOING_AUTOSAVE)
        return $post_id;
    $slug = "post";
    if ($slug != $post->post_type)
        return $post_id;

    $tt_post_add_content = "";
    $tt_post_state = "";
    $tt_post_fstate = "";
    $tt_post_s_fstate = "";
    $voicer_add_content = "";

    if(isset($_POST["tt_post_add_content"])) {
        $tt_post_add_content = wp_kses($_POST["tt_post_add_content"], voicer_tags());
    }
    update_post_meta($post_id, "tt_post_add_content", $tt_post_add_content);

    if (isset($_POST["tt_post_state"])) {$tt_post_state = sanitize_text_field($_POST["tt_post_state"]);}
    update_post_meta($post_id, "tt_post_state", $tt_post_state);

    if (isset($_POST["tt_post_fstate"])) {$tt_post_fstate = sanitize_text_field($_POST["tt_post_fstate"]);}
    update_post_meta($post_id, "tt_post_fstate", $tt_post_fstate);

    if (isset($_POST["voicer_add_content"])) {$voicer_add_content = sanitize_text_field($_POST["voicer_add_content"]);}
    update_post_meta($post_id, "voicer_add_content", $voicer_add_content);

    if (isset($_POST["tt_post_s_fstate"])) {$tt_post_s_fstate = sanitize_text_field($_POST["tt_post_s_fstate"]);}
    update_post_meta($post_id, "tt_post_s_fstate", $tt_post_s_fstate);

}
add_action("save_post", "voicer_front_save_mbox", 10, 3);

function voicer_gallery_shortcode($attr) {
    $size = 'full';
    $post = get_post();
    static $instance = 0;
    $instance++;
    if ( ! empty( $attr['ids'] ) ) {
        if ( empty( $attr['orderby'] ) )
            $attr['orderby'] = 'post__in';
        $attr['include'] = $attr['ids'];
    }
    $output = apply_filters('post_gallery', '', $attr);
    if ( $output != '' )
        return $output;
    if ( isset( $attr['orderby'] ) ) {
        $attr['orderby'] = sanitize_sql_orderby( $attr['orderby'] );
        if ( !$attr['orderby'] )
            unset( $attr['orderby'] );
    }
    extract(shortcode_atts(array(
        'order'      => 'ASC',
        'orderby'    => 'menu_order ID',
        'id'         => $post->ID,
        'itemtag'    => 'dl',
        'icontag'    => 'figure',
        'captiontag' => 'figcaption',
        'columns'    => 3,
        'size'       => 'thumbnail',
        'include'    => '',
        'exclude'    => '',
        'g_type'    => '',
        'dots' => 0,
        'arrows' => 1
    ), $attr));

    $size_class = sanitize_html_class( $size );
    $columns = intval($columns);
    $arrows = intval( $arrows );
    $dots = intval( $dots );


    $slider_ini = ($g_type == 'voicer' ? 'ini-post-slider' : 'gallery-columns-'.$columns.' gallery-size-'.$size_class);
    $image_class = ($g_type == 'voicer' ? '' : 'gallery-icon');

    $cell_class = ($g_type == 'voicer' ? '' : 'gallery-item');


    $id = intval($id);
    if ( 'RAND' == $order )
        $orderby = 'none';

    if ( !empty($include) ) {
        $_attachments = get_posts( array('include' => $include, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );

        $attachments = array();
        foreach ( $_attachments as $key => $val ) {
            $attachments[$val->ID] = $_attachments[$key];
        }
    } elseif ( !empty($exclude) ) {
        $attachments = get_children( array('post_parent' => $id, 'exclude' => $exclude, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
    } else {
        $attachments = get_children( array('post_parent' => $id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
    }

    if ( empty($attachments) )
        return '';

    if ( is_feed() ) {
        foreach ( $attachments as $att_id => $attachment )
            $output .= wp_get_attachment_link($att_id, $size, true);
        return $output;
    }

    $itemtag = tag_escape($itemtag);
    $captiontag = tag_escape($captiontag);
    $icontag = tag_escape($icontag);
    $valid_tags = wp_kses_allowed_html( 'post' );
    if ( ! isset( $valid_tags[ $itemtag ] ) )
        $itemtag = 'dl';
    if ( ! isset( $valid_tags[ $captiontag ] ) )
        $captiontag = 'figcaption';
    if ( ! isset( $valid_tags[ $icontag ] ) )
        $icontag = 'figure';

    $itemwidth = $columns > 0 ? floor(100/$columns) : 100;

    $selector = "tt-post-gallery";
    $gallery_style = $gallery_div = '';
    if ( apply_filters( 'use_default_gallery_style', true ) )


        $gallery_div = "<div id='$selector' class='post-carousel $slider_ini'>";
    $output = apply_filters( 'gallery_style', $gallery_style . "\n\t\t" . $gallery_div );

    foreach ( $attachments as $id => $attachment ) {
        $link = isset($attr['link']) && 'file' == $attr['link'] ? wp_get_attachment_link($id, $size_class, false, false) : wp_get_attachment_link($id, $size_class, true, false);

        $output .= " <$icontag class='$cell_class tt-gallery-cell'>";
        $output .= "<div class='$image_class'>$link</div>";
        if ( $captiontag && trim($attachment->post_excerpt) ) {
            $output .= "<$captiontag class='wp-caption-text gallery-caption tt-post-gallery__caption'>" . wptexturize($attachment->post_excerpt) . "</$captiontag>";
        }
        $output .= " </$icontag>";
    }
    $output .= " </div>";

    wp_enqueue_script('voicer-gallery', get_template_directory_uri() . '/js/' . 'voicer-gallery.js');
    wp_localize_script('voicer-gallery', 'slider_vars', array(
            'columns' => $columns,
            'dots' => $dots,
            'arrows' => $arrows
        )
    );

    return $output;
}
function voicer_aw_player( $atts, $content = "" ) {
    $atts = shortcode_atts( array(
        'type' => '',
        'baz' => 'default baz'
    ), $atts, 'aw_player' );
    $type = "{$atts['type']}";

    $player_output = '';
    $btn_play = '<svg class="icon icon-play awp-contr-btn-i icon-play-circle awp-icon-color" width="30" height="31" viewBox="0 0 30 31" xmlns="http://www.w3.org/2000/svg"><path d="M15 0.875C12.9297 0.875 10.9766 1.26562 9.14062 2.04688C7.32422 2.82812 5.73242 3.90234 4.36523 5.26953C3.01758 6.61719 1.95312 8.20898 1.17188 10.0449C0.390625 11.8613 0 13.8047 0 15.875C0 17.9453 0.390625 19.8984 1.17188 21.7344C1.95312 23.5508 3.01758 25.1426 4.36523 26.5098C5.73242 27.8574 7.32422 28.9219 9.14062 29.7031C10.9766 30.4844 12.9297 30.875 15 30.875C17.0703 30.875 19.0137 30.4844 20.8301 29.7031C22.666 28.9219 24.2578 27.8574 25.6055 26.5098C26.9727 25.1426 28.0469 23.5508 28.8281 21.7344C29.6094 19.8984 30 17.9453 30 15.875C30 13.8047 29.6094 11.8613 28.8281 10.0449C28.0469 8.20898 26.9727 6.61719 25.6055 5.26953C24.2578 3.90234 22.666 2.82812 20.8301 2.04688C19.0137 1.26562 17.0703 0.875 15 0.875ZM15 28.0625C13.3203 28.0625 11.7383 27.75 10.2539 27.125C8.76953 26.4805 7.4707 25.6113 6.35742 24.5176C5.26367 23.4043 4.39453 22.1055 3.75 20.6211C3.125 19.1367 2.8125 17.5547 2.8125 15.875C2.8125 14.1953 3.125 12.6133 3.75 11.1289C4.39453 9.64453 5.26367 8.35547 6.35742 7.26172C7.4707 6.14844 8.76953 5.2793 10.2539 4.6543C11.7383 4.00977 13.3203 3.6875 15 3.6875C16.6797 3.6875 18.2617 4.00977 19.7461 4.6543C21.2305 5.2793 22.5195 6.14844 23.6133 7.26172C24.7266 8.35547 25.5957 9.64453 26.2207 11.1289C26.8652 12.6133 27.1875 14.1953 27.1875 15.875C27.1875 17.5547 26.8652 19.1367 26.2207 20.6211C25.5957 22.1055 24.7266 23.4043 23.6133 24.5176C22.5195 25.6113 21.2305 26.4805 19.7461 27.125C18.2617 27.75 16.6797 28.0625 15 28.0625ZM11.25 9.3125L22.5 15.875L11.25 22.4375V9.3125Z"/></svg>';
    $btn_stop = '<svg class="icon icon-pause icon-play-circle awp-icon-color" width="30" height="31" viewBox="0 0 30 31" xmlns="http://www.w3.org/2000/svg"><path d="M8.8,8.5h4.1V24H8.8V8.5z M16.6,24.1h4.1V8.5h-4.1V24.1z M30,15.9c0,2.1-0.4,4-1.2,5.9c-0.8,1.8-1.9,3.4-3.2,4.8c-1.3,1.3-2.9,2.4-4.8,3.2c-1.8,0.8-3.8,1.2-5.8,1.2s-4-0.4-5.9-1.2c-1.8-0.8-3.4-1.8-4.8-3.2c-1.3-1.4-2.4-3-3.2-4.8C0.4,19.9,0,17.9,0,15.9s0.4-4,1.2-5.8C2,8.2,3,6.6,4.4,5.3c1.4-1.4,3-2.4,4.8-3.2C11,1.3,12.9,0.9,15,0.9s4,0.4,5.8,1.2c1.8,0.8,3.4,1.9,4.8,3.2C27,6.6,28,8.2,28.8,10C29.6,11.9,30,13.8,30,15.9z M27.2,15.9c0-1.7-0.3-3.3-1-4.7c-0.6-1.5-1.5-2.8-2.6-3.9c-1.1-1.1-2.4-2-3.9-2.6c-1.5-0.6-3.1-1-4.7-1s-3.3,0.3-4.7,1C8.8,5.3,7.5,6.1,6.4,7.3c-1.1,1.1-2,2.4-2.6,3.9c-0.6,1.5-0.9,3.1-0.9,4.7s0.3,3.3,0.9,4.7c0.6,1.5,1.5,2.8,2.6,3.9c1.1,1.1,2.4,2,3.9,2.6c1.5,0.6,3.1,0.9,4.7,0.9s3.3-0.3,4.7-0.9c1.5-0.6,2.8-1.5,3.9-2.6c1.1-1.1,2-2.4,2.6-3.9C26.9,19.1,27.2,17.6,27.2,15.9z"/></svg>';

    $btn_play_prev = '<svg class="icon icon-play-prev awp-contr-btn-i awp-icon-color" width="18" height="16" viewBox="0 0 18 16" xmlns="http://www.w3.org/2000/svg"><path d="M16.5879 15.5801C16.8027 15.5801 16.9883 15.502 17.1445 15.3457C17.3008 15.1895 17.3789 15.0039 17.3789 14.7891V0.990234C17.3789 0.755859 17.3008 0.570312 17.1445 0.433594C16.9883 0.277344 16.8027 0.199219 16.5879 0.199219L3.75586 7.28906C3.75586 7.28906 3.67773 7.41602 3.52148 7.66992C3.38477 7.9043 3.46289 8.16797 3.75586 8.46094C3.91211 8.61719 4.66406 9.07617 6.01172 9.83789C7.37891 10.5801 8.84375 11.3809 10.4062 12.2402C11.9688 13.0996 13.3848 13.8711 14.6543 14.5547C15.9434 15.2383 16.5879 15.5801 16.5879 15.5801ZM3.25781 1.04883C3.25781 0.794922 3.16992 0.589844 2.99414 0.433594C2.83789 0.257812 2.64258 0.169922 2.4082 0.169922H1.4707C1.23633 0.169922 1.03125 0.257812 0.855469 0.433594C0.699219 0.589844 0.621094 0.794922 0.621094 1.04883V14.7012C0.621094 14.9551 0.699219 15.1699 0.855469 15.3457C1.03125 15.502 1.23633 15.5801 1.4707 15.5801H2.4082C2.64258 15.5801 2.83789 15.502 2.99414 15.3457C3.16992 15.1699 3.25781 14.9551 3.25781 14.7012V1.04883Z"/></svg>';
    $btn_play_next = '<svg class="icon icon-play-next awp-contr-btn-i awp-icon-color" width="18" height="16" viewBox="0 0 18 16" xmlns="http://www.w3.org/2000/svg"><path d="M1.41211 15.5801C1.19727 15.5801 1.01172 15.502 0.855469 15.3457C0.699219 15.1895 0.621094 15.0039 0.621094 14.7891V0.990234C0.621094 0.755859 0.699219 0.570312 0.855469 0.433594C1.01172 0.277344 1.19727 0.199219 1.41211 0.199219L14.2441 7.28906C14.2441 7.28906 14.3125 7.41602 14.4492 7.66992C14.6055 7.9043 14.5371 8.16797 14.2441 8.46094C14.0879 8.61719 13.3262 9.07617 11.959 9.83789C10.6113 10.5801 9.15625 11.3809 7.59375 12.2402C6.03125 13.0996 4.60547 13.8711 3.31641 14.5547C2.04688 15.2383 1.41211 15.5801 1.41211 15.5801ZM14.7422 1.04883C14.7422 0.794922 14.8203 0.589844 14.9766 0.433594C15.1523 0.257812 15.3574 0.169922 15.5918 0.169922H16.5293C16.7637 0.169922 16.959 0.257812 17.1152 0.433594C17.291 0.589844 17.3789 0.794922 17.3789 1.04883V14.7012C17.3789 14.9551 17.291 15.1699 17.1152 15.3457C16.959 15.502 16.7637 15.5801 16.5293 15.5801H15.5918C15.3574 15.5801 15.1523 15.502 14.9766 15.3457C14.8203 15.1699 14.7422 14.9551 14.7422 14.7012V1.04883Z"/></svg>';
    $btn_volume = '<svg class="icon icon-volume" width="20" height="14" viewBox="0 0 20 14" xmlns="http://www.w3.org/2000/svg"><path d="M1.11328 9.47656C0.800781 9.47656 0.533854 9.58724 0.3125 9.80859C0.104167 10.0169 0 10.2773 0 10.5898V12.7969C0 13.1094 0.104167 13.3763 0.3125 13.5977C0.533854 13.806 0.800781 13.9102 1.11328 13.9102C1.41276 13.9102 1.67318 13.806 1.89453 13.5977C2.11589 13.3763 2.22656 13.1094 2.22656 12.7969V10.5898C2.22656 10.2773 2.11589 10.0169 1.89453 9.80859C1.67318 9.58724 1.41276 9.47656 1.11328 9.47656ZM5.54688 7.25C5.2474 7.25 4.98698 7.36068 4.76562 7.58203C4.55729 7.79036 4.45312 8.05078 4.45312 8.36328V12.7969C4.45312 13.1094 4.55729 13.3763 4.76562 13.5977C4.98698 13.806 5.2474 13.9102 5.54688 13.9102C5.85938 13.9102 6.11979 13.806 6.32812 13.5977C6.54948 13.3763 6.66016 13.1094 6.66016 12.7969V8.36328C6.66016 8.05078 6.54948 7.79036 6.32812 7.58203C6.11979 7.36068 5.85938 7.25 5.54688 7.25ZM10 5.02344C9.6875 5.02344 9.42057 5.13411 9.19922 5.35547C8.99089 5.57682 8.88672 5.83724 8.88672 6.13672V12.7969C8.88672 13.1094 8.99089 13.3763 9.19922 13.5977C9.42057 13.806 9.6875 13.9102 10 13.9102C10.3125 13.9102 10.5729 13.806 10.7812 13.5977C11.0026 13.3763 11.1133 13.1094 11.1133 12.7969V6.13672C11.1133 5.83724 11.0026 5.57682 10.7812 5.35547C10.5729 5.13411 10.3125 5.02344 10 5.02344ZM14.4531 2.79688C14.1406 2.79688 13.8737 2.90755 13.6523 3.12891C13.444 3.35026 13.3398 3.61068 13.3398 3.91016V12.7969C13.3398 13.1094 13.444 13.3763 13.6523 13.5977C13.8737 13.806 14.1406 13.9102 14.4531 13.9102C14.7526 13.9102 15.0065 13.806 15.2148 13.5977C15.4362 13.3763 15.5469 13.1094 15.5469 12.7969V3.91016C15.5469 3.61068 15.4362 3.35026 15.2148 3.12891C15.0065 2.90755 14.7526 2.79688 14.4531 2.79688ZM18.8867 0.589844C18.5872 0.589844 18.3268 0.700521 18.1055 0.921875C17.8841 1.13021 17.7734 1.39062 17.7734 1.70312V12.7969C17.7734 13.1094 17.8841 13.3763 18.1055 13.5977C18.3268 13.806 18.5872 13.9102 18.8867 13.9102C19.1992 13.9102 19.4596 13.806 19.668 13.5977C19.8893 13.3763 20 13.1094 20 12.7969V1.70312C20 1.39062 19.8893 1.13021 19.668 0.921875C19.4596 0.700521 19.1992 0.589844 18.8867 0.589844Z"/></svg>';


    $btn_close = '<svg class="icon icon-close" width="20" height="21" viewBox="0 0 20 21" xmlns="http://www.w3.org/2000/svg"><path d="M9.04297 10.1921L0.195312 19.0398C0.0651042 19.157 0 19.3002 0 19.4695C0 19.6518 0.0651042 19.8015 0.195312 19.9187C0.260417 19.9838 0.325521 20.0294 0.390625 20.0554C0.46875 20.0945 0.553385 20.114 0.644531 20.114C0.722656 20.114 0.800781 20.0945 0.878906 20.0554C0.957031 20.0294 1.02214 19.9838 1.07422 19.9187L10 11.0125L18.9258 19.9187C18.9779 19.9838 19.043 20.0294 19.1211 20.0554C19.1992 20.0945 19.2773 20.114 19.3555 20.114C19.4466 20.114 19.5312 20.0945 19.6094 20.0554C19.6875 20.0294 19.7526 19.9838 19.8047 19.9187C19.9349 19.8015 20 19.6518 20 19.4695C20 19.3002 19.9349 19.157 19.8047 19.0398L10.957 10.1921L19.8242 1.32495C19.9414 1.20776 20 1.06453 20 0.895264C20 0.712972 19.9414 0.556722 19.8242 0.426514C19.694 0.309326 19.5378 0.250732 19.3555 0.250732C19.1862 0.250732 19.043 0.309326 18.9258 0.426514L10 9.35229L1.07422 0.426514C0.957031 0.309326 0.807292 0.250732 0.625 0.250732C0.455729 0.250732 0.30599 0.309326 0.175781 0.426514C0.0585938 0.556722 0 0.712972 0 0.895264C0 1.06453 0.0585938 1.20776 0.175781 1.32495L9.04297 10.1921Z" /></svg>';

    switch ( $type ) :
        case 'home':
            $player =  '<div id="awp-home-player" class="awp-home-player">
				<div class="awp-player-holder">
                    <div class="awp-prev-toggle awp-contr-btn">'.$btn_play_prev.'</div>
                    <div class="awp-playback-toggle awp-contr-btn">'.$btn_play.$btn_stop.'</div>
                    <div class="awp-next-toggle awp-contr-btn">'.$btn_play_next.'</div>
					<div class="awp-info">
						<span class="awp-player-artist"></span> - <span class="awp-player-title"></span>
					</div>
					<div class="awp-waveform-wrap">
						<div class="awp-waveform awp-hidden"></div>
						<div class="awp-waveform-img awp-hidden">
							<div class="awp-waveform-img-load"></div>
							<div class="awp-waveform-img-progress-wrap">
								<div class="awp-waveform-img-progress"></div>
							</div>
						</div>
						<span class="awp-waveform-preloader"></span>
					</div>
					<div class="awp-media-time">
						<span class="awp-media-time-current awp-contr-btn">0:00</span>|<span class="awp-media-time-total awp-contr-btn">0:00</span>
					</div>
					<div class="awp-volume-wrapper">
						<div class="awp-player-volume">'.$btn_volume.'</div>
						<div class="awp-volume-seekbar awp-tooltip-top">
							<div class="awp-volume-bg"></div>
							<div class="awp-volume-level"></div>
						</div>
					</div>
				</div>
			</div>';
            $player_before = '<div id="awp-home-playlist"><p>';
            $player_after = '</div>';
            $player_output = $player.$player_before."$content".$player_after;

            break;

        case 'popup':
            $player = '
            <div id="awp-grid-player" class="awp-player">
                <button class="close" aria-label="Close" data-dismiss="modal">'.$btn_close.'</button>
				<div class="awp-player-thumb"></div>
				<div class="awp-player-holder">
					<div class="awp-info">
						<div class="awp-player-artist"></div>
						<div class="awp-player-title"></div>
					</div>
					<div class="awp-waveform-wrap">
						<div class="awp-waveform awp-hidden"></div>
						<div class="awp-waveform-img awp-hidden">
							<div class="awp-waveform-img-load"></div>
							<div class="awp-waveform-img-progress-wrap">
								<div class="awp-waveform-img-progress"></div>
							</div>
						</div>
						<span class="awp-waveform-preloader"></span>
					</div>
					<div class="awp-player-controls">
                        <div class="awp-prev-toggle awp-contr-btn">'.$btn_play_prev.'</div>
                        <div class="awp-playback-toggle awp-contr-btn">'.$btn_play.$btn_stop.'</div>
                        <div class="awp-next-toggle awp-contr-btn">'.$btn_play_next.'</div>
						<div class="awp-volume-wrapper">
                            <div class="awp-player-volume">'.$btn_volume.'</div>
							<div class="awp-volume-seekbar awp-tooltip-top">
								<div class="awp-volume-bg"></div>
								<div class="awp-volume-level"></div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div id="awp-grid-playlist"><p>';
            $player_before = '<div id="playerPopup" class="awp-player-popup mfp-with-anim"><div class="mfp-inside">';
            $player_after = '</p></div></div></div>';

            $player_output = $player_before.$player."$content".$player_after;
            break;

        case 'projects':
            $player = '
            <div id="awp-project-player" class="awp-project-player">
					<div class="awp-player-row-top">
						<div class="awp-player-thumb-wrapper">
							<div class="awp-player-thumb"></div>
						</div>
						<div class="awp-info">
							<div class="awp-player-title"></div>
							<div class="awp-player-artist"></div>
						</div>
					</div>
					<div class="awp-player-holder">
						<div class="awp-player-controls">
                            <div class="awp-prev-toggle awp-contr-btn">'.$btn_play_prev.'</div>
                            <div class="awp-playback-toggle awp-contr-btn">'.$btn_play.$btn_stop.'</div>
                            <div class="awp-next-toggle awp-contr-btn">'.$btn_play_next.'</div>
						</div>
						<div class="awp-waveform-with-time">
							<div class="awp-media-time-total awp-hidden">0:00</div>
							<div class="awp-waveform-wrap">
								<div class="awp-waveform awp-hidden"></div>
								<div class="awp-waveform-img awp-hidden">
									<div class="awp-waveform-img-load"></div>
									<div class="awp-waveform-img-progress-wrap">
										<div class="awp-waveform-img-progress"></div>
									</div>
								</div>
								<div class="awp-waveform-preloader"></div>
							</div>
							<div class="awp-media-time-current awp-hidden">0:00</div>
						</div>
					</div>
					<div class="awp-playlist-holder">
						<div class="awp-playlist-inner">
							<div class="awp-playlist-content">
							</div>
						</div>
						<div class="awp-preloader"></div>
					</div>
				</div>
            ';
            $player_before = '<div id="awp-project-playlist">';
            $player_after = '';

            $player_output = $player.$player_before."$content".$player_after;
            break;

    endswitch;
    return $player_output;
}

remove_shortcode('gallery');
add_shortcode('gallery', 'voicer_gallery_shortcode');
add_shortcode('aw_player', 'voicer_aw_player' );


add_shortcode('voicer_tagcloud', 'voicer_tagcloud');
add_shortcode('voicer_categories', 'voicer_categories');
add_shortcode('voicer_featured_posts', 'voicer_featured_posts');


require_once 'inc/voicer-custom-fields.php';

add_filter('style_loader_tag', 'sj_remove_type_attr', 10, 2);
add_filter('script_loader_tag', 'sj_remove_type_attr', 10, 2);
add_filter('wp_print_footer_scripts ', 'sj_remove_type_attr', 10, 2);
function sj_remove_type_attr($tag) {
    return preg_replace( "/type=['\"]text\/(javascript|css)['\"]/", '', $tag );
}

function voicer_add_favicon() {
    echo '<link rel="shortcut icon" type="image/x-icon" href="'.get_template_directory_uri().'/favicon.png" />';
}
add_action('wp_head', 'voicer_add_favicon');




add_action( 'init', 'voicer_register_menus' );

function voicer_register_menus() {
    register_nav_menus(
        array(
            'voicer_header_navigation' => esc_html__( 'Theme Header Menu','voicer-layout'),
            'voicer_footer_menu' => esc_html__( 'Theme Footer Menu','voicer-layout')
        )
    );
}
add_action( 'init', 'voicer_register_menus' );

add_action( 'widgets_init', 'voicer_default_widget_demo' );

function voicer_default_widget_demo() {

    register_widget( 'Voicer_Demo_Widget' );
    $sidebars = array (
        'a' => esc_html__('Theme-Footer-Logos', 'voicer-layout'),
        'b' => esc_html__('Theme-Footer-Information', 'voicer-layout'),
        'c' => esc_html__('Theme-Footer-Socials', 'voicer-layout'),
        'd' => esc_html__('Theme-Footer-Copyright', 'voicer-layout'),

        'e' => esc_html__('Theme-Blog-Home', 'voicer-layout'),
        'g' => esc_html__('Theme-Header-Cart', 'voicer-layout'),
        'h' => esc_html__('Theme-Shop', 'voicer-layout'),
    );
    $before_widget = '';
    $after_widget = '';
    $before_title = '';
    $after_title = '';
    $description = '';

    foreach ( $sidebars as $sidebar ) {
        switch ($sidebar) :
            case 'Theme-Footer-Logos':
                $description = 'This sidebar will show in Footer';
                $before_title = '<h4 class="footer-logo-title">';
                $after_title = '</h4>';
                break;
            case 'Theme-Footer-Information':
                $description = 'This sidebar will show in Footer';
                break;
            case 'Theme-Footer-Socials':
                $description = 'This sidebar will show in Footer';
                break;
            case 'Theme-Footer-Copyright':
                $description = 'This sidebar will show in Footer';
                break;
            case 'Theme-Blog-Home':
                $description = 'This sidebar will show in Blog Home Page';
                $before_widget = '<div class="side-block %2$s">';
                $after_widget = '</div>';
                $before_title = '<h4 class="tt-widget-title">';
                $after_title = '</h4>';

                break;
            case 'Theme-Blog-Default':
                $description = 'This sidebar will show in blog other page without blog home page';
                $before_widget = '<div class="side-block %2$s">';
                $after_widget = '</div>';
                $before_title = '<h4 class="tt-widget-title">';
                $after_title = '</h4>';
                break;
            case 'Theme-Shop':
                $description = 'This sidebar will show in Shop Page';
                $before_widget = '<div class="side-block %2$s">';
                $after_widget = '</div>';
                $before_title = '<h3 class="side-block-title">';
                $after_title = '</h3>';
                break;
            case 'Theme-Header-Cart':
                $description = 'This sidebar will show in Header for Mini cart only';
                $before_widget = '';
                $after_widget = '';
                break;
            default:
        endswitch;

        register_sidebar(
            array (
                'name'          => str_replace('-', ' ', $sidebar),
                'id'            => $sidebar,
                'before_widget' => $before_widget,
                'after_widget'  => $after_widget,
                'before_title'  => $before_title,
                'after_title'   => $after_title,
                'description'   => $description
            )
        );
    }
    $active_widgets = get_option( 'sidebars_widgets' );
    if ( ! empty ( $active_widgets[ $sidebars['a'] ] )
        or ! empty ( $active_widgets[ $sidebars['b'] ] )
        or ! empty ( $active_widgets[ $sidebars['c'] ] )
        or ! empty ( $active_widgets[ $sidebars['d'] ] )
        or ! empty ( $active_widgets[ $sidebars['e'] ] )
        or ! empty ( $active_widgets[ $sidebars['g'] ] )
        or ! empty ( $active_widgets[ $sidebars['h'] ] )
    ) {
        return;
    }

    $counter = 100;


    $active_widgets[ $sidebars['a'] ][0] = 'voicer_demo_widget-' . $counter;
    $demo_widget_content[ $counter ] = array ('title' => '!Footer logo','text' => '[voicer_icon icon="icon-logo" link="#"]' );
    $counter++;


    $active_widgets[ $sidebars['b'] ][0] = 'voicer_demo_widget-' . $counter;
    $demo_widget_content[ $counter ] = array (
        'title'        => '!Footer Information',
        'text' => '
        <div class="col-sm-4">
            <div class="footer-info">[voicer_icon icon="icon-place"]<strong>Voicer Studio Recording</strong>1035 N Sycamore<br> Avenue Hollywood, CA 90040 </div>
        </div>
        <div class="col-sm-4">
            <div class="footer-info">[voicer_icon icon="icon-phone"]<strong>Contact Phones</strong>1 (800) 765-43-21, 765-43-21<br>1 (800) 765-43-23 (fax)</div>
        </div>
        <div class="col-sm-4">
            <div class="footer-info">[voicer_icon icon="icon-time"]<strong>Working Hours</strong>Mon-Fri: 9:00 am - 5:00 pm <br>Sat-Sun: 11:00 am - 16:00 pm </div>
        </div>
    ');
    $counter++;

    $active_widgets[ $sidebars['c'] ][0] = 'voicer_demo_widget-' . $counter;
    $demo_widget_content[ $counter ] = array ('title' => '!Footer socials','text' => '[voicer_icon icon="icon-facebook" link="//www.facebook.com"][voicer_icon icon="icon-twitter" link="www.twitter.com"][voicer_icon icon="icon-googleplus" link="//plus.google.com"][voicer_icon icon="icon-linkedin" link="#"]' );
    $counter++;

    $active_widgets[ $sidebars['d'] ][] = 'voicer_demo_widget-' . $counter;
    $demo_widget_content[ $counter ] = array ('title' => '!Footer copyright','text' => '<div class="footer-copyright text-center">&copy; 2019 Voicer Recording Studio.<br class="hidden visible-xs"> All Rights Reserved.</div><div class="footer-link text-center"><a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></div>' );
    $counter++;


    $active_widgets[ $sidebars['e'] ][] = 'search-' . $counter;
    $widget_content[ $counter ] = array (
        'title'        => '!Blog Search'
    );
    update_option( 'widget_search', $widget_content);
    $counter++;

    $active_widgets[ $sidebars['e'] ][] = 'custom_html-' . $counter;
    $widget_content[ $counter ] = array (
        'title'        => 'Categories',
        'content'     => '[voicer_categories show_count="1"]'
    );
    update_option( 'widget_custom_html', $widget_content);
    $counter++;


    $active_widgets[ $sidebars['e'] ][] = 'calendar-' . $counter;
    $widget_content[ $counter ] = array (
        'title'        => 'Archives'
    );
    update_option( 'widget_calendar', $widget_content);
    $counter++;

    $active_widgets[ $sidebars['e'] ][] = 'custom_html-' . $counter;
    $widget_content[ $counter ] = array (
        'title'        => '!Featured Posts',
        'content'     => '[voicer_featured_posts qty="3"]'
    );
    update_option( 'widget_custom_html', $widget_content);
    $counter++;


    $active_widgets[ $sidebars['e'] ][] = 'custom_html-' . $counter;
    $widget_content[ $counter ] = array (
        'title'        => 'Popular tags',
        'content'     => '[voicer_tagcloud taxonomy="post_tag"]'
    );
    update_option( 'widget_custom_html', $widget_content);
    $counter++;


    $active_widgets[ $sidebars['g'] ][] = 'voicer_demo_widget-' . $counter;
    $demo_widget_content[ $counter ] = array ('title' => '!Header Cart','text' => '[voicer_mini_cart]' );
    $counter++;

    $active_widgets[ $sidebars['h'] ][] = 'woocommerce_product_categories-' . $counter;
    $widget_content[ $counter ] = array (
        'title'        => 'Categories',
        'orderby'     => 'order',
        'dropdown'     => '',
        'count'     => '',
        'hierarchical'     => '1',
        'show_children_only'     => '',
        'hide_empty'     => '',
        'max_depth'     => '',
    );
    update_option( 'widget_woocommerce_product_categories', $widget_content);
    $counter++;

    $active_widgets[ $sidebars['h'] ][] = 'woocommerce_price_filter-' . $counter;
    $widget_content[ $counter ] = array (
        'title'        => 'Price',
    );
    update_option( 'widget_woocommerce_price_filter', $widget_content);
    $counter++;

    $active_widgets[ $sidebars['h'] ][] = 'woocommerce_top_rated_products-' . $counter;
    $widget_content[ $counter ] = array (
        'title'        => 'Popular',
        'number'     => '3',
    );
    update_option( 'widget_woocommerce_top_rated_products', $widget_content);
    $counter++;


    update_option( 'widget_voicer_demo_widget', $demo_widget_content );
    update_option( 'sidebars_widgets', $active_widgets );
}


class Voicer_Demo_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct( 'voicer_demo_widget', 'Voicer Demo Widget' );
    }
    public function widget( $args, $instance ) {
        $text = apply_filters( 'widget_text', empty( $instance['text'] ) ? '' : $instance['text'], $instance );
        echo $args['before_widget'], $text, $args['after_widget'];
        $title = apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base );
        if ( ! empty( $title ) ) {
            echo $args['before_title'] . $title . $args['after_title'];
        }
    }
    public function form( $instance ) {
        $text = isset ( $instance['text'] ) ? esc_textarea( $instance['text'] ) : '';
        $title = isset ( $instance['title'] ) ? sanitize_text_field( $instance['title'] ): '' ;
        $text = shortcode_unautop( $text );
        $settings = array(
            'textarea_name' => $this->get_field_name( 'text' ),
            'media_buttons' => false,
            'teeny' => true
        );
        echo '<p><input name="'.$this->get_field_name( 'title' ).'" class="widefat title" type="text" value="'. $title.'"/></p>';
        printf(
            '<p><textarea class="widefat" rows="7" cols="20" id="%1$s" name="%2$s">%3$s</textarea></p>',
            $this->get_field_id( 'text' ),
            $this->get_field_name( 'text' ),
            $text
        );
    }
}


function voicer_mini_cart() {
        if (voicer_plugin_detect('woo')):
            echo '<div id="voicer-cart" class="header-cart">';
            echo '<a href="#" class="dropdown-back" data-toggle="dropdown"><svg class="icon icon-cart" width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M23.8128 4.96444C23.6358 4.72814 23.3578 4.58906 23.0625 4.58906H5.40389L4.88906 2.83036C4.77211 2.4308 4.40569 2.15625 3.98934 2.15625H0.9375C0.419719 2.15625 0 2.57597 0 3.09375C0 3.61153 0.419719 4.03125 0.9375 4.03125H3.28692C3.42384 4.49902 6.88678 16.3287 7.02666 16.8066C7.14361 17.2061 7.51008 17.4807 7.92637 17.4807H19.8376C20.254 17.4807 20.6204 17.2061 20.7374 16.8066L23.9622 5.78995C24.0452 5.50664 23.9898 5.20073 23.8128 4.96444ZM19.1353 15.6057H8.6288L5.9528 6.46406H21.8113L19.1353 15.6057Z" /><path d="M9.35742 21.8438C10.0564 21.8438 10.623 21.2771 10.623 20.5781C10.623 19.8791 10.0564 19.3125 9.35742 19.3125C8.65844 19.3125 8.0918 19.8791 8.0918 20.5781C8.0918 21.2771 8.65844 21.8438 9.35742 21.8438Z" /><path d="M18.4062 21.8438C19.1052 21.8438 19.6719 21.2771 19.6719 20.5781C19.6719 19.8791 19.1052 19.3125 18.4062 19.3125C17.7073 19.3125 17.1406 19.8791 17.1406 20.5781C17.1406 21.2771 17.7073 21.8438 18.4062 21.8438Z"/></svg>';
            echo '</a>';
            echo '<ul class="dropdown-menu dropdown-menu-mini-cart header-cart-dropdown">';
            echo '<li> <div class="widget_shopping_cart_content">';
            echo '<span class="cart-items-count7 count7 badge">';
            echo '</span>';
            woocommerce_mini_cart();
            echo '</div></li></ul>';
            echo '</div>';
        endif;

}

add_shortcode( 'voicer_mini_cart', 'voicer_mini_cart' );
function voicer_icon_func( $atts, $content ) {
    $ch_icons = array (
        array('icon-arrow-left','<svg class="icon icon-arrow-left" width="22" height="41" viewBox="0 0 22 41" xmlns="http://www.w3.org/2000/svg"><path d="M20.5312 40.5L0.53125 20.5L20.5312 0.5L21.4688 1.4375L2.44531 20.5L21.4688 39.5625L20.5312 40.5Z"/></svg>'),
        array('icon-arrow-right','<svg class="icon icon-arrow-right" width="22" height="41" viewBox="0 0 22 41" xmlns="http://www.w3.org/2000/svg"><path d="M1.66875 40.5L21.6688 20.5L1.66875 0.5L0.731251 1.4375L19.7547 20.5L0.731251 39.5625L1.66875 40.5Z"/></svg>'),
        array('icon-bin','<svg class="icon icon-bin" width="17" height="17" viewBox="0 0 17 17" xmlns="http://www.w3.org/2000/svg"><path d="M13.4321 2.03674H10.7859C10.6539 0.892094 9.68002 0 8.50052 0C7.32106 0 6.34731 0.892059 6.21531 2.03674H3.56898C2.49808 2.03674 1.62695 2.90812 1.62695 3.97897V4.07863C1.62695 4.89697 2.1365 5.5974 2.85431 5.8828V15.0578C2.85431 16.1287 3.72554 17 4.79637 17H12.2048C13.2756 17 14.1468 16.1286 14.1468 15.0578V5.88283C14.8645 5.5974 15.3741 4.89697 15.3741 4.07866V3.97901C15.3741 2.90812 14.5029 2.03674 13.4321 2.03674ZM8.50052 0.921095C9.17136 0.921095 9.7313 1.40192 9.85519 2.03674H7.1461C7.26996 1.40189 7.82994 0.921095 8.50052 0.921095ZM13.2257 15.0578C13.2257 15.6208 12.7676 16.0789 12.2047 16.0789H4.79633C4.23347 16.0789 3.77537 15.6208 3.77537 15.0578V6.02086H13.2257V15.0578ZM14.453 4.07863C14.453 4.64167 13.9949 5.0998 13.4321 5.0998H3.56898C3.00611 5.0998 2.54801 4.64167 2.54801 4.07863V3.97897C2.54801 3.41594 3.00611 2.9578 3.56898 2.9578H13.4321C13.995 2.9578 14.4531 3.41594 14.4531 3.97897V4.07863H14.453Z" /><path d="M6.03084 14.901C6.28519 14.901 6.49137 14.6947 6.49137 14.4405V9.25504C6.49137 9.00076 6.28516 8.79448 6.03084 8.79448C5.77653 8.79448 5.57031 9.00076 5.57031 9.25504V14.4405C5.57028 14.6948 5.77649 14.901 6.03084 14.901Z" /><path d="M8.49959 14.901C8.75394 14.901 8.96015 14.6947 8.96015 14.4405V9.25504C8.96015 9.00076 8.75387 8.79448 8.49959 8.79448C8.24528 8.79448 8.03906 9.00076 8.03906 9.25504V14.4405C8.03906 14.6948 8.24524 14.901 8.49959 14.901Z" /><path d="M10.9703 14.901C11.2246 14.901 11.4308 14.6947 11.4308 14.4405V9.25504C11.4308 9.00076 11.2246 8.79448 10.9703 8.79448C10.7159 8.79448 10.5098 9.00076 10.5098 9.25504V14.4405C10.5097 14.6948 10.716 14.901 10.9703 14.901Z" /></svg>'),
        array('icon-booking','<svg class="icon icon-booking" width="44" height="38" viewBox="0 0 44 38" xmlns="http://www.w3.org/2000/svg"><path d="M41.3594 7.04688H39.5312C39.4375 6.70312 39.2344 6.4375 38.9219 6.25C38.6406 6.03125 38.3125 5.92188 37.9375 5.92188H34.5156C34.1406 5.92188 33.8125 6.03125 33.5312 6.25C33.25 6.4375 33.0469 6.70312 32.9219 7.04688H30.5312V1.9375C30.5312 1.46875 30.3594 1.0625 30.0156 0.71875C29.7031 0.375 29.3125 0.203125 28.8438 0.203125H15.1562C14.6875 0.203125 14.2812 0.375 13.9375 0.71875C13.625 1.0625 13.4688 1.46875 13.4688 1.9375V7.04688H11.0781C10.9531 6.70312 10.75 6.4375 10.4688 6.25C10.1875 6.03125 9.85938 5.92188 9.48438 5.92188H6.0625C5.6875 5.92188 5.35938 6.03125 5.07812 6.25C4.79688 6.4375 4.59375 6.70312 4.46875 7.04688H2.64062C2.17188 7.04688 1.76562 7.21875 1.42188 7.5625C1.10938 7.875 0.953125 8.26562 0.953125 8.73438V36.0625C0.953125 36.5312 1.10938 36.9375 1.42188 37.2812C1.76562 37.625 2.17188 37.7969 2.64062 37.7969H41.3594C41.8281 37.7969 42.2188 37.625 42.5312 37.2812C42.875 36.9375 43.0469 36.5312 43.0469 36.0625V8.73438C43.0469 8.26562 42.875 7.875 42.5312 7.5625C42.2188 7.21875 41.8281 7.04688 41.3594 7.04688ZM16.8906 3.625H27.1094V7.04688H16.8906V3.625ZM39.625 34.375H4.375V21.8594H16.8906V23.5469C16.8906 24.0156 17.0469 24.4219 17.3594 24.7656C17.7031 25.1094 18.1094 25.2812 18.5781 25.2812H25.4219C25.8906 25.2812 26.2812 25.1094 26.5938 24.7656C26.9375 24.4219 27.1094 24.0156 27.1094 23.5469V21.8594H39.625V34.375ZM20.3125 21.8594V18.4375H23.6875V21.8594H20.3125ZM39.625 18.4375H27.1094V16.7031C27.1094 16.2344 26.9375 15.8438 26.5938 15.5312C26.2812 15.1875 25.8906 15.0156 25.4219 15.0156H18.5781C18.1094 15.0156 17.7031 15.1875 17.3594 15.5312C17.0469 15.8438 16.8906 16.2344 16.8906 16.7031V18.4375H4.375V10.4688H39.625V18.4375Z" /></svg>'),
        array('icon-booking-grad','<svg class="icon icon-booking-grad" width="44" height="38" viewBox="0 0 44 38" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M41.3594 7.04736H39.5312C39.4375 6.70361 39.2344 6.43799 38.9219 6.25049C38.6406 6.03174 38.3125 5.92236 37.9375 5.92236H34.5156C34.1406 5.92236 33.8125 6.03174 33.5312 6.25049C33.25 6.43799 33.0469 6.70361 32.9219 7.04736H30.5312V1.93799C30.5312 1.46924 30.3594 1.06299 30.0156 0.719238C29.7031 0.375488 29.3125 0.203613 28.8438 0.203613H15.1562C14.6875 0.203613 14.2812 0.375488 13.9375 0.719238C13.625 1.06299 13.4688 1.46924 13.4688 1.93799V7.04736H11.0781C10.9531 6.70361 10.75 6.43799 10.4688 6.25049C10.1875 6.03174 9.85938 5.92236 9.48438 5.92236H6.0625C5.6875 5.92236 5.35938 6.03174 5.07812 6.25049C4.79688 6.43799 4.59375 6.70361 4.46875 7.04736H2.64062C2.17188 7.04736 1.76562 7.21924 1.42188 7.56299C1.10938 7.87549 0.953125 8.26611 0.953125 8.73486V36.063C0.953125 36.5317 1.10938 36.938 1.42188 37.2817C1.76562 37.6255 2.17188 37.7974 2.64062 37.7974H41.3594C41.8281 37.7974 42.2188 37.6255 42.5312 37.2817C42.875 36.938 43.0469 36.5317 43.0469 36.063V8.73486C43.0469 8.26611 42.875 7.87549 42.5312 7.56299C42.2188 7.21924 41.8281 7.04736 41.3594 7.04736ZM16.8906 3.62549H27.1094V7.04736H16.8906V3.62549ZM39.625 34.3755H4.375V21.8599H16.8906V23.5474C16.8906 24.0161 17.0469 24.4224 17.3594 24.7661C17.7031 25.1099 18.1094 25.2817 18.5781 25.2817H25.4219C25.8906 25.2817 26.2812 25.1099 26.5938 24.7661C26.9375 24.4224 27.1094 24.0161 27.1094 23.5474V21.8599H39.625V34.3755ZM20.3125 21.8599V18.438H23.6875V21.8599H20.3125ZM39.625 18.438H27.1094V16.7036C27.1094 16.2349 26.9375 15.8442 26.5938 15.5317C26.2812 15.188 25.8906 15.0161 25.4219 15.0161H18.5781C18.1094 15.0161 17.7031 15.188 17.3594 15.5317C17.0469 15.8442 16.8906 16.2349 16.8906 16.7036V18.438H4.375V10.4692H39.625V18.438Z" fill="url(#paint0_linear)"/><defs><linearGradient id="paint0_linear" x1="47.1114" y1="20.4684" x2="-2.00233" y2="20.4684" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient></defs></svg>'),
        array('icon-calendar','<svg class="icon icon-calendar" width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M17.6562 1.5625H16.7188V0H15.1562V1.5625H4.84375V0H3.28125V1.5625H2.34375C1.05141 1.5625 0 2.61391 0 3.90625V17.6562C0 18.9486 1.05141 20 2.34375 20H17.6562C18.9486 20 20 18.9486 20 17.6562V3.90625C20 2.61391 18.9486 1.5625 17.6562 1.5625ZM18.4375 17.6562C18.4375 18.087 18.087 18.4375 17.6562 18.4375H2.34375C1.91297 18.4375 1.5625 18.087 1.5625 17.6562V7.34375H18.4375V17.6562ZM18.4375 5.78125H1.5625V3.90625C1.5625 3.47547 1.91297 3.125 2.34375 3.125H3.28125V4.6875H4.84375V3.125H15.1562V4.6875H16.7188V3.125H17.6562C18.087 3.125 18.4375 3.47547 18.4375 3.90625V5.78125Z" /><path d="M4.53125 8.98438H2.96875V10.5469H4.53125V8.98438Z" /><path d="M7.65625 8.98438H6.09375V10.5469H7.65625V8.98438Z" /><path d="M10.7812 8.98438H9.21875V10.5469H10.7812V8.98438Z" /><path d="M13.9062 8.98438H12.3438V10.5469H13.9062V8.98438Z" /><path d="M17.0312 8.98438H15.4688V10.5469H17.0312V8.98438Z" /><path d="M4.53125 12.1094H2.96875V13.6719H4.53125V12.1094Z" /><path d="M7.65625 12.1094H6.09375V13.6719H7.65625V12.1094Z" /><path d="M10.7812 12.1094H9.21875V13.6719H10.7812V12.1094Z" /><path d="M13.9062 12.1094H12.3438V13.6719H13.9062V12.1094Z" /><path d="M4.53125 15.2344H2.96875V16.7969H4.53125V15.2344Z" /><path d="M7.65625 15.2344H6.09375V16.7969H7.65625V15.2344Z" /><path d="M10.7812 15.2344H9.21875V16.7969H10.7812V15.2344Z" /><path d="M13.9062 15.2344H12.3438V16.7969H13.9062V15.2344Z" /><path d="M17.0312 12.1094H15.4688V13.6719H17.0312V12.1094Z" /></svg>'),
        array('icon-cart','<svg class="icon icon-cart" width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M23.8128 4.96444C23.6358 4.72814 23.3578 4.58906 23.0625 4.58906H5.40389L4.88906 2.83036C4.77211 2.4308 4.40569 2.15625 3.98934 2.15625H0.9375C0.419719 2.15625 0 2.57597 0 3.09375C0 3.61153 0.419719 4.03125 0.9375 4.03125H3.28692C3.42384 4.49902 6.88678 16.3287 7.02666 16.8066C7.14361 17.2061 7.51008 17.4807 7.92637 17.4807H19.8376C20.254 17.4807 20.6204 17.2061 20.7374 16.8066L23.9622 5.78995C24.0452 5.50664 23.9898 5.20073 23.8128 4.96444ZM19.1353 15.6057H8.6288L5.9528 6.46406H21.8113L19.1353 15.6057Z" /><path d="M9.35742 21.8438C10.0564 21.8438 10.623 21.2771 10.623 20.5781C10.623 19.8791 10.0564 19.3125 9.35742 19.3125C8.65844 19.3125 8.0918 19.8791 8.0918 20.5781C8.0918 21.2771 8.65844 21.8438 9.35742 21.8438Z" /><path d="M18.4062 21.8438C19.1052 21.8438 19.6719 21.2771 19.6719 20.5781C19.6719 19.8791 19.1052 19.3125 18.4062 19.3125C17.7073 19.3125 17.1406 19.8791 17.1406 20.5781C17.1406 21.2771 17.7073 21.8438 18.4062 21.8438Z"/></svg>'),
        array('icon-close','<svg class="icon icon-close" width="20" height="21" viewBox="0 0 20 21" xmlns="http://www.w3.org/2000/svg"><path d="M9.04297 10.1921L0.195312 19.0398C0.0651042 19.157 0 19.3002 0 19.4695C0 19.6518 0.0651042 19.8015 0.195312 19.9187C0.260417 19.9838 0.325521 20.0294 0.390625 20.0554C0.46875 20.0945 0.553385 20.114 0.644531 20.114C0.722656 20.114 0.800781 20.0945 0.878906 20.0554C0.957031 20.0294 1.02214 19.9838 1.07422 19.9187L10 11.0125L18.9258 19.9187C18.9779 19.9838 19.043 20.0294 19.1211 20.0554C19.1992 20.0945 19.2773 20.114 19.3555 20.114C19.4466 20.114 19.5312 20.0945 19.6094 20.0554C19.6875 20.0294 19.7526 19.9838 19.8047 19.9187C19.9349 19.8015 20 19.6518 20 19.4695C20 19.3002 19.9349 19.157 19.8047 19.0398L10.957 10.1921L19.8242 1.32495C19.9414 1.20776 20 1.06453 20 0.895264C20 0.712972 19.9414 0.556722 19.8242 0.426514C19.694 0.309326 19.5378 0.250732 19.3555 0.250732C19.1862 0.250732 19.043 0.309326 18.9258 0.426514L10 9.35229L1.07422 0.426514C0.957031 0.309326 0.807292 0.250732 0.625 0.250732C0.455729 0.250732 0.30599 0.309326 0.175781 0.426514C0.0585938 0.556722 0 0.712972 0 0.895264C0 1.06453 0.0585938 1.20776 0.175781 1.32495L9.04297 10.1921Z" /></svg>'),
        array('icon-comments','<svg class="icon icon-comments" width="13" height="14" viewBox="0 0 13 14" xmlns="http://www.w3.org/2000/svg"><path d="M11.3623 0.8125H1.6377C1.19759 0.8125 0.820964 0.969076 0.507812 1.28223C0.203125 1.58691 0.0507812 1.95508 0.0507812 2.38672V8.77246C0.0507812 9.21257 0.203125 9.58919 0.507812 9.90234C0.820964 10.207 1.19759 10.3594 1.6377 10.3594H6.96973V13.4316C6.96973 13.5078 6.99089 13.5798 7.0332 13.6475C7.07552 13.7152 7.13477 13.7617 7.21094 13.7871C7.23633 13.7956 7.25749 13.7998 7.27441 13.7998C7.2998 13.8083 7.3252 13.8125 7.35059 13.8125C7.40137 13.8125 7.45215 13.7998 7.50293 13.7744C7.55371 13.7575 7.60026 13.7279 7.64258 13.6855L10.5244 10.3594H11.3623C11.8024 10.3594 12.1748 10.207 12.4795 9.90234C12.7926 9.58919 12.9492 9.21257 12.9492 8.77246V2.38672C12.9492 1.95508 12.7926 1.58691 12.4795 1.28223C12.1748 0.969076 11.8024 0.8125 11.3623 0.8125ZM12.1748 8.77246C12.1748 9.00098 12.0944 9.19564 11.9336 9.35645C11.7812 9.50879 11.5908 9.58496 11.3623 9.58496C11.3623 9.58496 11.1973 9.58496 10.8672 9.58496C10.5371 9.58496 10.3678 9.58496 10.3594 9.58496C10.3001 9.58496 10.2451 9.59766 10.1943 9.62305C10.1436 9.63997 10.097 9.6696 10.0547 9.71191L7.73145 12.3906V9.96582C7.73145 9.86426 7.69336 9.77539 7.61719 9.69922C7.54102 9.62305 7.45215 9.58496 7.35059 9.58496H1.6377C1.40918 9.58496 1.21452 9.50879 1.05371 9.35645C0.901367 9.19564 0.825195 9.00098 0.825195 8.77246V2.38672C0.825195 2.16667 0.901367 1.98047 1.05371 1.82812C1.21452 1.66732 1.40918 1.58691 1.6377 1.58691H11.3623C11.5908 1.58691 11.7812 1.66732 11.9336 1.82812C12.0944 1.98047 12.1748 2.16667 12.1748 2.38672V8.77246ZM10.8164 3.35156H2.18359C2.07357 3.35156 1.98047 3.38965 1.9043 3.46582C1.82812 3.54199 1.79004 3.63509 1.79004 3.74512C1.79004 3.84668 1.82812 3.93555 1.9043 4.01172C1.98047 4.08789 2.07357 4.12598 2.18359 4.12598H10.8164C10.9264 4.12598 11.0195 4.08789 11.0957 4.01172C11.1719 3.93555 11.21 3.84668 11.21 3.74512C11.21 3.63509 11.1719 3.54199 11.0957 3.46582C11.0195 3.38965 10.9264 3.35156 10.8164 3.35156ZM10.8164 5.19238H2.18359C2.07357 5.19238 1.98047 5.23047 1.9043 5.30664C1.82812 5.38281 1.79004 5.47591 1.79004 5.58594C1.79004 5.6875 1.82812 5.77637 1.9043 5.85254C1.98047 5.92871 2.07357 5.9668 2.18359 5.9668H10.8164C10.9264 5.9668 11.0195 5.92871 11.0957 5.85254C11.1719 5.77637 11.21 5.6875 11.21 5.58594C11.21 5.47591 11.1719 5.38281 11.0957 5.30664C11.0195 5.23047 10.9264 5.19238 10.8164 5.19238ZM6.27148 7.0459H2.18359C2.07357 7.0459 1.98047 7.08398 1.9043 7.16016C1.82812 7.22786 1.79004 7.31673 1.79004 7.42676C1.79004 7.53678 1.82812 7.62988 1.9043 7.70605C1.98047 7.77376 2.07357 7.80762 2.18359 7.80762H6.27148C6.37305 7.80762 6.46191 7.77376 6.53809 7.70605C6.61426 7.62988 6.65234 7.53678 6.65234 7.42676C6.65234 7.31673 6.61426 7.22786 6.53809 7.16016C6.46191 7.08398 6.37305 7.0459 6.27148 7.0459Z" /></svg>'),
        array('icon-corevalues','<svg class="icon icon-corevalues" width="54" height="54" viewBox="0 0 54 54" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M53.0103 1.76132C52.9143 1.39174 52.626 1.10306 52.2566 1.00634L52.2423 1.00255C47.0412 -0.35806 41.5495 -0.333695 36.3606 1.07321C31.8971 2.28341 27.7574 4.49044 24.2674 7.50339C20.9382 6.68502 17.4402 6.72162 14.1283 7.61762C10.7124 8.54156 7.58437 10.3525 5.08213 12.8546L0.309881 17.627C-0.101992 18.0389 -0.101992 18.7068 0.309881 19.1187L6.42206 25.2309L0.309881 31.3431C-0.101992 31.755 -0.101992 32.4228 0.309881 32.8348C0.515871 33.0407 0.785777 33.1437 1.05568 33.1437C1.32559 33.1437 1.5956 33.0407 1.80148 32.8348L7.91366 26.7226L9.59058 28.3995L6.76706 31.2232C6.35519 31.635 6.35519 32.3029 6.76706 32.7149L8.64934 34.5972C5.77751 37.8421 4.16535 42.104 4.19752 46.4508L4.2144 48.7177C4.21872 49.2941 4.68481 49.7603 5.26122 49.7646L7.52805 49.7814C7.57077 49.7817 7.61327 49.7818 7.65599 49.7818C11.9582 49.7818 16.1686 48.1733 19.3817 45.3296L21.3477 47.2956C21.5455 47.4934 21.8138 47.6045 22.0935 47.6045C22.3732 47.6045 22.6415 47.4934 22.8393 47.2956L25.6628 44.472L34.8599 53.669C35.0659 53.8749 35.3358 53.978 35.6057 53.978C35.8756 53.978 36.1456 53.8749 36.3515 53.669L41.2427 48.7779C43.7117 46.3089 45.5103 43.2253 46.4443 39.8609C47.3746 36.5097 47.4253 32.9554 46.5926 29.5788C49.5515 26.1183 51.7223 22.027 52.921 17.6196C54.3299 12.44 54.3607 6.9563 53.0103 1.76132ZM6.57383 14.3463C10.7228 10.1974 16.6526 8.32714 22.3844 9.26838L7.91366 23.7392L2.54729 18.3729L6.57383 14.3463ZM7.65652 47.6723C7.61918 47.6723 7.58121 47.6721 7.54387 47.6718L6.31616 47.6628L6.30699 46.435C6.27893 42.6494 7.66706 38.9369 10.1439 36.0914L17.8874 43.8349C15.0701 46.2874 11.4031 47.6723 7.65652 47.6723ZM22.0937 45.0579L10.8635 33.8278C10.8637 33.8279 10.8634 33.8277 10.8635 33.8278C10.8633 33.8277 10.8628 33.8272 10.8627 33.827L9.00457 31.9689L11.0823 29.8911L24.1714 42.9803L22.0937 45.0579ZM39.7514 47.2861L35.606 51.4314L30.2397 46.0652L44.8283 31.4766C45.7662 37.2041 43.888 43.1495 39.7514 47.2861ZM43.4747 29.8468L28.748 44.5735L28.5791 44.4046C28.5794 44.4048 28.5789 44.4044 28.5791 44.4046L9.40526 25.2308L12.3409 22.2952L26.4635 36.4178C26.6694 36.6237 26.9394 36.7268 27.2093 36.7268C27.4792 36.7268 27.7492 36.6237 27.9551 36.4178C28.3669 36.006 28.3669 35.3381 27.9551 34.9261L13.8326 20.8035L24.11 10.526C31.155 3.48117 41.4527 0.586559 51.1186 2.89579C53.4024 12.544 50.5032 22.8182 43.4747 29.8468Z" fill="url(#paint0_linear)"/><path d="M34.0789 9.60241C31.3221 9.60241 28.7305 10.676 26.7812 12.6253C24.8318 14.5745 23.7583 17.1663 23.7583 19.923C23.7583 22.6798 24.8318 25.2715 26.7812 27.2208C28.7306 29.17 31.3223 30.2436 34.079 30.2436C36.8358 30.2436 39.4275 29.17 41.3768 27.2208C45.4008 23.1968 45.4008 16.6493 41.3768 12.6252C39.4273 10.676 36.8355 9.60241 34.0789 9.60241ZM25.9171 20.8169C27.2519 20.5243 28.6565 20.9185 29.6479 21.91L32.1524 24.4146C33.1278 25.39 33.5264 26.7743 33.2564 28.0938C31.3738 27.9077 29.628 27.0847 28.2727 25.7293C26.9346 24.391 26.1167 22.672 25.9171 20.8169ZM31.805 20.2538C31.805 19.7187 32.0134 19.2155 32.3918 18.837L32.9325 18.2964C33.3109 17.9179 33.8141 17.7096 34.3492 17.7096C34.8844 17.7096 35.3875 17.918 35.7659 18.2965C36.1444 18.6749 36.3527 19.1779 36.3527 19.7132C36.3527 20.2485 36.1443 20.7515 35.7659 21.1299L35.2254 21.6706C34.4443 22.4517 33.1735 22.4518 32.3922 21.6708C32.0138 21.2924 31.805 20.7889 31.805 20.2538ZM39.8851 25.7293C38.6517 26.9627 37.0947 27.7535 35.4059 28.0264C35.5642 26.7282 35.3041 25.4137 34.6662 24.2742C35.4181 24.115 36.1341 23.7451 36.7169 23.1623L37.2574 22.6216C38.0344 21.8448 38.4622 20.812 38.4622 19.7134C38.4622 18.6148 38.0344 17.5819 37.2575 16.8052C36.4807 16.0283 35.4478 15.6004 34.3492 15.6004C33.2506 15.6004 32.2177 16.0283 31.441 16.8051L30.9003 17.3456C30.3304 17.9156 29.9493 18.6235 29.7861 19.3938C28.625 18.7433 27.2848 18.4865 25.9639 18.6649C26.2262 16.9496 27.0226 15.3672 28.2728 14.1171C29.8237 12.5661 31.8857 11.712 34.0789 11.712C36.2722 11.712 38.3342 12.5661 39.8851 14.1171C43.0866 17.3184 43.0866 22.5277 39.8851 25.7293Z" fill="url(#paint0_linear)"/><path d="M30.1923 37.6005C29.915 37.6005 29.6428 37.7124 29.4467 37.9096C29.2505 38.1057 29.1376 38.3778 29.1376 38.6552C29.1376 38.9327 29.2505 39.2048 29.4467 39.4009C29.6428 39.597 29.915 39.7099 30.1923 39.7099C30.4697 39.7099 30.7418 39.5971 30.938 39.4009C31.1342 39.2048 31.247 38.9327 31.247 38.6552C31.247 38.3778 31.1342 38.1057 30.938 37.9096C30.7418 37.7124 30.4697 37.6005 30.1923 37.6005Z" fill="url(#paint2_linear)"/><path d="M17.5508 49.6005L14.963 52.1883C14.5511 52.6002 14.5511 53.268 14.963 53.68C15.169 53.8859 15.4389 53.9889 15.7088 53.9889C15.9787 53.9889 16.2487 53.8859 16.4546 53.68L19.0424 51.0922C19.4543 50.6803 19.4543 50.0125 19.0424 49.6005C18.6305 49.1886 17.9627 49.1886 17.5508 49.6005Z" fill="url(#paint3_linear)"/><defs><linearGradient id="paint0_linear" x1="54.1237" y1="28.7955" x2="-0.00159143" y2="28.7955" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint1_linear" x1="54.1237" y1="28.7955" x2="-0.00159143" y2="28.7955" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint2_linear" x1="54.1237" y1="28.7955" x2="-0.00159143" y2="28.7955" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint3_linear" x1="54.1237" y1="28.7955" x2="-0.00159143" y2="28.7955" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient></defs></svg>'),
        array('icon-equalizer1','<svg class="icon icon-equalizer" width="24" height="25" viewBox="0 0 24 25" xmlns="http://www.w3.org/2000/svg"><path d="M12.7031 12.1953V1.17969C12.7031 0.992188 12.6328 0.835938 12.4922 0.710938C12.3672 0.570312 12.2109 0.5 12.0234 0.5C11.8359 0.5 11.6719 0.570312 11.5312 0.710938C11.4062 0.835938 11.3438 0.992188 11.3438 1.17969V12.1953C10.5625 12.3516 9.90625 12.7422 9.375 13.3672C8.85938 13.9922 8.60156 14.7188 8.60156 15.5469C8.60156 16.375 8.85938 17.1094 9.375 17.75C9.90625 18.375 10.5625 18.7656 11.3438 18.9219V23.8203C11.3438 24.0078 11.4062 24.1641 11.5312 24.2891C11.6719 24.4297 11.8359 24.5 12.0234 24.5C12.2109 24.5 12.3672 24.4297 12.4922 24.2891C12.6328 24.1641 12.7031 24.0078 12.7031 23.8203V18.9219C13.4844 18.7656 14.1328 18.375 14.6484 17.75C15.1797 17.1094 15.4453 16.375 15.4453 15.5469C15.4453 14.7188 15.1797 13.9922 14.6484 13.3672C14.1328 12.7422 13.4844 12.3516 12.7031 12.1953ZM12.0234 17.6328C11.4453 17.6328 10.9531 17.4297 10.5469 17.0234C10.1562 16.6172 9.96094 16.125 9.96094 15.5469C9.96094 14.9844 10.1562 14.5 10.5469 14.0938C10.9531 13.6875 11.4453 13.4844 12.0234 13.4844C12.6016 13.4844 13.0938 13.6875 13.5 14.0938C13.9062 14.5 14.1094 14.9844 14.1094 15.5469C14.1094 16.125 13.9062 16.6172 13.5 17.0234C13.0938 17.4297 12.6016 17.6328 12.0234 17.6328ZM4.42969 6.54688V1.17969C4.42969 0.992188 4.36719 0.835938 4.24219 0.710938C4.11719 0.570312 3.96094 0.5 3.77344 0.5C3.58594 0.5 3.42188 0.570312 3.28125 0.710938C3.15625 0.835938 3.09375 0.992188 3.09375 1.17969V6.54688C2.3125 6.70312 1.65625 7.09375 1.125 7.71875C0.609375 8.34375 0.351562 9.07031 0.351562 9.89844C0.351562 10.7266 0.609375 11.4531 1.125 12.0781C1.65625 12.7031 2.3125 13.0938 3.09375 13.25V23.8203C3.09375 24.0078 3.15625 24.1641 3.28125 24.2891C3.42188 24.4297 3.58594 24.5 3.77344 24.5C3.96094 24.5 4.11719 24.4297 4.24219 24.2891C4.36719 24.1641 4.42969 24.0078 4.42969 23.8203V13.25C5.21094 13.0938 5.86719 12.7031 6.39844 12.0781C6.92969 11.4531 7.19531 10.7266 7.19531 9.89844C7.19531 9.07031 6.92969 8.34375 6.39844 7.71875C5.86719 7.09375 5.21094 6.70312 4.42969 6.54688ZM3.77344 11.9844C3.19531 11.9844 2.70312 11.7812 2.29688 11.375C1.89062 10.9688 1.6875 10.4766 1.6875 9.89844C1.6875 9.32031 1.89062 8.83594 2.29688 8.44531C2.70312 8.03906 3.19531 7.83594 3.77344 7.83594C4.33594 7.83594 4.82031 8.03906 5.22656 8.44531C5.63281 8.83594 5.83594 9.32031 5.83594 9.89844C5.83594 10.4766 5.63281 10.9688 5.22656 11.375C4.82031 11.7812 4.33594 11.9844 3.77344 11.9844ZM20.9062 6.54688V1.17969C20.9062 0.992188 20.8359 0.835938 20.6953 0.710938C20.5703 0.570312 20.4141 0.5 20.2266 0.5C20.0391 0.5 19.8828 0.570312 19.7578 0.710938C19.6328 0.835938 19.5703 0.992188 19.5703 1.17969V6.54688C18.7891 6.70312 18.1328 7.09375 17.6016 7.71875C17.0703 8.34375 16.8047 9.07031 16.8047 9.89844C16.8047 10.7266 17.0703 11.4531 17.6016 12.0781C18.1328 12.7031 18.7891 13.0938 19.5703 13.25V23.8203C19.5703 24.0078 19.6328 24.1641 19.7578 24.2891C19.8828 24.4297 20.0391 24.5 20.2266 24.5C20.4141 24.5 20.5703 24.4297 20.6953 24.2891C20.8359 24.1641 20.9062 24.0078 20.9062 23.8203V13.25C21.6875 13.0938 22.3359 12.7031 22.8516 12.0781C23.3828 11.4531 23.6484 10.7266 23.6484 9.89844C23.6484 9.07031 23.3828 8.34375 22.8516 7.71875C22.3359 7.09375 21.6875 6.70312 20.9062 6.54688ZM20.2266 11.9844C19.6641 11.9844 19.1797 11.7812 18.7734 11.375C18.3672 10.9688 18.1641 10.4766 18.1641 9.89844C18.1641 9.32031 18.3672 8.83594 18.7734 8.44531C19.1797 8.03906 19.6641 7.83594 20.2266 7.83594C20.8047 7.83594 21.2969 8.03906 21.7031 8.44531C22.1094 8.83594 22.3125 9.32031 22.3125 9.89844C22.3125 10.4766 22.1094 10.9688 21.7031 11.375C21.2969 11.7812 20.8047 11.9844 20.2266 11.9844Z"/></svg>'),
        array('icon-equalizer-grad','<svg class="icon icon-equalizer-grad" width="52" height="53" viewBox="0 0 52 53" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M27.5234 25.5903V1.72314C27.5234 1.31689 27.3711 0.978353 27.0664 0.70752C26.7956 0.402832 26.457 0.250488 26.0508 0.250488C25.6445 0.250488 25.2891 0.402832 24.9844 0.70752C24.7135 0.978353 24.5781 1.31689 24.5781 1.72314V25.5903C22.8854 25.9289 21.4635 26.7752 20.3125 28.1294C19.1953 29.4836 18.6367 31.0578 18.6367 32.8521C18.6367 34.6463 19.1953 36.2375 20.3125 37.6255C21.4635 38.9797 22.8854 39.826 24.5781 40.1646V50.7778C24.5781 51.1841 24.7135 51.5226 24.9844 51.7935C25.2891 52.0981 25.6445 52.2505 26.0508 52.2505C26.457 52.2505 26.7956 52.0981 27.0664 51.7935C27.3711 51.5226 27.5234 51.1841 27.5234 50.7778V40.1646C29.2161 39.826 30.6211 38.9797 31.7383 37.6255C32.8893 36.2375 33.4648 34.6463 33.4648 32.8521C33.4648 31.0578 32.8893 29.4836 31.7383 28.1294C30.6211 26.7752 29.2161 25.9289 27.5234 25.5903ZM26.0508 37.3716C24.7982 37.3716 23.7318 36.9315 22.8516 36.0513C22.0052 35.1711 21.582 34.1047 21.582 32.8521C21.582 31.6333 22.0052 30.5838 22.8516 29.7036C23.7318 28.8234 24.7982 28.3833 26.0508 28.3833C27.3034 28.3833 28.3698 28.8234 29.25 29.7036C30.1302 30.5838 30.5703 31.6333 30.5703 32.8521C30.5703 34.1047 30.1302 35.1711 29.25 36.0513C28.3698 36.9315 27.3034 37.3716 26.0508 37.3716ZM9.59766 13.3521V1.72314C9.59766 1.31689 9.46224 0.978353 9.19141 0.70752C8.92057 0.402832 8.58203 0.250488 8.17578 0.250488C7.76953 0.250488 7.41406 0.402832 7.10938 0.70752C6.83854 0.978353 6.70312 1.31689 6.70312 1.72314V13.3521C5.01042 13.6906 3.58854 14.5369 2.4375 15.8911C1.32031 17.2453 0.761719 18.8195 0.761719 20.6138C0.761719 22.408 1.32031 23.9823 2.4375 25.3364C3.58854 26.6906 5.01042 27.5369 6.70312 27.8755V50.7778C6.70312 51.1841 6.83854 51.5226 7.10938 51.7935C7.41406 52.0981 7.76953 52.2505 8.17578 52.2505C8.58203 52.2505 8.92057 52.0981 9.19141 51.7935C9.46224 51.5226 9.59766 51.1841 9.59766 50.7778V27.8755C11.2904 27.5369 12.7122 26.6906 13.8633 25.3364C15.0143 23.9823 15.5898 22.408 15.5898 20.6138C15.5898 18.8195 15.0143 17.2453 13.8633 15.8911C12.7122 14.5369 11.2904 13.6906 9.59766 13.3521ZM8.17578 25.1333C6.92318 25.1333 5.85677 24.6932 4.97656 23.813C4.09635 22.9328 3.65625 21.8664 3.65625 20.6138C3.65625 19.3612 4.09635 18.3117 4.97656 17.4653C5.85677 16.5851 6.92318 16.145 8.17578 16.145C9.39453 16.145 10.444 16.5851 11.3242 17.4653C12.2044 18.3117 12.6445 19.3612 12.6445 20.6138C12.6445 21.8664 12.2044 22.9328 11.3242 23.813C10.444 24.6932 9.39453 25.1333 8.17578 25.1333ZM45.2969 13.3521V1.72314C45.2969 1.31689 45.1445 0.978353 44.8398 0.70752C44.569 0.402832 44.2305 0.250488 43.8242 0.250488C43.418 0.250488 43.0794 0.402832 42.8086 0.70752C42.5378 0.978353 42.4023 1.31689 42.4023 1.72314V13.3521C40.7096 13.6906 39.2878 14.5369 38.1367 15.8911C36.9857 17.2453 36.4102 18.8195 36.4102 20.6138C36.4102 22.408 36.9857 23.9823 38.1367 25.3364C39.2878 26.6906 40.7096 27.5369 42.4023 27.8755V50.7778C42.4023 51.1841 42.5378 51.5226 42.8086 51.7935C43.0794 52.0981 43.418 52.2505 43.8242 52.2505C44.2305 52.2505 44.569 52.0981 44.8398 51.7935C45.1445 51.5226 45.2969 51.1841 45.2969 50.7778V27.8755C46.9896 27.5369 48.3945 26.6906 49.5117 25.3364C50.6628 23.9823 51.2383 22.408 51.2383 20.6138C51.2383 18.8195 50.6628 17.2453 49.5117 15.8911C48.3945 14.5369 46.9896 13.6906 45.2969 13.3521ZM43.8242 25.1333C42.6055 25.1333 41.556 24.6932 40.6758 23.813C39.7956 22.9328 39.3555 21.8664 39.3555 20.6138C39.3555 19.3612 39.7956 18.3117 40.6758 17.4653C41.556 16.5851 42.6055 16.145 43.8242 16.145C45.0768 16.145 46.1432 16.5851 47.0234 17.4653C47.9036 18.3117 48.3438 19.3612 48.3438 20.6138C48.3438 21.8664 47.9036 22.9328 47.0234 23.813C46.1432 24.6932 45.0768 25.1333 43.8242 25.1333Z" fill="url(#paint0_linear)"/><defs><linearGradient id="paint0_linear" x1="53.1228" y1="27.9355" x2="-1.00257" y2="27.9355" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient></defs></svg>'),
        array('icon-equalizer-trans','<svg class="icon icon-equalizer-trans" width="35" height="37" viewBox="0 0 35 37" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M18.5547 17.793V1.26953C18.5547 0.988281 18.4492 0.753906 18.2383 0.566406C18.0508 0.355469 17.8164 0.25 17.5352 0.25C17.2539 0.25 17.0078 0.355469 16.7969 0.566406C16.6094 0.753906 16.5156 0.988281 16.5156 1.26953V17.793C15.3438 18.0273 14.3594 18.6133 13.5625 19.5508C12.7891 20.4883 12.4023 21.5781 12.4023 22.8203C12.4023 24.0625 12.7891 25.1641 13.5625 26.125C14.3594 27.0625 15.3438 27.6484 16.5156 27.8828V35.2305C16.5156 35.5117 16.6094 35.7461 16.7969 35.9336C17.0078 36.1445 17.2539 36.25 17.5352 36.25C17.8164 36.25 18.0508 36.1445 18.2383 35.9336C18.4492 35.7461 18.5547 35.5117 18.5547 35.2305V27.8828C19.7266 27.6484 20.6992 27.0625 21.4727 26.125C22.2695 25.1641 22.668 24.0625 22.668 22.8203C22.668 21.5781 22.2695 20.4883 21.4727 19.5508C20.6992 18.6133 19.7266 18.0273 18.5547 17.793ZM17.5352 25.9492C16.668 25.9492 15.9297 25.6445 15.3203 25.0352C14.7344 24.4258 14.4414 23.6875 14.4414 22.8203C14.4414 21.9766 14.7344 21.25 15.3203 20.6406C15.9297 20.0312 16.668 19.7266 17.5352 19.7266C18.4023 19.7266 19.1406 20.0312 19.75 20.6406C20.3594 21.25 20.6641 21.9766 20.6641 22.8203C20.6641 23.6875 20.3594 24.4258 19.75 25.0352C19.1406 25.6445 18.4023 25.9492 17.5352 25.9492ZM6.14453 9.32031V1.26953C6.14453 0.988281 6.05078 0.753906 5.86328 0.566406C5.67578 0.355469 5.44141 0.25 5.16016 0.25C4.87891 0.25 4.63281 0.355469 4.42188 0.566406C4.23438 0.753906 4.14062 0.988281 4.14062 1.26953V9.32031C2.96875 9.55469 1.98438 10.1406 1.1875 11.0781C0.414062 12.0156 0.0273438 13.1055 0.0273438 14.3477C0.0273438 15.5898 0.414062 16.6797 1.1875 17.6172C1.98438 18.5547 2.96875 19.1406 4.14062 19.375V35.2305C4.14062 35.5117 4.23438 35.7461 4.42188 35.9336C4.63281 36.1445 4.87891 36.25 5.16016 36.25C5.44141 36.25 5.67578 36.1445 5.86328 35.9336C6.05078 35.7461 6.14453 35.5117 6.14453 35.2305V19.375C7.31641 19.1406 8.30078 18.5547 9.09766 17.6172C9.89453 16.6797 10.293 15.5898 10.293 14.3477C10.293 13.1055 9.89453 12.0156 9.09766 11.0781C8.30078 10.1406 7.31641 9.55469 6.14453 9.32031ZM5.16016 17.4766C4.29297 17.4766 3.55469 17.1719 2.94531 16.5625C2.33594 15.9531 2.03125 15.2148 2.03125 14.3477C2.03125 13.4805 2.33594 12.7539 2.94531 12.168C3.55469 11.5586 4.29297 11.2539 5.16016 11.2539C6.00391 11.2539 6.73047 11.5586 7.33984 12.168C7.94922 12.7539 8.25391 13.4805 8.25391 14.3477C8.25391 15.2148 7.94922 15.9531 7.33984 16.5625C6.73047 17.1719 6.00391 17.4766 5.16016 17.4766ZM30.8594 9.32031V1.26953C30.8594 0.988281 30.7539 0.753906 30.543 0.566406C30.3555 0.355469 30.1211 0.25 29.8398 0.25C29.5586 0.25 29.3242 0.355469 29.1367 0.566406C28.9492 0.753906 28.8555 0.988281 28.8555 1.26953V9.32031C27.6836 9.55469 26.6992 10.1406 25.9023 11.0781C25.1055 12.0156 24.707 13.1055 24.707 14.3477C24.707 15.5898 25.1055 16.6797 25.9023 17.6172C26.6992 18.5547 27.6836 19.1406 28.8555 19.375V35.2305C28.8555 35.5117 28.9492 35.7461 29.1367 35.9336C29.3242 36.1445 29.5586 36.25 29.8398 36.25C30.1211 36.25 30.3555 36.1445 30.543 35.9336C30.7539 35.7461 30.8594 35.5117 30.8594 35.2305V19.375C32.0312 19.1406 33.0039 18.5547 33.7773 17.6172C34.5742 16.6797 34.9727 15.5898 34.9727 14.3477C34.9727 13.1055 34.5742 12.0156 33.7773 11.0781C33.0039 10.1406 32.0312 9.55469 30.8594 9.32031ZM29.8398 17.4766C28.9961 17.4766 28.2695 17.1719 27.6602 16.5625C27.0508 15.9531 26.7461 15.2148 26.7461 14.3477C26.7461 13.4805 27.0508 12.7539 27.6602 12.168C28.2695 11.5586 28.9961 11.2539 29.8398 11.2539C30.707 11.2539 31.4453 11.5586 32.0547 12.168C32.6641 12.7539 32.9688 13.4805 32.9688 14.3477C32.9688 15.2148 32.6641 15.9531 32.0547 16.5625C31.4453 17.1719 30.707 17.4766 29.8398 17.4766Z" fill="white"/></svg>'),
        array('icon-facebook','<svg class="icon icon-facebook" width="9" height="19" viewBox="0 0 9 19" xmlns="http://www.w3.org/2000/svg"><path d="M5.88867 6.03125V4.4668C5.88867 4.34961 5.88867 4.25 5.88867 4.16797C5.90039 4.07422 5.91211 3.99805 5.92383 3.93945C5.93555 3.86914 5.95312 3.80469 5.97656 3.74609C6 3.67578 6.0293 3.61133 6.06445 3.55273C6.09961 3.49414 6.14648 3.44727 6.20508 3.41211C6.27539 3.36523 6.35156 3.33008 6.43359 3.30664C6.52734 3.27148 6.62695 3.24805 6.73242 3.23633C6.84961 3.22461 6.97852 3.21875 7.11914 3.21875H8.66602V0.125H6.1875C5.47266 0.125 4.85742 0.212891 4.3418 0.388672C3.82617 0.552734 3.41016 0.804688 3.09375 1.14453C2.78906 1.48438 2.55469 1.90625 2.39062 2.41016C2.23828 2.91406 2.16211 3.49414 2.16211 4.15039V6.03125H0.298828V9.125H2.16211V18.125H5.88867V9.125H8.36719L8.70117 6.03125H5.88867Z"/></svg>'),
        array('icon-googleplus','<svg class="icon icon-googleplus" width="27" height="17" viewBox="0 0 27 17" xmlns="http://www.w3.org/2000/svg"><path d="M9.77344 9.82998H13.6934C13.5176 10.3104 13.2715 10.7558 12.9551 11.1659C12.6504 11.5761 12.293 11.9335 11.8828 12.2382C11.4727 12.5311 11.0156 12.7597 10.5117 12.9237C10.0195 13.0761 9.49805 13.1522 8.94727 13.1522C8.29102 13.1522 7.66406 13.0292 7.06641 12.7831C6.48047 12.5253 5.96484 12.1796 5.51953 11.746C5.07422 11.3124 4.7168 10.8085 4.44727 10.2343C4.17773 9.64833 4.03125 9.02724 4.00781 8.37099C3.98438 7.65615 4.0957 6.98818 4.3418 6.36708C4.59961 5.73427 4.95117 5.18349 5.39648 4.71474C5.85352 4.23427 6.38672 3.85927 6.99609 3.58974C7.61719 3.32021 8.2793 3.18544 8.98242 3.18544C9.62695 3.18544 10.2363 3.30263 10.8105 3.53701C11.3848 3.75966 11.8945 4.07021 12.3398 4.46865C12.4453 4.5624 12.5684 4.60927 12.709 4.60927C12.8496 4.60927 12.9727 4.5624 13.0781 4.46865L14.5195 3.11513C14.625 3.00966 14.6777 2.88076 14.6777 2.72841C14.6777 2.56435 14.625 2.42958 14.5195 2.32412C14.168 1.99599 13.7871 1.69716 13.377 1.42763C12.9668 1.1581 12.5332 0.929585 12.0762 0.742085C11.6309 0.554585 11.1621 0.4081 10.6699 0.302632C10.1777 0.197163 9.67383 0.138569 9.1582 0.12685C8.04492 0.103413 6.99023 0.302632 5.99414 0.724507C5.00977 1.13466 4.14258 1.70302 3.39258 2.42958C2.6543 3.15615 2.0625 4.01162 1.61719 4.99599C1.18359 5.96865 0.960938 7.00576 0.949219 8.10732C0.949219 9.2206 1.1543 10.2694 1.56445 11.2538C1.98633 12.2382 2.56055 13.0995 3.28711 13.8378C4.01367 14.5644 4.86328 15.1444 5.83594 15.578C6.82031 15.9999 7.86914 16.2108 8.98242 16.2108C10.0605 16.2108 11.0742 16.0116 12.0234 15.6132C12.9727 15.2147 13.8047 14.6757 14.5195 13.996C15.2461 13.3163 15.8262 12.5136 16.2598 11.5878C16.7051 10.662 16.957 9.67177 17.0156 8.61708C17.0156 8.59365 17.0156 8.2831 17.0156 7.68544C17.0273 7.07607 17.0332 6.77138 17.0332 6.77138H9.77344C9.62109 6.77138 9.49219 6.82412 9.38672 6.92958C9.28125 7.03505 9.22852 7.16396 9.22852 7.3163V9.28505C9.22852 9.4374 9.28125 9.5663 9.38672 9.67177C9.49219 9.77724 9.62109 9.82998 9.77344 9.82998ZM23.6777 6.94716V5.03115C23.6777 4.90224 23.6309 4.79091 23.5371 4.69716C23.4434 4.60341 23.332 4.55654 23.2031 4.55654H21.5859C21.457 4.55654 21.3457 4.60341 21.252 4.69716C21.1582 4.79091 21.1113 4.90224 21.1113 5.03115V6.94716H19.1777C19.0488 6.94716 18.9375 6.99404 18.8438 7.08779C18.75 7.18154 18.7031 7.29287 18.7031 7.42177V9.05654C18.7031 9.18544 18.75 9.29677 18.8438 9.39052C18.9375 9.47255 19.0488 9.51357 19.1777 9.51357H21.1113V11.4472C21.1113 11.5761 21.1582 11.6874 21.252 11.7811C21.3457 11.8749 21.457 11.9218 21.5859 11.9218H23.2031C23.332 11.9218 23.4434 11.8749 23.5371 11.7811C23.6309 11.6874 23.6777 11.5761 23.6777 11.4472V9.51357H25.6113C25.7402 9.51357 25.8516 9.47255 25.9453 9.39052C26.0391 9.29677 26.0859 9.18544 26.0859 9.05654V7.42177C26.0859 7.29287 26.0391 7.18154 25.9453 7.08779C25.8516 6.99404 25.7402 6.94716 25.6113 6.94716H23.6777Z"/></svg>'),
        array('icon-headphones','<svg class="icon icon-headphones" width="33" height="35" viewBox="0 0 33 35" xmlns="http://www.w3.org/2000/svg"><path d="M27.6094 5.01562C26.8828 4.26562 26.0977 3.60938 25.2539 3.04688C24.4102 2.46094 23.5195 1.96875 22.582 1.57031C21.668 1.17187 20.707 0.878906 19.6992 0.691406C18.6914 0.480469 17.6719 0.375 16.6406 0.375C14.4844 0.351563 12.457 0.75 10.5586 1.57031C8.66016 2.36719 6.99609 3.46875 5.56641 4.875C4.16016 6.28125 3.03516 7.93359 2.19141 9.83203C1.37109 11.707 0.960938 13.7109 0.960938 15.8438L0.890625 25.1953C0.890625 25.5938 1.00781 25.9219 1.24219 26.1797C1.47656 26.4375 1.79297 26.5664 2.19141 26.5664H2.26172C2.63672 26.5664 2.95312 26.4375 3.21094 26.1797C3.46875 25.9219 3.59766 25.5938 3.59766 25.1953L3.73828 15.8438C3.73828 14.1094 4.07812 12.4688 4.75781 10.9219C5.4375 9.375 6.35156 8.02734 7.5 6.87891C8.64844 5.73047 9.99609 4.82812 11.543 4.17188C13.0898 3.49219 14.7422 3.15234 16.5 3.15234C18.2578 3.15234 19.9219 3.49219 21.4922 4.17188C23.0625 4.82812 24.4688 5.76563 25.7109 6.98438C26.9062 8.20312 27.8086 9.59766 28.418 11.168C29.0273 12.7148 29.332 14.3438 29.332 16.0547L29.2617 25.4062C29.2617 25.8047 29.3906 26.1328 29.6484 26.3906C29.9297 26.6484 30.2695 26.7773 30.668 26.7773C31.0195 26.7773 31.3359 26.6367 31.6172 26.3555C31.8984 26.0742 32.0391 25.7578 32.0391 25.4062L32.1094 16.0547C32.1094 15.0234 32.0156 14.0039 31.8281 12.9961C31.6406 11.9883 31.3477 11.0156 30.9492 10.0781C30.5742 9.14063 30.1055 8.25 29.543 7.40625C28.9805 6.53906 28.3359 5.74219 27.6094 5.01562ZM21.5273 16.1953C21.1992 16.1953 20.9062 16.3125 20.6484 16.5469C20.3906 16.7812 20.2617 17.0625 20.2617 17.3906L20.1914 32.8594C20.1914 33.1875 20.3086 33.4805 20.543 33.7383C20.7773 33.9961 21.0586 34.125 21.3867 34.125H21.457C23.8477 34.125 25.4531 33.5625 26.2734 32.4375C27.1172 31.3125 27.5391 30.3516 27.5391 29.5547L27.6094 20.8359C27.6094 20.7656 27.5742 20.4961 27.5039 20.0273C27.457 19.5352 27.2344 19.0078 26.8359 18.4453C26.4609 17.9531 25.8633 17.4609 25.043 16.9688C24.2227 16.4531 23.0508 16.1953 21.5273 16.1953ZM25.1836 29.4844C25.1836 29.6484 25.043 30 24.7617 30.5391C24.4805 31.0781 23.7539 31.4414 22.582 31.6289L22.7227 18.6914C23.8711 18.9023 24.5742 19.2773 24.832 19.8164C25.0898 20.332 25.2188 20.6719 25.2188 20.8359L25.1836 29.4844ZM11.7891 16.125H11.7188C9.35156 16.125 7.74609 16.6875 6.90234 17.8125C6.05859 18.9375 5.63672 19.8984 5.63672 20.6953L5.56641 29.3789C5.56641 29.4258 5.60156 29.707 5.67188 30.2227C5.74219 30.7148 5.97656 31.2422 6.375 31.8047C6.72656 32.2969 7.3125 32.7891 8.13281 33.2812C8.97656 33.7969 10.1602 34.0547 11.6836 34.0547C12.0117 34.0547 12.2812 33.9375 12.4922 33.7031C12.7266 33.4688 12.8438 33.1875 12.8438 32.8594L12.9844 17.3203C12.9844 16.9922 12.8672 16.7109 12.6328 16.4766C12.3984 16.2422 12.1172 16.125 11.7891 16.125ZM10.4883 31.5586C9.31641 31.3477 8.60156 30.9844 8.34375 30.4688C8.08594 29.9297 7.95703 29.5781 7.95703 29.4141L8.02734 20.6953C8.02734 20.5312 8.16797 20.1914 8.44922 19.6758C8.73047 19.1602 9.44531 18.8203 10.5938 18.6562L10.4883 31.5586Z" /></svg>'),
        array('icon-ideas','<svg class="icon icon-ideas" width="62" height="62" viewBox="0 0 62 62" xmlns="http://www.w3.org/2000/svg"><path d="M34.1007 40.3C34.6722 40.3 35.134 39.8371 35.134 39.2667V24.8H38.234C41.0828 24.8 43.4007 22.4823 43.4007 19.6333C43.4007 16.7844 41.083 14.4666 38.234 14.4666C35.3852 14.4666 33.0673 16.7843 33.0673 19.6333V22.7333H28.9341V19.6333C28.9341 16.7844 26.6164 14.4666 23.7674 14.4666C20.9186 14.4666 18.6007 16.7843 18.6007 19.6333C18.6007 22.4821 20.9184 24.8 23.7674 24.8H26.8674V39.2667C26.8674 39.8371 27.3303 40.3 27.9007 40.3C28.471 40.3 28.9339 39.8371 28.9339 39.2667V24.8H33.0672V39.2667C33.0675 39.8371 33.5293 40.3 34.1007 40.3ZM35.134 19.6333C35.134 17.9242 36.5249 16.5333 38.234 16.5333C39.9431 16.5333 41.334 17.9242 41.334 19.6333C41.334 21.3424 39.9431 22.7333 38.234 22.7333H35.134V19.6333ZM26.8675 22.7333H23.7675C22.0584 22.7333 20.6675 21.3424 20.6675 19.6333C20.6675 17.9242 22.0584 16.5333 23.7675 16.5333C25.4766 16.5333 26.8675 17.9242 26.8675 19.6333V22.7333Z" /><path d="M7.37861 2.19783L11.3342 5.51798C11.5285 5.68122 11.7641 5.75981 11.9987 5.75981C12.2932 5.75981 12.5866 5.63472 12.7901 5.39095C13.1569 4.95381 13.1001 4.30184 12.663 3.93504L8.70749 0.614775C8.27034 0.248951 7.61935 0.305865 7.25159 0.741923C6.88468 1.18004 6.94147 1.83104 7.37861 2.19783Z" /><path d="M8.04737 11.2147L3.19383 9.44883C2.65751 9.2546 2.06548 9.53045 1.86907 10.0668C1.67484 10.6031 1.95069 11.1962 2.48701 11.3915L7.34055 13.1575C7.45728 13.1998 7.57619 13.2205 7.69389 13.2205C8.11554 13.2205 8.51224 12.9591 8.66518 12.5396C8.86063 12.0032 8.58369 11.4101 8.04737 11.2147Z" /><path d="M49.9993 5.75983C50.2328 5.75983 50.4685 5.68027 50.6617 5.518L54.6194 2.1958C55.0566 1.829 55.1143 1.178 54.7466 0.739888C54.3828 0.304798 53.7308 0.245946 53.2916 0.612739L49.3339 3.93495C48.8968 4.30174 48.84 4.95274 49.2068 5.39086C49.4103 5.63377 49.7038 5.75983 49.9993 5.75983Z" /><path d="M6.19791 19.6353H1.03329C0.462939 19.6353 0 20.0982 0 20.6686C0 21.2389 0.462939 21.7019 1.03329 21.7019H6.19791C6.76825 21.7019 7.23119 21.2389 7.23119 20.6686C7.23119 20.0982 6.76825 19.6353 6.19791 19.6353Z" /><path d="M60.1289 10.0636C59.9347 9.52839 59.3405 9.25036 58.8053 9.44678L53.9506 11.2138C53.4134 11.4091 53.1374 12.0022 53.3327 12.5385C53.4857 12.9581 53.8814 13.2185 54.304 13.2185C54.4207 13.2185 54.5406 13.1989 54.6564 13.1554L59.512 11.3884C60.0483 11.1931 60.3252 10.6 60.1289 10.0636Z" /><path d="M30.9996 0C19.604 0 10.333 9.27106 10.333 20.6667C10.333 29.388 13.7532 35.8939 21.0992 41.1411C21.1344 41.1659 21.1861 41.1969 21.2243 41.2175C21.2781 41.2465 22.39 41.8674 22.669 43.6097C21.5024 44.0551 20.6663 45.1784 20.6663 46.5C20.6663 47.2937 20.966 48.018 21.4578 48.5667C20.9659 49.1154 20.6663 49.8398 20.6663 50.6334C20.6663 51.4271 20.966 52.1513 21.4578 52.7001C20.9659 53.2488 20.6663 53.9732 20.6663 54.7668C20.6663 56.4759 22.0572 57.8668 23.7663 57.8668C24.3367 57.8668 24.7996 57.4039 24.7996 56.8335C24.7996 56.2632 24.3367 55.8002 23.7663 55.8002C23.1969 55.8002 22.733 55.3363 22.733 54.767C22.733 54.1976 23.1969 53.7337 23.7663 53.7337H34.0995C34.671 53.7337 35.1328 53.2707 35.1328 52.7004C35.1328 52.13 34.671 51.6671 34.0995 51.6671H23.7663C23.1969 51.6671 22.733 51.2032 22.733 50.6338C22.733 50.0644 23.1969 49.6005 23.7663 49.6005H34.0995C34.671 49.6005 35.1328 49.1375 35.1328 48.5672C35.1328 47.9968 34.671 47.5339 34.0995 47.5339H23.7663C23.1969 47.5339 22.733 47.07 22.733 46.5006C22.733 45.9312 23.1969 45.4673 23.7663 45.4673H34.0995C34.671 45.4673 35.1328 45.0044 35.1328 44.434C35.1328 43.8637 34.671 43.4007 34.0995 43.4007H24.7294C24.3635 40.7988 22.6772 39.6714 22.2546 39.4275C15.4387 34.543 12.3998 28.7553 12.3998 20.6673C12.3998 10.4115 20.7439 2.06731 30.9997 2.06731C41.2554 2.06731 49.5996 10.4115 49.5996 20.6673C49.5996 28.7552 46.5605 34.543 39.7448 39.4275C39.2695 39.7013 37.1996 41.0912 37.1996 44.434C37.1996 45.0044 37.6615 45.4673 38.2329 45.4673C38.8033 45.4673 39.2662 45.9312 39.2662 46.5006C39.2662 47.07 38.8033 47.5339 38.2329 47.5339C37.6615 47.5339 37.1996 47.9968 37.1996 48.5672C37.1996 49.1375 37.6615 49.6005 38.2329 49.6005C38.8033 49.6005 39.2662 50.0644 39.2662 50.6338C39.2662 51.2032 38.8033 51.6671 38.2329 51.6671C37.6615 51.6671 37.1996 52.13 37.1996 52.7004C37.1996 53.2707 37.6615 53.7337 38.2329 53.7337C38.8033 53.7337 39.2662 54.1976 39.2662 54.767C39.2662 55.356 38.8219 55.8002 38.2329 55.8002H27.8996C27.3292 55.8002 26.8663 56.2632 26.8663 56.8335V58.9C26.8663 60.6091 28.2572 62 29.9663 62H32.033C33.7421 62 35.1329 60.6091 35.1329 58.9V57.8667H38.2329C39.9721 57.8667 41.3329 56.5048 41.3329 54.7667C41.3329 53.9731 41.0332 53.2488 40.5413 52.7C41.0332 52.1513 41.3329 51.4269 41.3329 50.6333C41.3329 49.8396 41.0332 49.1154 40.5413 48.5666C41.0332 48.0179 41.3329 47.2935 41.3329 46.4999C41.3329 45.1783 40.4969 44.055 39.3293 43.6096C39.6083 41.8674 40.7191 41.2474 40.7615 41.2237C40.81 41.2 40.8565 41.172 40.8999 41.141C48.2448 35.8938 51.6661 29.3879 51.6661 20.6666C51.6661 9.27106 42.3951 0 30.9996 0ZM33.0663 58.9C33.0663 59.4694 32.6033 59.9333 32.033 59.9333H29.9663C29.3969 59.9333 28.933 59.4694 28.933 58.9V57.8667H33.0663V58.9Z" /><path d="M60.9667 19.6333H55.8C55.2286 19.6333 54.7668 20.0962 54.7668 20.6666C54.7668 21.2369 55.2286 21.6999 55.8 21.6999H60.9667C61.5382 21.6999 62 21.2369 62 20.6666C62 20.0962 61.5382 19.6333 60.9667 19.6333Z" /></svg>'),
        array('icon-ideas-grad','<svg class="icon icon-ideas-grad" width="62" height="62" viewBox="0 0 62 62" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M34.1007 40.3C34.6722 40.3 35.134 39.8371 35.134 39.2667V24.8H38.234C41.0828 24.8 43.4007 22.4823 43.4007 19.6333C43.4007 16.7844 41.083 14.4666 38.234 14.4666C35.3852 14.4666 33.0673 16.7843 33.0673 19.6333V22.7333H28.9341V19.6333C28.9341 16.7844 26.6164 14.4666 23.7674 14.4666C20.9186 14.4666 18.6007 16.7843 18.6007 19.6333C18.6007 22.4821 20.9184 24.8 23.7674 24.8H26.8674V39.2667C26.8674 39.8371 27.3303 40.3 27.9007 40.3C28.471 40.3 28.9339 39.8371 28.9339 39.2667V24.8H33.0672V39.2667C33.0675 39.8371 33.5293 40.3 34.1007 40.3ZM35.134 19.6333C35.134 17.9242 36.5249 16.5333 38.234 16.5333C39.9431 16.5333 41.334 17.9242 41.334 19.6333C41.334 21.3424 39.9431 22.7333 38.234 22.7333H35.134V19.6333ZM26.8675 22.7333H23.7675C22.0584 22.7333 20.6675 21.3424 20.6675 19.6333C20.6675 17.9242 22.0584 16.5333 23.7675 16.5333C25.4766 16.5333 26.8675 17.9242 26.8675 19.6333V22.7333Z" fill="url(#paint0_linear)"/><path d="M7.37861 2.19783L11.3342 5.51798C11.5285 5.68122 11.7641 5.75981 11.9987 5.75981C12.2932 5.75981 12.5866 5.63472 12.7901 5.39095C13.1569 4.95381 13.1001 4.30184 12.663 3.93504L8.70749 0.614775C8.27034 0.248951 7.61935 0.305865 7.25159 0.741923C6.88468 1.18004 6.94147 1.83104 7.37861 2.19783Z" fill="url(#paint1_linear)"/><path d="M8.04737 11.2147L3.19383 9.44883C2.65751 9.25459 2.06548 9.53045 1.86907 10.0668C1.67484 10.6031 1.95069 11.1962 2.48701 11.3915L7.34055 13.1575C7.45728 13.1998 7.57619 13.2205 7.69389 13.2205C8.11554 13.2205 8.51224 12.9591 8.66518 12.5396C8.86063 12.0032 8.58369 11.4101 8.04737 11.2147Z" fill="url(#paint2_linear)"/><path d="M49.9993 5.75983C50.2328 5.75983 50.4685 5.68027 50.6617 5.518L54.6194 2.1958C55.0566 1.829 55.1143 1.178 54.7466 0.739888C54.3828 0.304798 53.7308 0.245946 53.2916 0.612739L49.3339 3.93495C48.8968 4.30174 48.84 4.95274 49.2068 5.39086C49.4103 5.63377 49.7038 5.75983 49.9993 5.75983Z" fill="url(#paint3_linear)"/><path d="M6.19791 19.6353H1.03329C0.462939 19.6353 0 20.0982 0 20.6686C0 21.2389 0.462939 21.7019 1.03329 21.7019H6.19791C6.76825 21.7019 7.23119 21.2389 7.23119 20.6686C7.23119 20.0982 6.76825 19.6353 6.19791 19.6353Z" fill="url(#paint4_linear)"/><path d="M60.1289 10.0636C59.9347 9.52839 59.3405 9.25036 58.8053 9.44678L53.9506 11.2138C53.4134 11.4091 53.1374 12.0022 53.3327 12.5385C53.4857 12.9581 53.8814 13.2185 54.304 13.2185C54.4207 13.2185 54.5406 13.1989 54.6564 13.1554L59.512 11.3884C60.0483 11.1931 60.3252 10.6 60.1289 10.0636Z" fill="url(#paint5_linear)"/><path d="M30.9996 0C19.604 0 10.333 9.27106 10.333 20.6667C10.333 29.388 13.7532 35.8939 21.0992 41.1411C21.1344 41.1659 21.1861 41.1969 21.2243 41.2175C21.2781 41.2465 22.39 41.8674 22.669 43.6097C21.5024 44.0551 20.6663 45.1784 20.6663 46.5C20.6663 47.2937 20.966 48.018 21.4578 48.5667C20.9659 49.1154 20.6663 49.8398 20.6663 50.6334C20.6663 51.4271 20.966 52.1513 21.4578 52.7001C20.9659 53.2488 20.6663 53.9732 20.6663 54.7668C20.6663 56.4759 22.0572 57.8668 23.7663 57.8668C24.3367 57.8668 24.7996 57.4039 24.7996 56.8335C24.7996 56.2632 24.3367 55.8002 23.7663 55.8002C23.1969 55.8002 22.733 55.3363 22.733 54.767C22.733 54.1976 23.1969 53.7337 23.7663 53.7337H34.0995C34.671 53.7337 35.1328 53.2707 35.1328 52.7004C35.1328 52.13 34.671 51.6671 34.0995 51.6671H23.7663C23.1969 51.6671 22.733 51.2032 22.733 50.6338C22.733 50.0644 23.1969 49.6005 23.7663 49.6005H34.0995C34.671 49.6005 35.1328 49.1375 35.1328 48.5672C35.1328 47.9968 34.671 47.5339 34.0995 47.5339H23.7663C23.1969 47.5339 22.733 47.07 22.733 46.5006C22.733 45.9312 23.1969 45.4673 23.7663 45.4673H34.0995C34.671 45.4673 35.1328 45.0044 35.1328 44.434C35.1328 43.8637 34.671 43.4007 34.0995 43.4007H24.7294C24.3635 40.7988 22.6772 39.6714 22.2546 39.4275C15.4387 34.543 12.3998 28.7553 12.3998 20.6673C12.3998 10.4115 20.7439 2.06731 30.9997 2.06731C41.2554 2.06731 49.5996 10.4115 49.5996 20.6673C49.5996 28.7552 46.5605 34.543 39.7448 39.4275C39.2695 39.7013 37.1996 41.0912 37.1996 44.434C37.1996 45.0044 37.6615 45.4673 38.2329 45.4673C38.8033 45.4673 39.2662 45.9312 39.2662 46.5006C39.2662 47.07 38.8033 47.5339 38.2329 47.5339C37.6615 47.5339 37.1996 47.9968 37.1996 48.5672C37.1996 49.1375 37.6615 49.6005 38.2329 49.6005C38.8033 49.6005 39.2662 50.0644 39.2662 50.6338C39.2662 51.2032 38.8033 51.6671 38.2329 51.6671C37.6615 51.6671 37.1996 52.13 37.1996 52.7004C37.1996 53.2707 37.6615 53.7337 38.2329 53.7337C38.8033 53.7337 39.2662 54.1976 39.2662 54.767C39.2662 55.356 38.8219 55.8002 38.2329 55.8002H27.8996C27.3292 55.8002 26.8663 56.2632 26.8663 56.8335V58.9C26.8663 60.6091 28.2572 62 29.9663 62H32.033C33.7421 62 35.1329 60.6091 35.1329 58.9V57.8667H38.2329C39.9721 57.8667 41.3329 56.5048 41.3329 54.7667C41.3329 53.9731 41.0332 53.2488 40.5413 52.7C41.0332 52.1513 41.3329 51.4269 41.3329 50.6333C41.3329 49.8396 41.0332 49.1154 40.5413 48.5666C41.0332 48.0179 41.3329 47.2935 41.3329 46.4999C41.3329 45.1783 40.4969 44.055 39.3293 43.6096C39.6083 41.8674 40.7191 41.2474 40.7615 41.2237C40.81 41.2 40.8565 41.172 40.8999 41.141C48.2448 35.8938 51.6661 29.3879 51.6661 20.6666C51.6661 9.27106 42.3951 0 30.9996 0ZM33.0663 58.9C33.0663 59.4694 32.6033 59.9333 32.033 59.9333H29.9663C29.3969 59.9333 28.933 59.4694 28.933 58.9V57.8667H33.0663V58.9Z" fill="url(#paint6_linear)"/><path d="M60.9667 19.6333H55.8C55.2286 19.6333 54.7668 20.0962 54.7668 20.6666C54.7668 21.2369 55.2286 21.6999 55.8 21.6999H60.9667C61.5382 21.6999 62 21.2369 62 20.6666C62 20.0962 61.5382 19.6333 60.9667 19.6333Z" fill="url(#paint7_linear)"/><defs><linearGradient id="paint0_linear" x1="62.1409" y1="33.0684" x2="-0.00294844" y2="33.0684" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint1_linear" x1="62.1409" y1="33.0684" x2="-0.00294844" y2="33.0684" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint2_linear" x1="62.1409" y1="33.0684" x2="-0.00294844" y2="33.0684" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint3_linear" x1="62.1409" y1="33.0684" x2="-0.00294844" y2="33.0684" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint4_linear" x1="62.1409" y1="33.0684" x2="-0.00294844" y2="33.0684" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint5_linear" x1="62.1409" y1="33.0684" x2="-0.00294844" y2="33.0684" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint6_linear" x1="62.1409" y1="33.0684" x2="-0.00294844" y2="33.0684" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint7_linear" x1="62.1409" y1="33.0684" x2="-0.00294844" y2="33.0684" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient></defs></svg>'),
        array('icon-instagram','<svg class="icon icon-instagram" width="20" height="21" viewBox="0 0 20 21" xmlns="http://www.w3.org/2000/svg"><path d="M14.9024 20.25H5.09767C4.39454 20.25 3.73048 20.1133 3.10548 19.8398C2.4935 19.5794 1.95314 19.2214 1.48439 18.7656C1.02866 18.2969 0.664075 17.7565 0.390637 17.1445C0.130221 16.5195 1.23978e-05 15.849 1.23978e-05 15.1328V5.34766C1.23978e-05 4.64453 0.130221 3.98698 0.390637 3.375C0.664075 2.75 1.02866 2.20964 1.48439 1.75391C1.95314 1.28516 2.4935 0.920573 3.10548 0.660156C3.73048 0.386719 4.39454 0.25 5.09767 0.25H14.9024C15.6055 0.25 16.263 0.386719 16.875 0.660156C17.5 0.920573 18.0404 1.28516 18.4961 1.75391C18.9649 2.20964 19.3294 2.75 19.5899 3.375C19.8633 3.98698 20 4.64453 20 5.34766V15.1328C20 15.849 19.8633 16.5195 19.5899 17.1445C19.3294 17.7565 18.9649 18.2969 18.4961 18.7656C18.0404 19.2214 17.5 19.5794 16.875 19.8398C16.263 20.1133 15.6055 20.25 14.9024 20.25ZM5.09767 1.38281C4.56381 1.38281 4.056 1.48698 3.57423 1.69531C3.09246 1.90365 2.66928 2.1901 2.3047 2.55469C1.94012 2.91927 1.65366 3.34245 1.44532 3.82422C1.25001 4.29297 1.15236 4.80078 1.15236 5.34766V15.1328C1.15236 15.6797 1.25001 16.194 1.44532 16.6758C1.65366 17.1576 1.94012 17.5807 2.3047 17.9453C2.66928 18.2969 3.09246 18.5768 3.57423 18.7852C4.056 18.9935 4.56381 19.0977 5.09767 19.0977H14.9024C15.4362 19.0977 15.944 18.9935 16.4258 18.7852C16.9076 18.5768 17.3307 18.2969 17.6953 17.9453C18.0599 17.5807 18.3399 17.1576 18.5352 16.6758C18.7435 16.194 18.8477 15.6797 18.8477 15.1328V5.34766C18.8477 4.80078 18.7435 4.29297 18.5352 3.82422C18.3399 3.34245 18.0599 2.91927 17.6953 2.55469C17.3307 2.1901 16.9076 1.91016 16.4258 1.71484C15.944 1.50651 15.4362 1.40234 14.9024 1.40234H5.09767V1.38281ZM19.4336 7.75H12.3828C12.2266 7.75 12.0899 7.69792 11.9727 7.59375C11.8685 7.47656 11.8164 7.33984 11.8164 7.18359C11.8164 7.02734 11.8685 6.89714 11.9727 6.79297C12.0899 6.67578 12.2266 6.61719 12.3828 6.61719H19.4336C19.5899 6.61719 19.7201 6.67578 19.8242 6.79297C19.9414 6.89714 20 7.02734 20 7.18359C20 7.33984 19.9414 7.47656 19.8242 7.59375C19.7201 7.69792 19.5899 7.75 19.4336 7.75ZM7.46095 7.75H0.566419C0.410169 7.75 0.27345 7.69792 0.156262 7.59375C0.0520957 7.47656 1.23978e-05 7.33984 1.23978e-05 7.18359C1.23978e-05 7.02734 0.0520957 6.89714 0.156262 6.79297C0.27345 6.67578 0.410169 6.61719 0.566419 6.61719H7.46095C7.6172 6.61719 7.75392 6.67578 7.87111 6.79297C7.98829 6.89714 8.04689 7.02734 8.04689 7.18359C8.04689 7.33984 7.98829 7.47656 7.87111 7.59375C7.75392 7.69792 7.6172 7.75 7.46095 7.75ZM10 14.7031C9.38803 14.7031 8.80861 14.5859 8.26173 14.3516C7.72788 14.1172 7.25913 13.7982 6.85548 13.3945C6.45184 12.9909 6.13282 12.5221 5.89845 11.9883C5.66407 11.4414 5.54689 10.862 5.54689 10.25C5.54689 9.63802 5.66407 9.0651 5.89845 8.53125C6.13282 7.98438 6.45184 7.50911 6.85548 7.10547C7.25913 6.70182 7.72788 6.38281 8.26173 6.14844C8.80861 5.91406 9.38803 5.79688 10 5.79688C10.612 5.79688 11.1849 5.91406 11.7188 6.14844C12.2656 6.38281 12.7409 6.70182 13.1445 7.10547C13.5482 7.50911 13.8672 7.98438 14.1016 8.53125C14.3359 9.0651 14.4531 9.63802 14.4531 10.25C14.4531 10.862 14.3359 11.4414 14.1016 11.9883C13.8672 12.5221 13.5482 12.9909 13.1445 13.3945C12.7409 13.7982 12.2656 14.1172 11.7188 14.3516C11.1849 14.5859 10.612 14.7031 10 14.7031ZM10 6.92969C9.08855 6.92969 8.3073 7.25521 7.65626 7.90625C7.00522 8.55729 6.6797 9.33854 6.6797 10.25C6.6797 11.1615 7.00522 11.9427 7.65626 12.5938C8.3073 13.2448 9.08855 13.5703 10 13.5703C10.9115 13.5703 11.6927 13.2448 12.3438 12.5938C12.9948 11.9427 13.3203 11.1615 13.3203 10.25C13.3203 9.33854 12.9948 8.55729 12.3438 7.90625C11.6927 7.25521 10.9115 6.92969 10 6.92969ZM16.4649 6.28516H13.8867C13.7305 6.28516 13.5938 6.23307 13.4766 6.12891C13.3724 6.01172 13.3203 5.86849 13.3203 5.69922V3.14062C13.3203 2.98438 13.3724 2.84766 13.4766 2.73047C13.5938 2.61328 13.7305 2.55469 13.8867 2.55469H16.4649C16.6211 2.55469 16.7513 2.61328 16.8555 2.73047C16.9727 2.84766 17.0313 2.98438 17.0313 3.14062V5.69922C17.0313 5.86849 16.9727 6.01172 16.8555 6.12891C16.7513 6.23307 16.6211 6.28516 16.4649 6.28516ZM14.4531 5.13281H15.8789V3.70703H14.4531V5.13281Z"/></svg>'),
        array('icon-like','<svg class="icon icon-like" width="13" height="14" viewBox="0 0 13 14" xmlns="http://www.w3.org/2000/svg"><path d="M11.8447 5.06543C11.5908 4.99772 11.1719 4.95964 10.5879 4.95117C10.0039 4.93424 9.27604 4.91309 8.4043 4.8877C8.44661 4.7015 8.47201 4.51107 8.48047 4.31641C8.4974 4.11328 8.50586 3.85938 8.50586 3.55469C8.50586 3.19076 8.44238 2.84375 8.31543 2.51367C8.19694 2.18359 8.04036 1.8916 7.8457 1.6377C7.65951 1.38379 7.44792 1.1849 7.21094 1.04102C6.97396 0.888672 6.73698 0.8125 6.5 0.8125C6.16992 0.8125 5.88639 0.93099 5.64941 1.16797C5.41243 1.40495 5.28971 1.68848 5.28125 2.01855C5.27279 2.43327 5.17122 2.94108 4.97656 3.54199C4.7819 4.13444 4.3418 4.6084 3.65625 4.96387C3.60547 4.99772 3.52507 5.04004 3.41504 5.09082C3.31348 5.1416 3.25 5.17122 3.22461 5.17969L3.25 5.20508C3.13997 5.11198 3.01302 5.03581 2.86914 4.97656C2.73372 4.90885 2.58984 4.875 2.4375 4.875H1.21875C0.880208 4.875 0.592448 4.99349 0.355469 5.23047C0.11849 5.46745 0 5.75521 0 6.09375V12.5938C0 12.9323 0.11849 13.2201 0.355469 13.457C0.592448 13.694 0.880208 13.8125 1.21875 13.8125H2.4375C2.68294 13.8125 2.89876 13.7448 3.08496 13.6094C3.27962 13.4824 3.4235 13.3174 3.5166 13.1143C3.52507 13.1143 3.5293 13.1143 3.5293 13.1143C3.53776 13.1143 3.54199 13.1143 3.54199 13.1143C3.55046 13.1227 3.56315 13.127 3.58008 13.127C3.59701 13.1354 3.61816 13.1396 3.64355 13.1396C3.65202 13.1396 3.65625 13.1396 3.65625 13.1396C3.77474 13.1735 3.95671 13.2201 4.20215 13.2793C4.45605 13.3385 4.82422 13.4232 5.30664 13.5332C5.4082 13.5586 5.69596 13.6094 6.16992 13.6855C6.64388 13.7702 7.16439 13.8125 7.73145 13.8125H9.95312C10.2917 13.8125 10.5794 13.7448 10.8164 13.6094C11.0618 13.4824 11.2565 13.2878 11.4004 13.0254C11.4089 13.0254 11.43 12.9831 11.4639 12.8984C11.5062 12.8138 11.5443 12.7122 11.5781 12.5938C11.612 12.5007 11.6289 12.3906 11.6289 12.2637C11.6374 12.1367 11.6247 12.0098 11.5908 11.8828C11.8109 11.7305 11.9632 11.5527 12.0479 11.3496C12.141 11.1465 12.2129 10.973 12.2637 10.8291C12.3398 10.5837 12.3695 10.3721 12.3525 10.1943C12.3441 10.0081 12.3145 9.85156 12.2637 9.72461C12.3822 9.60612 12.488 9.45801 12.5811 9.28027C12.6826 9.09408 12.7546 8.86556 12.7969 8.59473C12.8307 8.42546 12.8307 8.26042 12.7969 8.09961C12.7715 7.93034 12.7207 7.77376 12.6445 7.62988C12.7546 7.50293 12.835 7.36328 12.8857 7.21094C12.945 7.05013 12.9788 6.89779 12.9873 6.75391L13 6.66504C13 6.63965 13 6.61426 13 6.58887C13 6.56348 13 6.52116 13 6.46191C13 6.20801 12.9069 5.94141 12.7207 5.66211C12.5345 5.38281 12.2425 5.18392 11.8447 5.06543ZM2.84375 12.5938C2.84375 12.7038 2.80143 12.8011 2.7168 12.8857C2.64062 12.9619 2.54753 13 2.4375 13H1.21875C1.10872 13 1.01139 12.9619 0.926758 12.8857C0.850586 12.8011 0.8125 12.7038 0.8125 12.5938V6.09375C0.8125 5.98372 0.850586 5.89062 0.926758 5.81445C1.01139 5.72982 1.10872 5.6875 1.21875 5.6875H2.4375C2.54753 5.6875 2.64062 5.72982 2.7168 5.81445C2.80143 5.89062 2.84375 5.98372 2.84375 6.09375V12.5938ZM12.1748 6.71582C12.1748 6.81738 12.1283 6.94434 12.0352 7.09668C11.9505 7.24056 11.7305 7.3125 11.375 7.3125C11.0703 7.3125 10.8587 7.3125 10.7402 7.3125C10.6217 7.3125 10.5625 7.3125 10.5625 7.3125C10.5033 7.3125 10.4525 7.33366 10.4102 7.37598C10.3763 7.40983 10.3594 7.45638 10.3594 7.51562C10.3594 7.57487 10.3763 7.62565 10.4102 7.66797C10.4525 7.70182 10.5033 7.71875 10.5625 7.71875C10.5625 7.71875 10.6175 7.71875 10.7275 7.71875C10.8376 7.71875 11.0449 7.71875 11.3496 7.71875C11.6543 7.71875 11.8447 7.81608 11.9209 8.01074C11.9971 8.19694 12.0225 8.34928 11.9971 8.46777C11.9717 8.62012 11.904 8.80632 11.7939 9.02637C11.6924 9.23796 11.4681 9.34375 11.1211 9.34375C10.7826 9.34375 10.5371 9.34375 10.3848 9.34375C10.2324 9.34375 10.1562 9.34375 10.1562 9.34375C10.097 9.34375 10.0462 9.36491 10.0039 9.40723C9.97005 9.44108 9.95312 9.48763 9.95312 9.54688C9.95312 9.60612 9.97005 9.6569 10.0039 9.69922C10.0462 9.73307 10.097 9.75 10.1562 9.75C10.1562 9.75 10.2493 9.75 10.4355 9.75C10.6217 9.75 10.7952 9.75 10.9561 9.75C11.3031 9.75 11.4893 9.85156 11.5146 10.0547C11.54 10.2493 11.5316 10.4271 11.4893 10.5879C11.4215 10.791 11.3327 10.973 11.2227 11.1338C11.1126 11.2946 10.8418 11.375 10.4102 11.375C10.2663 11.375 10.1182 11.375 9.96582 11.375C9.82194 11.375 9.75 11.375 9.75 11.375C9.69076 11.375 9.63997 11.3962 9.59766 11.4385C9.5638 11.4723 9.54688 11.5189 9.54688 11.5781C9.54688 11.6374 9.5638 11.6882 9.59766 11.7305C9.63997 11.7643 9.69076 11.7812 9.75 11.7812C9.75 11.7812 9.80924 11.7812 9.92773 11.7812C10.0547 11.7812 10.207 11.7812 10.3848 11.7812C10.6048 11.7812 10.736 11.8574 10.7783 12.0098C10.8206 12.1621 10.8291 12.2764 10.8037 12.3525C10.7783 12.4372 10.7529 12.5091 10.7275 12.5684C10.7021 12.6191 10.6895 12.6445 10.6895 12.6445C10.6302 12.7546 10.5456 12.8434 10.4355 12.9111C10.3255 12.9704 10.1647 13 9.95312 13H7.73145C7.17285 13 6.66081 12.9577 6.19531 12.873C5.72982 12.7884 5.49284 12.7461 5.48438 12.7461C4.63802 12.5514 4.12598 12.4329 3.94824 12.3906C3.77051 12.3398 3.65202 12.306 3.59277 12.2891C3.59277 12.2891 3.53353 12.2679 3.41504 12.2256C3.30501 12.1833 3.25 12.0859 3.25 11.9336V6.32227C3.25 6.22917 3.27962 6.14453 3.33887 6.06836C3.39811 5.98372 3.47428 5.92871 3.56738 5.90332C3.58431 5.89486 3.60124 5.89062 3.61816 5.89062C3.63509 5.88216 3.64779 5.8737 3.65625 5.86523C4.12174 5.67904 4.50684 5.43783 4.81152 5.1416C5.12467 4.84538 5.37435 4.52799 5.56055 4.18945C5.74674 3.84245 5.88216 3.48275 5.9668 3.11035C6.05143 2.73796 6.09375 2.37826 6.09375 2.03125C6.09375 1.93815 6.1276 1.84928 6.19531 1.76465C6.27148 1.67155 6.37305 1.625 6.5 1.625C6.71159 1.625 6.96126 1.81543 7.24902 2.19629C7.54525 2.56868 7.69336 3.02148 7.69336 3.55469C7.69336 4.03711 7.6722 4.38835 7.62988 4.6084C7.58757 4.82845 7.48177 5.18815 7.3125 5.6875C9.34375 5.6875 10.5371 5.7002 10.8926 5.72559C11.2565 5.75098 11.5273 5.78906 11.7051 5.83984C11.9251 5.90755 12.0605 6.01335 12.1113 6.15723C12.1621 6.30111 12.1875 6.40267 12.1875 6.46191C12.1875 6.52962 12.1875 6.57194 12.1875 6.58887C12.1875 6.60579 12.1833 6.64811 12.1748 6.71582ZM1.82812 11.375C1.65885 11.375 1.51497 11.4342 1.39648 11.5527C1.27799 11.6712 1.21875 11.8151 1.21875 11.9844C1.21875 12.1536 1.27799 12.2975 1.39648 12.416C1.51497 12.5345 1.65885 12.5938 1.82812 12.5938C1.9974 12.5938 2.14128 12.5345 2.25977 12.416C2.37826 12.2975 2.4375 12.1536 2.4375 11.9844C2.4375 11.8151 2.37826 11.6712 2.25977 11.5527C2.14128 11.4342 1.9974 11.375 1.82812 11.375ZM1.82812 12.1875C1.76888 12.1875 1.7181 12.1706 1.67578 12.1367C1.64193 12.0944 1.625 12.0436 1.625 11.9844C1.625 11.9251 1.64193 11.8786 1.67578 11.8447C1.7181 11.8024 1.76888 11.7812 1.82812 11.7812C1.88737 11.7812 1.93392 11.8024 1.96777 11.8447C2.01009 11.8786 2.03125 11.9251 2.03125 11.9844C2.03125 12.0436 2.01009 12.0944 1.96777 12.1367C1.93392 12.1706 1.88737 12.1875 1.82812 12.1875Z" /></svg>'),
        array('icon-linkedin','<svg class="icon icon-linkedin" width="19" height="18" viewBox="0 0 19 18" xmlns="http://www.w3.org/2000/svg"><path d="M18.5 11.0762V17.7207H14.6504V11.5156C14.6504 10.7305 14.498 10.0977 14.1934 9.61719C13.8887 9.13672 13.3848 8.89648 12.6816 8.89648C12.1543 8.89648 11.7266 9.04297 11.3984 9.33594C11.082 9.62891 10.8535 9.95117 10.7129 10.3027C10.6543 10.4316 10.6133 10.5781 10.5898 10.7422C10.5781 10.9062 10.5723 11.0762 10.5723 11.252V17.7207H6.72266C6.72266 17.7207 6.72266 17.1699 6.72266 16.0684C6.73438 14.9551 6.74023 13.707 6.74023 12.3242C6.74023 10.9414 6.74023 9.62891 6.74023 8.38672C6.74023 7.14453 6.73438 6.38867 6.72266 6.11914H10.5723V7.77148C10.5723 7.77148 10.5664 7.77734 10.5547 7.78906C10.5547 7.78906 10.5547 7.79492 10.5547 7.80664H10.5723V7.77148C10.8301 7.37305 11.2168 6.95703 11.7324 6.52344C12.2598 6.07812 13.0332 5.85547 14.0527 5.85547C14.6855 5.85547 15.2715 5.96094 15.8105 6.17188C16.3613 6.37109 16.8359 6.6875 17.2344 7.12109C17.6328 7.55469 17.9434 8.09961 18.166 8.75586C18.3887 9.41211 18.5 10.1855 18.5 11.0762ZM2.67969 0.529297C2.02344 0.529297 1.49609 0.722656 1.09766 1.10938C0.699219 1.48438 0.5 1.95898 0.5 2.5332C0.5 3.08398 0.693359 3.55859 1.08008 3.95703C1.4668 4.34375 1.98242 4.53711 2.62695 4.53711H2.66211C3.33008 4.53711 3.85742 4.34375 4.24414 3.95703C4.64258 3.55859 4.8418 3.08398 4.8418 2.5332C4.83008 1.95898 4.63086 1.48438 4.24414 1.10938C3.86914 0.722656 3.34766 0.529297 2.67969 0.529297ZM0.728516 17.7207H4.5957V6.11914H0.728516V17.7207Z"/></svg>'),
        array('icon-link-grad','<svg class="icon icon-link-grad" width="35" height="35" viewBox="0 0 35 35" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M32.5835 2.41965C29.3563 -0.807187 24.1049 -0.805913 20.8771 2.41965L15.0239 8.27227C14.5266 8.76954 14.5266 9.57561 15.0239 10.0729C15.5212 10.5701 16.3274 10.5701 16.8247 10.0729L22.6779 4.22026C23.7547 3.14422 25.1938 2.55081 26.7296 2.55081C28.2662 2.55081 29.7053 3.14422 30.782 4.2209C31.8588 5.29757 32.4523 6.73653 32.4523 8.27291C32.4523 9.80865 31.8588 11.2476 30.782 12.3243L23.1287 19.9788C20.8937 22.2124 17.2583 22.2124 15.0233 19.9788C14.526 19.4815 13.7198 19.4815 13.2225 19.9788C12.7252 20.4761 12.7252 21.2828 13.2225 21.7794C14.8361 23.3928 16.9559 24.1995 19.0757 24.1995C21.1955 24.1995 23.3153 23.3928 24.9289 21.7794L32.5835 14.1255C34.1416 12.5681 35 10.4893 35 8.27291C35 6.05589 34.1416 3.97767 32.5835 2.41965Z" fill="url(#paint0_linear)"/><path d="M17.2749 25.8308L12.3221 30.7831C11.2453 31.8598 9.80624 32.4532 8.26972 32.4532C6.73383 32.4532 5.2941 31.8598 4.21732 30.7831C1.9829 28.5489 1.9829 24.9133 4.21732 22.6791L11.4217 15.4753C12.4985 14.3993 13.9376 13.8059 15.4741 13.8059C17.01 13.8059 18.4491 14.3993 19.5259 15.4753C20.0232 15.9726 20.8293 15.9726 21.3267 15.4753C21.824 14.9781 21.824 14.172 21.3267 13.6747C18.1002 10.4485 12.8487 10.4479 9.6203 13.6747L2.4159 20.8791C0.858364 22.4365 0 24.5153 0 26.7317C0 28.9475 0.858365 31.0263 2.41654 32.5837C3.97407 34.1417 6.05313 35 8.26908 35C10.4857 35 12.5647 34.1417 14.1223 32.5837L19.075 27.6314C19.5724 27.1341 19.5724 26.328 19.075 25.8308C18.5777 25.3335 17.7722 25.3335 17.2749 25.8308Z" fill="url(#paint0_linear)"/><defs><linearGradient id="paint0_linear" x1="35.0796" y1="18.6677" x2="-0.00166444" y2="18.6677" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint1_linear" x1="35.0796" y1="18.6677" x2="-0.00166444" y2="18.6677" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient></defs></svg>'),
        array('icon-logo','<svg class="icon ch-icon-logo" width="258" height="59" viewBox="0 0 258 59" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M33.4942 54C31.9671 53.3232 31.5079 52.1387 31.5399 50.5206C31.6253 46.248 31.5933 41.9754 31.5719 37.7028C31.5613 35.8203 30.5467 34.7627 28.9021 34.7945C27.3536 34.8262 26.4459 35.8732 26.3818 37.7028C26.3712 38.1152 26.3818 38.5277 26.3818 38.9402C26.3818 42.8003 26.4032 46.6604 26.3925 50.5206C26.3818 52.5511 25.41 53.7145 23.7975 53.651C22.281 53.5981 21.3412 52.4136 21.3412 50.5206C21.3412 45.476 21.3626 40.4313 21.3626 35.3867C21.3626 34.8791 21.3946 34.3397 21.2665 33.8532C20.9034 32.5418 19.9743 31.8861 18.5967 31.9707C17.2831 32.0554 16.4608 32.7745 16.29 34.0542C16.1618 35.0166 16.2473 36.0107 16.1939 36.9836C16.0977 38.6229 15.0085 39.7439 13.5988 39.7016C12.2425 39.6593 11.2387 38.5594 11.1746 36.9836C11.1319 36.1059 11.196 35.2387 11.1639 34.3609C11.0999 32.6899 10.1067 31.6006 8.67569 31.5689C7.10584 31.5371 6.102 32.5736 6.01656 34.3397C6.00588 34.5935 6.02724 34.8579 5.98452 35.1117C5.76026 36.4549 4.69234 37.3432 3.38947 37.2903C2.07593 37.2375 1.06141 36.2962 1.04005 34.9002C0.986651 31.9707 0.986651 29.0307 1.04005 26.1012C1.06141 24.6841 2.20408 23.6265 3.49627 23.6265C4.74574 23.6265 5.80298 24.5995 5.98452 25.9532C6.02724 26.3127 5.98453 26.6723 6.01656 27.0319C6.14471 28.4385 7.19128 29.3903 8.60093 29.3797C9.98923 29.3691 11.0892 28.4067 11.1426 27.0002C11.2173 25.308 11.1639 23.6053 11.1853 21.9027C11.2067 20.1365 12.2212 18.9309 13.6415 18.9097C15.1153 18.8886 16.1084 20.0202 16.1832 21.8075C16.2045 22.368 16.1832 22.9391 16.1939 23.5102C16.2259 25.5196 17.1763 26.6829 18.7782 26.6935C20.3908 26.704 21.384 25.5196 21.384 23.5419C21.3946 20.5067 21.3626 17.4714 21.4053 14.4362C21.4267 12.522 22.8684 11.2952 24.5023 11.7711C25.8265 12.1624 26.3818 13.1248 26.3712 14.4573C26.3605 16.9744 26.3605 19.502 26.3712 22.019C26.3818 24.2293 27.3536 25.4878 29.0196 25.4667C30.6642 25.4455 31.5719 24.2716 31.5719 22.093C31.5826 15.9697 31.5826 9.84632 31.5826 3.72297C31.5826 3.36339 31.5719 3.00382 31.5826 2.64424C31.668 1.03673 32.6185 0.0214629 34.0281 0.000311481C35.5232 -0.02084 36.5271 1.03673 36.5271 2.71827C36.5484 7.96384 36.5484 13.22 36.5591 18.4655C36.5591 18.7194 36.5378 18.9838 36.5591 19.2376C36.6873 20.6759 37.6804 21.6488 39.0687 21.6806C40.5318 21.7229 41.6424 20.7499 41.7065 19.227C41.7919 16.9109 41.7492 14.5948 41.7813 12.2787C41.8133 10.3963 42.8278 9.22235 44.3549 9.26465C45.818 9.30695 46.7685 10.4597 46.7791 12.2787C46.8005 15.6207 46.7791 18.9732 46.8112 22.3151C46.8325 24.2399 47.783 25.308 49.3849 25.2975C50.9867 25.2869 51.8838 24.2082 51.9265 22.2728C51.9372 21.9132 51.9158 21.5537 51.9586 21.1941C52.1401 19.7346 53.176 18.7722 54.5216 18.804C55.8992 18.8357 56.9137 19.7981 56.9458 21.2998C57.0098 24.0284 56.9885 26.7569 56.9885 29.4855C56.9885 30.9766 57.0205 32.4678 56.9778 33.959C56.9351 35.6723 55.9739 36.7087 54.4895 36.7193C52.9304 36.7404 51.9479 35.6617 51.9052 33.8744C51.8838 33.0495 51.9372 32.2246 51.8945 31.4102C51.8197 29.8344 50.8372 28.8826 49.3421 28.8932C47.8471 28.9038 46.8432 29.845 46.8325 31.442C46.8005 35.1963 46.8325 38.9507 46.8325 42.7157C46.8325 43.181 46.8539 43.6464 46.7791 44.1011C46.5442 45.4231 45.4229 46.3537 44.152 46.2586C42.7851 46.1528 41.8881 45.3808 41.7813 44.0271C41.6531 42.4407 41.7279 40.8438 41.7172 39.2469C41.7065 37.1846 40.8201 36.0741 39.1755 36.0636C37.4989 36.053 36.5805 37.1423 36.5805 39.194C36.5698 42.9484 36.5271 46.7133 36.6232 50.4677C36.6659 52.0858 36.1853 53.2597 34.7116 54C34.3272 54 33.9107 54 33.4942 54Z" fill="url(#paint0_linear1)"/><path d="M76.946 6.264L83.666 27.684L90.344 6.264H99.122L88.958 36H78.332L68.168 6.264H76.946ZM113.365 5.802C116.165 5.802 118.713 6.46 121.009 7.776C123.333 9.064 125.153 10.87 126.469 13.194C127.813 15.518 128.485 18.136 128.485 21.048C128.485 23.96 127.813 26.578 126.469 28.902C125.125 31.226 123.291 33.046 120.967 34.362C118.671 35.65 116.137 36.294 113.365 36.294C110.593 36.294 108.045 35.65 105.721 34.362C103.397 33.046 101.563 31.226 100.219 28.902C98.8749 26.578 98.2029 23.96 98.2029 21.048C98.2029 18.136 98.8749 15.518 100.219 13.194C101.563 10.87 103.397 9.064 105.721 7.776C108.045 6.46 110.593 5.802 113.365 5.802ZM113.365 13.446C111.265 13.446 109.613 14.132 108.409 15.504C107.205 16.848 106.603 18.696 106.603 21.048C106.603 23.344 107.205 25.178 108.409 26.55C109.613 27.922 111.265 28.608 113.365 28.608C115.437 28.608 117.075 27.922 118.279 26.55C119.483 25.178 120.085 23.344 120.085 21.048C120.085 18.696 119.483 16.848 118.279 15.504C117.103 14.132 115.465 13.446 113.365 13.446ZM137.938 6.264V36H129.664V6.264H137.938ZM153.715 5.97C156.263 5.97 158.531 6.446 160.519 7.398C162.535 8.322 164.173 9.652 165.433 11.388C166.693 13.096 167.547 15.084 167.995 17.352H159.301C158.825 16.176 158.083 15.266 157.075 14.622C156.067 13.95 154.905 13.614 153.589 13.614C151.769 13.614 150.299 14.3 149.179 15.672C148.059 17.016 147.499 18.822 147.499 21.09C147.499 23.358 148.059 25.178 149.179 26.55C150.299 27.922 151.769 28.608 153.589 28.608C154.905 28.608 156.067 28.272 157.075 27.6C158.083 26.928 158.825 26.004 159.301 24.828H167.995C167.323 28.3 165.727 31.072 163.207 33.144C160.715 35.188 157.551 36.21 153.715 36.21C150.775 36.21 148.199 35.58 145.987 34.32C143.803 33.032 142.109 31.24 140.905 28.944C139.729 26.648 139.141 24.03 139.141 21.09C139.141 18.15 139.729 15.532 140.905 13.236C142.109 10.94 143.803 9.162 145.987 7.902C148.199 6.614 150.775 5.97 153.715 5.97ZM177.441 12.858V17.772H187.059V24.03H177.441V29.406H188.319V36H169.167V6.264H188.319V12.858H177.441ZM204.694 36L198.688 25.038H197.848V36H189.574V6.264H202.636C205.016 6.264 207.032 6.684 208.684 7.524C210.364 8.336 211.624 9.47 212.464 10.926C213.304 12.382 213.724 14.02 213.724 15.84C213.724 17.912 213.15 19.718 212.002 21.258C210.854 22.77 209.202 23.834 207.046 24.45L213.808 36H204.694ZM197.848 19.494H201.922C204.218 19.494 205.366 18.458 205.366 16.386C205.366 15.406 205.072 14.636 204.484 14.076C203.924 13.516 203.07 13.236 201.922 13.236H197.848V19.494Z" fill="#CECECE"/><path d="M76.946 6.264L83.666 27.684L90.344 6.264H99.122L88.958 36H78.332L68.168 6.264H76.946ZM113.365 5.802C116.165 5.802 118.713 6.46 121.009 7.776C123.333 9.064 125.153 10.87 126.469 13.194C127.813 15.518 128.485 18.136 128.485 21.048C128.485 23.96 127.813 26.578 126.469 28.902C125.125 31.226 123.291 33.046 120.967 34.362C118.671 35.65 116.137 36.294 113.365 36.294C110.593 36.294 108.045 35.65 105.721 34.362C103.397 33.046 101.563 31.226 100.219 28.902C98.8749 26.578 98.2029 23.96 98.2029 21.048C98.2029 18.136 98.8749 15.518 100.219 13.194C101.563 10.87 103.397 9.064 105.721 7.776C108.045 6.46 110.593 5.802 113.365 5.802ZM113.365 13.446C111.265 13.446 109.613 14.132 108.409 15.504C107.205 16.848 106.603 18.696 106.603 21.048C106.603 23.344 107.205 25.178 108.409 26.55C109.613 27.922 111.265 28.608 113.365 28.608C115.437 28.608 117.075 27.922 118.279 26.55C119.483 25.178 120.085 23.344 120.085 21.048C120.085 18.696 119.483 16.848 118.279 15.504C117.103 14.132 115.465 13.446 113.365 13.446ZM137.938 6.264V36H129.664V6.264H137.938ZM153.715 5.97C156.263 5.97 158.531 6.446 160.519 7.398C162.535 8.322 164.173 9.652 165.433 11.388C166.693 13.096 167.547 15.084 167.995 17.352H159.301C158.825 16.176 158.083 15.266 157.075 14.622C156.067 13.95 154.905 13.614 153.589 13.614C151.769 13.614 150.299 14.3 149.179 15.672C148.059 17.016 147.499 18.822 147.499 21.09C147.499 23.358 148.059 25.178 149.179 26.55C150.299 27.922 151.769 28.608 153.589 28.608C154.905 28.608 156.067 28.272 157.075 27.6C158.083 26.928 158.825 26.004 159.301 24.828H167.995C167.323 28.3 165.727 31.072 163.207 33.144C160.715 35.188 157.551 36.21 153.715 36.21C150.775 36.21 148.199 35.58 145.987 34.32C143.803 33.032 142.109 31.24 140.905 28.944C139.729 26.648 139.141 24.03 139.141 21.09C139.141 18.15 139.729 15.532 140.905 13.236C142.109 10.94 143.803 9.162 145.987 7.902C148.199 6.614 150.775 5.97 153.715 5.97ZM177.441 12.858V17.772H187.059V24.03H177.441V29.406H188.319V36H169.167V6.264H188.319V12.858H177.441ZM204.694 36L198.688 25.038H197.848V36H189.574V6.264H202.636C205.016 6.264 207.032 6.684 208.684 7.524C210.364 8.336 211.624 9.47 212.464 10.926C213.304 12.382 213.724 14.02 213.724 15.84C213.724 17.912 213.15 19.718 212.002 21.258C210.854 22.77 209.202 23.834 207.046 24.45L213.808 36H204.694ZM197.848 19.494H201.922C204.218 19.494 205.366 18.458 205.366 16.386C205.366 15.406 205.072 14.636 204.484 14.076C203.924 13.516 203.07 13.236 201.922 13.236H197.848V19.494Z" fill="url(#paint1_linear1)"/><path d="M75.22 53L73.69 50.33H73.3V53H71.59V45.93H74.51C75.07 45.93 75.5433 46.0267 75.93 46.22C76.3167 46.4133 76.6067 46.68 76.8 47.02C76.9933 47.3533 77.09 47.7367 77.09 48.17C77.09 48.6833 76.9467 49.12 76.66 49.48C76.38 49.84 75.97 50.0867 75.43 50.22L77.11 53H75.22ZM73.3 49.16H74.36C74.7 49.16 74.95 49.0867 75.11 48.94C75.27 48.7867 75.35 48.5633 75.35 48.27C75.35 47.99 75.2667 47.77 75.1 47.61C74.94 47.45 74.6933 47.37 74.36 47.37H73.3V49.16ZM82.1574 47.29V48.77H84.5474V50.06H82.1574V51.63H84.8474V53H80.4474V45.93H84.8474V47.29H82.1574ZM91.5485 45.86C92.4485 45.86 93.1918 46.0967 93.7785 46.57C94.3718 47.0433 94.7552 47.6833 94.9285 48.49H93.1185C92.9852 48.1633 92.7785 47.9067 92.4985 47.72C92.2252 47.5333 91.8985 47.44 91.5185 47.44C91.0185 47.44 90.6152 47.6233 90.3085 47.99C90.0018 48.3567 89.8485 48.8467 89.8485 49.46C89.8485 50.0733 90.0018 50.5633 90.3085 50.93C90.6152 51.29 91.0185 51.47 91.5185 51.47C91.8985 51.47 92.2252 51.3767 92.4985 51.19C92.7785 51.0033 92.9852 50.75 93.1185 50.43H94.9285C94.7552 51.23 94.3718 51.87 93.7785 52.35C93.1918 52.8233 92.4485 53.06 91.5485 53.06C90.8618 53.06 90.2585 52.91 89.7385 52.61C89.2185 52.3033 88.8152 51.8767 88.5285 51.33C88.2485 50.7833 88.1085 50.16 88.1085 49.46C88.1085 48.76 88.2485 48.1367 88.5285 47.59C88.8152 47.0433 89.2185 46.62 89.7385 46.32C90.2585 46.0133 90.8618 45.86 91.5485 45.86ZM101.747 45.82C102.414 45.82 103.017 45.9767 103.557 46.29C104.104 46.5967 104.534 47.0267 104.847 47.58C105.16 48.1267 105.317 48.7467 105.317 49.44C105.317 50.1333 105.157 50.7567 104.837 51.31C104.524 51.8633 104.094 52.2967 103.547 52.61C103.007 52.9167 102.407 53.07 101.747 53.07C101.087 53.07 100.484 52.9167 99.9369 52.61C99.3969 52.2967 98.9669 51.8633 98.6469 51.31C98.3335 50.7567 98.1769 50.1333 98.1769 49.44C98.1769 48.7467 98.3335 48.1267 98.6469 47.58C98.9669 47.0267 99.3969 46.5967 99.9369 46.29C100.484 45.9767 101.087 45.82 101.747 45.82ZM101.747 47.41C101.187 47.41 100.74 47.5933 100.407 47.96C100.08 48.32 99.9169 48.8133 99.9169 49.44C99.9169 50.06 100.08 50.5533 100.407 50.92C100.74 51.2867 101.187 51.47 101.747 51.47C102.3 51.47 102.744 51.2867 103.077 50.92C103.41 50.5533 103.577 50.06 103.577 49.44C103.577 48.82 103.41 48.3267 103.077 47.96C102.75 47.5933 102.307 47.41 101.747 47.41ZM112.408 53L110.878 50.33H110.488V53H108.778V45.93H111.698C112.258 45.93 112.731 46.0267 113.118 46.22C113.504 46.4133 113.794 46.68 113.988 47.02C114.181 47.3533 114.278 47.7367 114.278 48.17C114.278 48.6833 114.134 49.12 113.848 49.48C113.568 49.84 113.158 50.0867 112.618 50.22L114.298 53H112.408ZM110.488 49.16H111.548C111.888 49.16 112.138 49.0867 112.298 48.94C112.458 48.7867 112.538 48.5633 112.538 48.27C112.538 47.99 112.454 47.77 112.288 47.61C112.128 47.45 111.881 47.37 111.548 47.37H110.488V49.16ZM123.995 49.45C123.995 50.1433 123.845 50.76 123.545 51.3C123.252 51.8333 122.825 52.25 122.265 52.55C121.712 52.85 121.058 53 120.305 53H117.635V45.93H120.305C121.065 45.93 121.722 46.0767 122.275 46.37C122.828 46.6633 123.252 47.0767 123.545 47.61C123.845 48.1433 123.995 48.7567 123.995 49.45ZM120.155 51.47C120.822 51.47 121.338 51.2933 121.705 50.94C122.078 50.5867 122.265 50.09 122.265 49.45C122.265 48.81 122.078 48.3133 121.705 47.96C121.338 47.6067 120.822 47.43 120.155 47.43H119.345V51.47H120.155ZM129.179 45.93V53H127.469V45.93H129.179ZM139.14 53H137.43L134.57 48.66V53H132.86V45.93H134.57L137.43 50.31V45.93H139.14V53ZM146.13 45.86C147.017 45.86 147.747 46.0767 148.32 46.51C148.894 46.9433 149.25 47.53 149.39 48.27H147.58C147.46 48.0167 147.277 47.8167 147.03 47.67C146.784 47.5167 146.487 47.44 146.14 47.44C145.6 47.44 145.167 47.6233 144.84 47.99C144.514 48.35 144.35 48.84 144.35 49.46C144.35 50.1333 144.52 50.65 144.86 51.01C145.207 51.37 145.697 51.55 146.33 51.55C146.737 51.55 147.094 51.44 147.4 51.22C147.707 50.9933 147.924 50.6733 148.05 50.26H145.89V49.03H149.48V50.72C149.347 51.1333 149.134 51.5167 148.84 51.87C148.547 52.2233 148.17 52.51 147.71 52.73C147.257 52.95 146.737 53.06 146.15 53.06C145.437 53.06 144.814 52.91 144.28 52.61C143.747 52.3033 143.334 51.8767 143.04 51.33C142.754 50.7833 142.61 50.16 142.61 49.46C142.61 48.76 142.754 48.1367 143.04 47.59C143.334 47.0433 143.744 46.62 144.27 46.32C144.804 46.0133 145.424 45.86 146.13 45.86ZM162.52 51.01C162.52 51.3833 162.423 51.7267 162.23 52.04C162.043 52.3533 161.763 52.6033 161.39 52.79C161.023 52.9767 160.576 53.07 160.05 53.07C159.256 53.07 158.603 52.8767 158.09 52.49C157.576 52.1033 157.296 51.5633 157.25 50.87H159.07C159.096 51.1367 159.19 51.3467 159.35 51.5C159.516 51.6533 159.726 51.73 159.98 51.73C160.2 51.73 160.373 51.67 160.5 51.55C160.626 51.43 160.69 51.27 160.69 51.07C160.69 50.89 160.63 50.74 160.51 50.62C160.396 50.5 160.253 50.4033 160.08 50.33C159.906 50.25 159.666 50.1567 159.36 50.05C158.913 49.8967 158.546 49.75 158.26 49.61C157.98 49.4633 157.736 49.25 157.53 48.97C157.33 48.6833 157.23 48.3133 157.23 47.86C157.23 47.44 157.336 47.0767 157.55 46.77C157.763 46.4633 158.056 46.23 158.43 46.07C158.81 45.9033 159.243 45.82 159.73 45.82C160.516 45.82 161.14 46.0067 161.6 46.38C162.066 46.7533 162.33 47.2667 162.39 47.92H160.54C160.506 47.6867 160.42 47.5033 160.28 47.37C160.146 47.23 159.963 47.16 159.73 47.16C159.53 47.16 159.366 47.2133 159.24 47.32C159.12 47.4267 159.06 47.5833 159.06 47.79C159.06 47.9567 159.113 48.1 159.22 48.22C159.333 48.3333 159.473 48.4267 159.64 48.5C159.806 48.5733 160.046 48.6667 160.36 48.78C160.813 48.9333 161.183 49.0867 161.47 49.24C161.756 49.3867 162.003 49.6033 162.21 49.89C162.416 50.1767 162.52 50.55 162.52 51.01ZM171.045 45.93V47.29H169.125V53H167.405V47.29H165.505V45.93H171.045ZM175.926 45.93V50.01C175.926 50.4767 176.029 50.8333 176.236 51.08C176.449 51.3267 176.756 51.45 177.156 51.45C177.556 51.45 177.859 51.3267 178.066 51.08C178.279 50.8333 178.386 50.4767 178.386 50.01V45.93H180.096V50.01C180.096 50.6767 179.966 51.24 179.706 51.7C179.446 52.1533 179.089 52.4967 178.636 52.73C178.189 52.9567 177.682 53.07 177.116 53.07C176.549 53.07 176.049 52.9567 175.616 52.73C175.182 52.5033 174.842 52.16 174.596 51.7C174.349 51.24 174.226 50.6767 174.226 50.01V45.93H175.926ZM190.098 49.45C190.098 50.1433 189.948 50.76 189.648 51.3C189.355 51.8333 188.928 52.25 188.368 52.55C187.815 52.85 187.162 53 186.408 53H183.738V45.93H186.408C187.168 45.93 187.825 46.0767 188.378 46.37C188.932 46.6633 189.355 47.0767 189.648 47.61C189.948 48.1433 190.098 48.7567 190.098 49.45ZM186.258 51.47C186.925 51.47 187.442 51.2933 187.808 50.94C188.182 50.5867 188.368 50.09 188.368 49.45C188.368 48.81 188.182 48.3133 187.808 47.96C187.442 47.6067 186.925 47.43 186.258 47.43H185.448V51.47H186.258ZM195.282 45.93V53H193.572V45.93H195.282ZM202.323 45.82C202.99 45.82 203.593 45.9767 204.133 46.29C204.68 46.5967 205.11 47.0267 205.423 47.58C205.736 48.1267 205.893 48.7467 205.893 49.44C205.893 50.1333 205.733 50.7567 205.413 51.31C205.1 51.8633 204.67 52.2967 204.123 52.61C203.583 52.9167 202.983 53.07 202.323 53.07C201.663 53.07 201.06 52.9167 200.513 52.61C199.973 52.2967 199.543 51.8633 199.223 51.31C198.91 50.7567 198.753 50.1333 198.753 49.44C198.753 48.7467 198.91 48.1267 199.223 47.58C199.543 47.0267 199.973 46.5967 200.513 46.29C201.06 45.9767 201.663 45.82 202.323 45.82ZM202.323 47.41C201.763 47.41 201.316 47.5933 200.983 47.96C200.656 48.32 200.493 48.8133 200.493 49.44C200.493 50.06 200.656 50.5533 200.983 50.92C201.316 51.2867 201.763 51.47 202.323 51.47C202.876 51.47 203.32 51.2867 203.653 50.92C203.986 50.5533 204.153 50.06 204.153 49.44C204.153 48.82 203.986 48.3267 203.653 47.96C203.326 47.5933 202.883 47.41 202.323 47.41Z" fill="white"/><defs><linearGradient id="paint0_linear1" x1="57.1273" y1="28.8015" x2="0.997337" y2="28.8015" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint1_linear1" x1="163" y1="2" x2="163" y2="45" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="white"/><stop offset="1" stop-color="white" stop-opacity="0"/></linearGradient></defs></svg> '),



        array('icon-mail','<svg class="icon icon-mail" width="18" height="14" viewBox="0 0 18 14" xmlns="http://www.w3.org/2000/svg"><path d="M17.7363 0.734375H0.423828V13.2656H17.7363V0.734375ZM1.61133 1.92188H16.5488V2.6875L9.37695 7.29688L1.61133 2.64062V1.92188ZM12.2832 7.15625L16.5488 4.3125V10.9531L12.2832 7.15625ZM1.61133 4.3125L6.0332 7.03125L1.61133 10.9531V4.3125ZM7.12695 7.70312L9.37695 9.09375L11.2051 7.875L15.877 12.0781H2.2832L7.12695 7.70312Z"/></svg>'),
        array('icon-megaphone','<svg class="icon icon-megaphone" width="24" height="19" viewBox="0 0 24 19" xmlns="http://www.w3.org/2000/svg"><path d="M20.8828 0.851562C20.3828 0.851562 19.9375 1.00781 19.5469 1.32031C19.1719 1.61719 18.9219 1.99219 18.7969 2.44531L5.08594 6.42969C4.91406 6.07031 4.64844 5.77344 4.28906 5.53906C3.94531 5.30469 3.55469 5.1875 3.11719 5.1875C2.52344 5.1875 2.01562 5.39844 1.59375 5.82031C1.17188 6.24219 0.960938 6.75 0.960938 7.34375V11.6562C0.960938 12.25 1.17188 12.7578 1.59375 13.1797C2.01562 13.6016 2.52344 13.8125 3.11719 13.8125C3.55469 13.8125 3.94531 13.6953 4.28906 13.4609C4.64844 13.2266 4.91406 12.9297 5.08594 12.5703L6.72656 13.0391V14.3281C6.72656 14.8125 6.86719 15.25 7.14844 15.6406C7.42969 16.0156 7.79688 16.2734 8.25 16.4141L12.5859 17.7031C12.6797 17.7344 12.7812 17.7578 12.8906 17.7734C13 17.7891 13.1016 17.7969 13.1953 17.7969C13.4297 17.7969 13.6562 17.7656 13.875 17.7031C14.0938 17.625 14.2969 17.5078 14.4844 17.3516C14.7656 17.1484 14.9766 16.8984 15.1172 16.6016C15.2734 16.3047 15.3516 15.9844 15.3516 15.6406V15.5469L18.7969 16.5547C18.9219 17.0078 19.1719 17.3906 19.5469 17.7031C19.9375 18 20.3828 18.1484 20.8828 18.1484C21.4766 18.1484 21.9844 17.9375 22.4062 17.5156C22.8281 17.0938 23.0391 16.5859 23.0391 15.9922V3.00781C23.0391 2.41406 22.8281 1.90625 22.4062 1.48438C21.9844 1.0625 21.4766 0.851562 20.8828 0.851562ZM3.84375 11.6562C3.84375 11.8594 3.77344 12.0312 3.63281 12.1719C3.49219 12.3125 3.32031 12.3828 3.11719 12.3828C2.91406 12.3828 2.74219 12.3125 2.60156 12.1719C2.46094 12.0312 2.39062 11.8594 2.39062 11.6562V7.34375C2.39062 7.14062 2.46094 6.96875 2.60156 6.82812C2.74219 6.6875 2.91406 6.61719 3.11719 6.61719C3.32031 6.61719 3.49219 6.6875 3.63281 6.82812C3.77344 6.96875 3.84375 7.14062 3.84375 7.34375V11.6562ZM13.9219 15.6406C13.9219 15.75 13.8906 15.8594 13.8281 15.9688C13.7812 16.0625 13.7188 16.1406 13.6406 16.2031C13.5469 16.2812 13.4375 16.3281 13.3125 16.3438C13.2031 16.3594 13.0938 16.3516 12.9844 16.3203L8.67188 15.0312C8.51562 14.9844 8.39062 14.8984 8.29688 14.7734C8.20312 14.6328 8.15625 14.4844 8.15625 14.3281V13.4609L13.9219 15.125V15.6406ZM18.7266 15.0312L14.8594 13.9062L5.27344 11.1172V7.88281L18.7266 3.96875V15.0312ZM21.6094 15.9922C21.6094 16.1797 21.5391 16.3438 21.3984 16.4844C21.2578 16.625 21.0859 16.6953 20.8828 16.6953C20.6797 16.6953 20.5078 16.625 20.3672 16.4844C20.2266 16.3438 20.1562 16.1797 20.1562 15.9922V3.00781C20.1562 2.82031 20.2266 2.65625 20.3672 2.51562C20.5078 2.375 20.6797 2.30469 20.8828 2.30469C21.0859 2.30469 21.2578 2.375 21.3984 2.51562C21.5391 2.65625 21.6094 2.82031 21.6094 3.00781V15.9922Z"/></svg>'),
        array('icon-menu','<svg class="icon icon-menu" width="19" height="16" viewBox="0 0 19 16" xmlns="http://www.w3.org/2000/svg"><path d="M1.28711 2.67578H17.2129C17.4941 2.67578 17.7344 2.57031 17.9336 2.35938C18.1445 2.14844 18.25 1.89648 18.25 1.60352C18.25 1.31055 18.1445 1.06445 17.9336 0.865234C17.7344 0.654297 17.4941 0.548828 17.2129 0.548828H1.28711C1.00586 0.548828 0.759766 0.654297 0.548828 0.865234C0.349609 1.06445 0.25 1.31055 0.25 1.60352C0.25 1.89648 0.349609 2.14844 0.548828 2.35938C0.759766 2.57031 1.00586 2.67578 1.28711 2.67578ZM17.2129 7.05273H1.28711C1.00586 7.05273 0.759766 7.1582 0.548828 7.36914C0.349609 7.58008 0.25 7.83203 0.25 8.125C0.25 8.41797 0.349609 8.66992 0.548828 8.88086C0.759766 9.0918 1.00586 9.19727 1.28711 9.19727H17.2129C17.4941 9.19727 17.7344 9.0918 17.9336 8.88086C18.1445 8.66992 18.25 8.41797 18.25 8.125C18.25 7.83203 18.1445 7.58008 17.9336 7.36914C17.7344 7.1582 17.4941 7.05273 17.2129 7.05273ZM17.2129 13.5742H1.28711C1.00586 13.5742 0.759766 13.6797 0.548828 13.8906C0.349609 14.1016 0.25 14.3535 0.25 14.6465C0.25 14.9395 0.349609 15.1914 0.548828 15.4023C0.759766 15.6016 1.00586 15.7012 1.28711 15.7012H17.2129C17.4941 15.7012 17.7344 15.6016 17.9336 15.4023C18.1445 15.1914 18.25 14.9395 18.25 14.6465C18.25 14.3535 18.1445 14.1016 17.9336 13.8906C17.7344 13.6797 17.4941 13.5742 17.2129 13.5742Z" /></svg>'),
        array('icon-mic1','<svg class="icon icon-mic" width="11" height="14" viewBox="0 0 11 14" xmlns="http://www.w3.org/2000/svg"><path d="M2.77197 0.8125C2.4165 0.8125 2.07796 0.88444 1.75635 1.02832C1.43473 1.16374 1.15544 1.34993 0.918457 1.58691C0.681478 1.82389 0.491048 2.10319 0.347168 2.4248C0.211751 2.73796 0.144043 3.0765 0.144043 3.44043C0.144043 3.80436 0.211751 4.14714 0.347168 4.46875C0.491048 4.79036 0.681478 5.06966 0.918457 5.30664C1.15544 5.54362 1.43473 5.72982 1.75635 5.86523C2.07796 6.00065 2.4165 6.06836 2.77197 6.06836C3.1359 6.06836 3.47868 6.00065 3.80029 5.86523C4.12191 5.72982 4.4012 5.54362 4.63818 5.30664C4.87516 5.06966 5.06136 4.79036 5.19678 4.46875C5.34066 4.14714 5.4126 3.80436 5.4126 3.44043C5.4126 3.0765 5.34066 2.73796 5.19678 2.4248C5.06136 2.10319 4.87516 1.82389 4.63818 1.58691C4.4012 1.34993 4.12191 1.16374 3.80029 1.02832C3.47868 0.88444 3.1359 0.8125 2.77197 0.8125ZM3.92725 6.62695L8.68799 10.6768L9.88135 9.44531L5.83154 4.76074C5.53532 5.31934 5.14176 5.77214 4.65088 6.11914C4.16846 6.45768 3.92725 6.62695 3.92725 6.62695ZM10.605 10.3721L10.1353 9.7373L9.03076 10.8926L9.66553 11.3242L10.605 10.3721ZM10.8462 10.7529L9.98291 11.5908L10.4019 11.667C10.4272 11.7855 10.4399 11.9759 10.4399 12.2383C10.4484 12.4922 10.3807 12.7207 10.2368 12.9238C10.1353 13.0508 9.99984 13.1481 9.83057 13.2158C9.66976 13.2835 9.4751 13.3216 9.24658 13.3301C8.28174 13.3555 7.56657 13.2962 7.10107 13.1523C6.64404 13.0169 6.15316 12.6657 5.62842 12.0986C5.31527 11.7686 4.96403 11.5273 4.57471 11.375C4.18538 11.2227 3.81299 11.1253 3.45752 11.083C3.11051 11.0322 2.81006 11.0153 2.55615 11.0322C2.31071 11.0407 2.17529 11.0492 2.1499 11.0576C2.09066 11.0661 2.03988 11.0957 1.99756 11.1465C1.95524 11.1973 1.93831 11.2565 1.94678 11.3242C1.95524 11.3835 1.98486 11.4342 2.03564 11.4766C2.08643 11.5189 2.14567 11.5358 2.21338 11.5273C2.22184 11.5273 2.3361 11.5189 2.55615 11.502C2.7762 11.485 3.04281 11.4977 3.35596 11.54C3.66911 11.5824 3.99919 11.667 4.34619 11.7939C4.70166 11.9209 5.01058 12.1283 5.27295 12.416C5.82308 13.0085 6.33512 13.3893 6.80908 13.5586C7.2915 13.7279 7.91357 13.8125 8.67529 13.8125C8.75993 13.8125 8.85303 13.8125 8.95459 13.8125C9.05615 13.8125 9.15771 13.8083 9.25928 13.7998C9.56396 13.7998 9.83057 13.749 10.0591 13.6475C10.2876 13.5459 10.4738 13.3978 10.6177 13.2031C10.7869 12.9661 10.88 12.7122 10.897 12.4414C10.9224 12.1706 10.9224 11.9421 10.897 11.7559L10.9858 11.7686L10.8462 10.7529Z" /></svg>'),
        array('icon-mic','<svg class="icon icon-mic" width="14" height="16" viewBox="0 0 14 16" xmlns="http://www.w3.org/2000/svg"><path d="M3.6425 0C3.205 0 2.78833 0.0885417 2.3925 0.265625C1.99667 0.432292 1.65292 0.661458 1.36125 0.953125C1.06958 1.24479 0.835208 1.58854 0.658125 1.98438C0.491458 2.36979 0.408125 2.78646 0.408125 3.23438C0.408125 3.68229 0.491458 4.10417 0.658125 4.5C0.835208 4.89583 1.06958 5.23958 1.36125 5.53125C1.65292 5.82292 1.99667 6.05208 2.3925 6.21875C2.78833 6.38542 3.205 6.46875 3.6425 6.46875C4.09042 6.46875 4.51229 6.38542 4.90812 6.21875C5.30396 6.05208 5.64771 5.82292 5.93937 5.53125C6.23104 5.23958 6.46021 4.89583 6.62687 4.5C6.80396 4.10417 6.8925 3.68229 6.8925 3.23438C6.8925 2.78646 6.80396 2.36979 6.62687 1.98438C6.46021 1.58854 6.23104 1.24479 5.93937 0.953125C5.64771 0.661458 5.30396 0.432292 4.90812 0.265625C4.51229 0.0885417 4.09042 0 3.6425 0ZM5.06437 7.15625L10.9237 12.1406L12.3925 10.625L7.40812 4.85938C7.04354 5.54688 6.55917 6.10417 5.955 6.53125C5.36125 6.94792 5.06437 7.15625 5.06437 7.15625ZM13.2831 11.7656L12.705 10.9844L11.3456 12.4062L12.1269 12.9375L13.2831 11.7656ZM13.58 12.2344L12.5175 13.2656L13.0331 13.3594C13.0644 13.5052 13.08 13.7396 13.08 14.0625C13.0904 14.375 13.0071 14.6562 12.83 14.9062C12.705 15.0625 12.5383 15.1823 12.33 15.2656C12.1321 15.349 11.8925 15.3958 11.6112 15.4062C10.4237 15.4375 9.54354 15.3646 8.97062 15.1875C8.40812 15.0208 7.80396 14.5885 7.15812 13.8906C6.77271 13.4844 6.34042 13.1875 5.86125 13C5.38208 12.8125 4.92375 12.6927 4.48625 12.6406C4.05917 12.5781 3.68937 12.5573 3.37687 12.5781C3.07479 12.5885 2.90812 12.599 2.87687 12.6094C2.80396 12.6198 2.74146 12.6562 2.68937 12.7188C2.63729 12.7812 2.61646 12.8542 2.62687 12.9375C2.63729 13.0104 2.67375 13.0729 2.73625 13.125C2.79875 13.1771 2.87167 13.1979 2.955 13.1875C2.96542 13.1875 3.10604 13.1771 3.37687 13.1562C3.64771 13.1354 3.97583 13.151 4.36125 13.2031C4.74667 13.2552 5.15292 13.3594 5.58 13.5156C6.0175 13.6719 6.39771 13.9271 6.72062 14.2812C7.39771 15.0104 8.02792 15.4792 8.61125 15.6875C9.205 15.8958 9.97062 16 10.9081 16C11.0123 16 11.1269 16 11.2519 16C11.3769 16 11.5019 15.9948 11.6269 15.9844C12.0019 15.9844 12.33 15.9219 12.6112 15.7969C12.8925 15.6719 13.1217 15.4896 13.2987 15.25C13.5071 14.9583 13.6217 14.6458 13.6425 14.3125C13.6737 13.9792 13.6737 13.6979 13.6425 13.4688L13.7519 13.4844L13.58 12.2344Z"/></svg>'),
        array('icon-mission',' <svg class="icon icon-mission" width="58" height="53" viewBox="0 0 58 53" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M35.4449 13.8542C35.6661 14.0735 35.956 14.1831 36.2459 14.1831C36.5358 14.1831 36.8258 14.0735 37.0469 13.8542C37.4892 13.4157 37.4892 12.7047 37.0469 12.2661L37.0316 12.2509C36.5892 11.8124 35.8719 11.8124 35.4295 12.2509C34.9871 12.6894 34.9871 13.4004 35.4295 13.839L35.4449 13.8542Z" fill="url(#paint0_linear)"/><path d="M53.7203 24.4786L57.6687 20.5648C57.9927 20.2436 58.0896 19.7606 57.9142 19.3411C57.7389 18.9214 57.3258 18.6479 56.8676 18.6479H48.6829C47.6131 14.3068 45.3678 10.3513 42.158 7.16947C37.4938 2.546 31.2923 -0.000244141 24.6959 -0.000244141C18.0995 -0.000244141 11.898 2.546 7.23372 7.16947C2.56937 11.7929 0.000610352 17.94 0.000610352 24.4786C0.000610352 31.0171 2.56937 37.1643 7.23372 41.7877C8.62074 43.1625 10.1445 44.3521 11.7734 45.3472L8.36053 51.3237C8.16206 51.6714 8.16478 52.0974 8.36778 52.4424C8.57067 52.7875 8.94325 52.9998 9.3463 52.9998H15.1803C15.5884 52.9998 15.9651 52.7821 16.1662 52.43L18.5793 48.204C20.5543 48.7007 22.6052 48.9574 24.6959 48.9574C26.7866 48.9574 28.8375 48.7007 30.8125 48.204L33.2256 52.43C33.4267 52.7821 33.8034 52.9998 34.2115 52.9998H40.0455C40.4485 52.9998 40.8211 52.7875 41.0241 52.4425C41.2271 52.0974 41.2298 51.6714 41.0314 51.3239L37.6185 45.3473C39.2474 44.3521 40.7712 43.1626 42.1582 41.7878C45.3668 38.6073 47.6132 34.6501 48.6829 30.3094H56.8677C57.3258 30.3094 57.739 30.0357 57.9143 29.6162C58.0897 29.1967 57.9927 28.7136 57.6689 28.3925L53.7203 24.4786ZM51.649 23.3557H43.7432L46.227 20.8937H54.1329L51.649 23.3557ZM14.5197 50.754H11.2892L13.7549 46.4362C14.6011 46.8514 15.4698 47.2187 16.3586 47.5338L14.5197 50.754ZM38.1026 50.754H34.8721L33.0332 47.5338C33.922 47.2187 34.7907 46.8514 35.6369 46.4362L38.1026 50.754ZM40.556 40.1997C39.0596 41.683 37.3883 42.9296 35.5891 43.9234C35.5669 43.9341 35.5445 43.9442 35.5226 43.9564C35.5089 43.9642 35.4965 43.973 35.4832 43.9812C34.1031 44.7338 32.6488 45.338 31.1398 45.7842C31.0804 45.7959 31.0217 45.8132 30.9639 45.8348C28.9527 46.4117 26.8477 46.7116 24.6959 46.7116C22.5441 46.7116 20.4391 46.4117 18.4279 45.8349C18.3699 45.8133 18.3113 45.796 18.2518 45.7843C16.7429 45.3381 15.2886 44.7339 13.9086 43.9813C13.8953 43.9731 13.8829 43.9643 13.8692 43.9565C13.8473 43.9443 13.825 43.9342 13.8028 43.9235C12.0037 42.9298 10.3323 41.6831 8.83586 40.1997C4.59937 36.0005 2.26623 30.4173 2.26623 24.4786C2.26623 18.5399 4.59937 12.9567 8.83574 8.75744C13.0721 4.55821 18.7047 2.24552 24.6959 2.24552C30.6871 2.24552 36.3197 4.55821 40.556 8.75744C43.3397 11.5167 45.3251 14.9158 46.3445 18.6479H45.7579C45.4575 18.6479 45.1693 18.7662 44.9569 18.9768L41.9503 21.957C41.6469 19.9155 40.9811 17.9305 39.9756 16.1252C39.6732 15.5823 38.984 15.3854 38.4363 15.6849C37.8886 15.9846 37.6898 16.6678 37.9922 17.2107C39.0675 19.1414 39.6683 21.2405 39.822 23.3558H34.8272C34.575 21.0813 33.5611 18.9742 31.9051 17.3328C29.9794 15.4239 27.4192 14.3726 24.6959 14.3726C21.9726 14.3726 19.4123 15.4239 17.4868 17.3326C15.5611 19.2415 14.5006 21.7792 14.5006 24.4786C14.5006 27.178 15.5611 29.7158 17.4867 31.6245C19.4124 33.5333 21.9726 34.5845 24.6959 34.5845C27.4192 34.5845 29.9794 33.5333 31.905 31.6246C33.5609 29.9832 34.5749 27.8761 34.8271 25.6014H39.817C39.5468 29.1116 38.0525 32.518 35.4295 35.1181C32.5625 37.9601 28.7505 39.5252 24.6959 39.5252C20.6413 39.5252 16.8293 37.9601 13.9623 35.1181C11.0951 32.2762 9.51622 28.4977 9.51622 24.4786C9.51622 20.4594 11.0951 16.6809 13.9623 13.839C18.7181 9.12496 26.147 8.08046 32.0281 11.299C32.5757 11.5986 33.2649 11.4016 33.5674 10.8587C33.8697 10.3158 33.6709 9.63273 33.1232 9.33292C29.8783 7.55708 26.0574 6.84933 22.3648 7.34048C18.5489 7.8478 15.0893 9.54582 12.3603 12.2511C9.06525 15.5172 7.2506 19.8596 7.2506 24.4786C7.2506 29.0975 9.06525 33.4401 12.3601 36.7061C15.6552 39.9722 20.0361 41.7709 24.6959 41.7709C29.3557 41.7709 33.7366 39.9722 37.0315 36.7062C39.7089 34.0524 41.4075 30.7016 41.9543 27.0043L44.9568 29.9805C45.1692 30.191 45.4574 30.3094 45.7578 30.3094H46.3441C45.3247 34.0413 43.3386 37.4416 40.556 40.1997ZM28.3957 22.3613C28.0829 21.8241 27.3901 21.6401 26.8482 21.9503L24.1295 23.5062C23.779 23.7067 23.5631 24.0774 23.5631 24.4786C23.5631 24.8798 23.779 25.2504 24.1295 25.451L26.8482 27.0068C27.0267 27.1089 27.2214 27.1574 27.4136 27.1574C27.8051 27.1574 28.1859 26.9561 28.3957 26.5959C28.5795 26.2803 28.59 25.9135 28.4585 25.6014H32.5448C32.3048 27.2749 31.5303 28.8201 30.303 30.0365C28.8053 31.5212 26.814 32.3387 24.6959 32.3387C22.5778 32.3387 20.5865 31.5212 19.0887 30.0365C17.591 28.5519 16.7662 26.5781 16.7662 24.4786C16.7662 22.379 17.591 20.4052 19.0888 18.9205C20.5865 17.436 22.5778 16.6184 24.6959 16.6184C26.814 16.6184 28.8053 17.436 30.3031 18.9206C31.5303 20.1371 32.3049 21.6823 32.5449 23.3557H28.4586C28.59 23.0435 28.5795 22.6768 28.3957 22.3613ZM46.227 28.0635L43.7432 25.6014H51.649L54.1329 28.0635H46.227Z" fill="url(#paint0_linear)"/><defs><linearGradient id="paint0_linear" x1="58.1325" y1="28.2679" x2="-0.00214786" y2="28.2679" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint1_linear" x1="58.1325" y1="28.2679" x2="-0.00214786" y2="28.2679" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient></defs></svg>'),
        array('icon-notes','<svg class="icon icon-notes" width="18" height="23" viewBox="0 0 18 23" xmlns="http://www.w3.org/2000/svg"><path d="M17.0156 0.578125C16.9375 0.515625 16.8438 0.476562 16.7344 0.460938C16.625 0.429687 16.5156 0.429687 16.4062 0.460938L6.72656 3.25C6.58594 3.28125 6.46875 3.35937 6.375 3.48438C6.28125 3.60938 6.23438 3.75 6.23438 3.90625V16.3516C5.9375 16.1328 5.61719 15.9609 5.27344 15.8359C4.92969 15.7109 4.5625 15.6484 4.17188 15.6484C3.21875 15.6484 2.39844 15.9922 1.71094 16.6797C1.03906 17.3516 0.703125 18.1641 0.703125 19.1172C0.703125 20.0703 1.03906 20.8828 1.71094 21.5547C2.39844 22.2266 3.21875 22.5625 4.17188 22.5625C5.10938 22.5625 5.91406 22.2266 6.58594 21.5547C7.27344 20.8828 7.61719 20.0703 7.61719 19.1172V7.1875L15.9141 4.79688V13.5859C15.6172 13.3672 15.2891 13.1953 14.9297 13.0703C14.5859 12.9453 14.2188 12.8828 13.8281 12.8828C12.875 12.8828 12.0625 13.2266 11.3906 13.9141C10.7188 14.5859 10.3828 15.3984 10.3828 16.3516C10.3828 17.3047 10.7188 18.1172 11.3906 18.7891C12.0625 19.4609 12.875 19.7969 13.8281 19.7969C14.7812 19.7969 15.5938 19.4609 16.2656 18.7891C16.9531 18.1172 17.2969 17.3047 17.2969 16.3516V1.11719C17.2969 1.02344 17.2734 0.929688 17.2266 0.835938C17.1797 0.726563 17.1094 0.640625 17.0156 0.578125ZM4.17188 21.1797C3.59375 21.1797 3.10156 20.9766 2.69531 20.5703C2.28906 20.1641 2.08594 19.6797 2.08594 19.1172C2.08594 18.5391 2.28906 18.0469 2.69531 17.6406C3.10156 17.2344 3.59375 17.0312 4.17188 17.0312C4.73438 17.0312 5.21875 17.2344 5.625 17.6406C6.03125 18.0469 6.23438 18.5391 6.23438 19.1172C6.23438 19.6797 6.03125 20.1641 5.625 20.5703C5.21875 20.9766 4.73438 21.1797 4.17188 21.1797ZM13.8281 18.4141C13.2656 18.4141 12.7812 18.2109 12.375 17.8047C11.9688 17.3984 11.7656 16.9141 11.7656 16.3516C11.7656 15.7734 11.9688 15.2812 12.375 14.875C12.7812 14.4688 13.2656 14.2656 13.8281 14.2656C14.4062 14.2656 14.8984 14.4688 15.3047 14.875C15.7109 15.2812 15.9141 15.7734 15.9141 16.3516C15.9141 16.9141 15.7109 17.3984 15.3047 17.8047C14.8984 18.2109 14.4062 18.4141 13.8281 18.4141ZM15.9141 3.36719L7.61719 5.73438V4.42188L15.9141 2.05469V3.36719Z"/></svg>'),
        array('icon-phone','<svg class="icon icon-phone" width="20" height="21" viewBox="0 0 20 21" xmlns="http://www.w3.org/2000/svg"><path d="M19.9609 15.7383C19.9349 15.6602 19.8307 15.5625 19.6484 15.4453C19.4661 15.3151 19.2122 15.1654 18.8867 14.9961C18.7956 14.944 18.6849 14.8854 18.5547 14.8203C18.4245 14.7422 18.2747 14.6576 18.1055 14.5664C17.9492 14.4753 17.793 14.3906 17.6367 14.3125C17.4805 14.2214 17.3372 14.1432 17.207 14.0781C17.0768 14 16.9466 13.9284 16.8164 13.8633C16.6862 13.7852 16.5625 13.707 16.4453 13.6289C16.4323 13.6159 16.3932 13.5898 16.3281 13.5508C16.276 13.5117 16.1979 13.4531 16.0938 13.375C15.9896 13.3099 15.8919 13.2513 15.8008 13.1992C15.7227 13.1471 15.651 13.1081 15.5859 13.082C15.5208 13.043 15.4557 13.0169 15.3906 13.0039C15.3255 12.9909 15.2539 12.9844 15.1758 12.9844C15.0846 12.9844 14.9805 13.0169 14.8633 13.082C14.7461 13.1471 14.6159 13.2448 14.4727 13.375C14.3294 13.5182 14.1927 13.6615 14.0625 13.8047C13.9323 13.9479 13.8086 14.0977 13.6914 14.2539C13.5742 14.4232 13.4505 14.5794 13.3203 14.7227C13.2031 14.8659 13.0794 15.0091 12.9492 15.1523C12.806 15.2826 12.6823 15.3802 12.5781 15.4453C12.474 15.5104 12.3763 15.543 12.2852 15.543C12.2461 15.543 12.2005 15.5365 12.1484 15.5234C12.0964 15.5104 12.0378 15.4974 11.9727 15.4844C11.9076 15.4583 11.849 15.4388 11.7969 15.4258C11.7448 15.3997 11.7057 15.3737 11.6797 15.3477C11.6406 15.3346 11.5951 15.3151 11.543 15.2891C11.4909 15.25 11.4193 15.2044 11.3281 15.1523C11.25 15.1003 11.1849 15.0612 11.1328 15.0352C11.0938 15.0091 11.0742 14.9961 11.0742 14.9961C10.4232 14.6315 9.81771 14.2474 9.25781 13.8438C8.69792 13.4271 8.1901 12.9844 7.73438 12.5156C7.26562 12.0599 6.82292 11.5521 6.40625 10.9922C6.0026 10.4323 5.61849 9.82682 5.25391 9.17578C5.25391 9.17578 5.24089 9.15625 5.21484 9.11719C5.1888 9.0651 5.14974 9 5.09766 8.92188C5.04557 8.83073 5 8.75911 4.96094 8.70703C4.9349 8.65495 4.91536 8.60938 4.90234 8.57031C4.8763 8.54427 4.85026 8.50521 4.82422 8.45312C4.8112 8.40104 4.79167 8.34245 4.76562 8.27734C4.7526 8.21224 4.73958 8.15365 4.72656 8.10156C4.71354 8.04948 4.70703 8.00391 4.70703 7.96484C4.70703 7.8737 4.73958 7.77604 4.80469 7.67188C4.86979 7.56771 4.96745 7.44401 5.09766 7.30078C5.24089 7.17057 5.38411 7.04688 5.52734 6.92969C5.67057 6.79948 5.82682 6.67578 5.99609 6.55859C6.15234 6.44141 6.30208 6.31771 6.44531 6.1875C6.58854 6.05729 6.73177 5.92057 6.875 5.77734C7.00521 5.63411 7.10286 5.50391 7.16797 5.38672C7.23307 5.26953 7.26562 5.16536 7.26562 5.07422C7.26562 4.99609 7.25911 4.92448 7.24609 4.85938C7.23307 4.79427 7.20703 4.72917 7.16797 4.66406C7.14193 4.59896 7.10286 4.52734 7.05078 4.44922C6.9987 4.35807 6.9401 4.26042 6.875 4.15625C6.79688 4.05208 6.73828 3.97396 6.69922 3.92188C6.66016 3.85677 6.63411 3.81771 6.62109 3.80469C6.54297 3.6875 6.46484 3.5638 6.38672 3.43359C6.32161 3.30339 6.25 3.17318 6.17188 3.04297C6.10677 2.91276 6.02865 2.76953 5.9375 2.61328C5.85938 2.45703 5.77474 2.30078 5.68359 2.14453C5.59245 1.97526 5.50781 1.82552 5.42969 1.69531C5.36458 1.5651 5.30599 1.45443 5.25391 1.36328C5.08464 1.03776 4.9349 0.783854 4.80469 0.601562C4.6875 0.419271 4.58984 0.315104 4.51172 0.289062C4.47266 0.276042 4.42708 0.269531 4.375 0.269531C4.32292 0.25651 4.26432 0.25 4.19922 0.25C4.06901 0.25 3.91927 0.263021 3.75 0.289062C3.59375 0.315104 3.41146 0.347656 3.20312 0.386719C2.99479 0.438802 2.80599 0.490885 2.63672 0.542969C2.48047 0.595052 2.34375 0.647135 2.22656 0.699219C1.99219 0.790365 1.74479 0.985677 1.48438 1.28516C1.23698 1.57161 0.983073 1.94922 0.722656 2.41797C0.488281 2.86068 0.30599 3.30339 0.175781 3.74609C0.0585938 4.1888 0 4.63151 0 5.07422C0 5.19141 0 5.3151 0 5.44531C0.0130208 5.5625 0.0325521 5.6862 0.0585938 5.81641C0.0716146 5.93359 0.0911458 6.0638 0.117188 6.20703C0.143229 6.33724 0.182292 6.48047 0.234375 6.63672C0.273438 6.77995 0.30599 6.91016 0.332031 7.02734C0.371094 7.13151 0.403646 7.22266 0.429688 7.30078C0.455729 7.37891 0.494792 7.48307 0.546875 7.61328C0.598958 7.74349 0.657552 7.89974 0.722656 8.08203C0.800781 8.27734 0.859375 8.43359 0.898438 8.55078C0.9375 8.66797 0.963542 8.74609 0.976562 8.78516C1.14583 9.25391 1.32812 9.69661 1.52344 10.1133C1.71875 10.5169 1.93359 10.901 2.16797 11.2656C2.53255 11.8776 2.96875 12.4961 3.47656 13.1211C3.9974 13.7461 4.57682 14.3841 5.21484 15.0352C5.86589 15.6732 6.50391 16.2526 7.12891 16.7734C7.75391 17.2812 8.3724 17.7174 8.98438 18.082C9.34896 18.3164 9.73307 18.5312 10.1367 18.7266C10.5534 18.9219 10.9961 19.1042 11.4648 19.2734C11.5039 19.2865 11.582 19.3125 11.6992 19.3516C11.8164 19.3906 11.9727 19.4492 12.168 19.5273C12.3503 19.5924 12.5065 19.651 12.6367 19.7031C12.7669 19.7552 12.8711 19.7943 12.9492 19.8203C13.0273 19.8464 13.1185 19.8724 13.2227 19.8984C13.3398 19.9375 13.4701 19.9766 13.6133 20.0156C13.7695 20.0677 13.9128 20.1068 14.043 20.1328C14.1862 20.1589 14.3164 20.1784 14.4336 20.1914C14.5638 20.2174 14.6875 20.2305 14.8047 20.2305C14.9349 20.2435 15.0586 20.25 15.1758 20.25C15.6185 20.25 16.0612 20.1849 16.5039 20.0547C16.9466 19.9375 17.3893 19.7617 17.832 19.5273C18.3008 19.2669 18.6784 19.013 18.9648 18.7656C19.2643 18.5052 19.4596 18.2578 19.5508 18.0234C19.6029 17.9062 19.6549 17.7695 19.707 17.6133C19.7591 17.444 19.8112 17.2552 19.8633 17.0469C19.9023 16.8385 19.9349 16.6562 19.9609 16.5C19.987 16.3307 20 16.181 20 16.0508C20 15.9857 19.9935 15.9271 19.9805 15.875C19.9805 15.8229 19.974 15.7773 19.9609 15.7383Z"/></svg>'),
        array('icon-place','<svg class="icon icon-place" width="15" height="21" viewBox="0 0 15 21" xmlns="http://www.w3.org/2000/svg"><path d="M7.56641 0.386719C6.5638 0.347656 5.61328 0.510417 4.71484 0.875C3.82943 1.22656 3.05469 1.72786 2.39062 2.37891C1.72656 3.01693 1.19922 3.77865 0.808594 4.66406C0.43099 5.53646 0.242188 6.46745 0.242188 7.45703C0.242188 8.58984 0.476562 9.66406 0.945312 10.6797C1.42708 11.6823 2.01302 12.6784 2.70312 13.668C3.40625 14.6576 4.14844 15.6667 4.92969 16.6953C5.71094 17.724 6.40755 18.8307 7.01953 20.0156C7.08464 20.1328 7.18229 20.1914 7.3125 20.1914C7.45573 20.1914 7.5599 20.1328 7.625 20.0156C8.17188 18.9479 8.79036 17.9583 9.48047 17.0469C10.1836 16.1224 10.8607 15.224 11.5117 14.3516C12.1628 13.4661 12.7422 12.5807 13.25 11.6953C13.7708 10.7969 14.1159 9.83333 14.2852 8.80469C14.4674 7.73698 14.4219 6.70833 14.1484 5.71875C13.875 4.72917 13.4258 3.84375 12.8008 3.0625C12.1888 2.28125 11.4336 1.64974 10.5352 1.16797C9.63672 0.686198 8.64714 0.425781 7.56641 0.386719ZM7.3125 11.168C6.29688 11.168 5.42448 10.8099 4.69531 10.0938C3.96615 9.36458 3.60156 8.48568 3.60156 7.45703C3.60156 6.44141 3.96615 5.56901 4.69531 4.83984C5.42448 4.11068 6.29688 3.74609 7.3125 3.74609C8.34115 3.74609 9.21354 4.11068 9.92969 4.83984C10.6589 5.56901 11.0234 6.44141 11.0234 7.45703C11.0234 8.48568 10.6589 9.36458 9.92969 10.0938C9.21354 10.8099 8.34115 11.168 7.3125 11.168Z"/></svg>'),
        array('icon-play','<svg class="icon icon-play" width="30" height="31" viewBox="0 0 30 31" xmlns="http://www.w3.org/2000/svg"><path d="M15 0.875C12.9297 0.875 10.9766 1.26562 9.14062 2.04688C7.32422 2.82812 5.73242 3.90234 4.36523 5.26953C3.01758 6.61719 1.95312 8.20898 1.17188 10.0449C0.390625 11.8613 0 13.8047 0 15.875C0 17.9453 0.390625 19.8984 1.17188 21.7344C1.95312 23.5508 3.01758 25.1426 4.36523 26.5098C5.73242 27.8574 7.32422 28.9219 9.14062 29.7031C10.9766 30.4844 12.9297 30.875 15 30.875C17.0703 30.875 19.0137 30.4844 20.8301 29.7031C22.666 28.9219 24.2578 27.8574 25.6055 26.5098C26.9727 25.1426 28.0469 23.5508 28.8281 21.7344C29.6094 19.8984 30 17.9453 30 15.875C30 13.8047 29.6094 11.8613 28.8281 10.0449C28.0469 8.20898 26.9727 6.61719 25.6055 5.26953C24.2578 3.90234 22.666 2.82812 20.8301 2.04688C19.0137 1.26562 17.0703 0.875 15 0.875ZM15 28.0625C13.3203 28.0625 11.7383 27.75 10.2539 27.125C8.76953 26.4805 7.4707 25.6113 6.35742 24.5176C5.26367 23.4043 4.39453 22.1055 3.75 20.6211C3.125 19.1367 2.8125 17.5547 2.8125 15.875C2.8125 14.1953 3.125 12.6133 3.75 11.1289C4.39453 9.64453 5.26367 8.35547 6.35742 7.26172C7.4707 6.14844 8.76953 5.2793 10.2539 4.6543C11.7383 4.00977 13.3203 3.6875 15 3.6875C16.6797 3.6875 18.2617 4.00977 19.7461 4.6543C21.2305 5.2793 22.5195 6.14844 23.6133 7.26172C24.7266 8.35547 25.5957 9.64453 26.2207 11.1289C26.8652 12.6133 27.1875 14.1953 27.1875 15.875C27.1875 17.5547 26.8652 19.1367 26.2207 20.6211C25.5957 22.1055 24.7266 23.4043 23.6133 24.5176C22.5195 25.6113 21.2305 26.4805 19.7461 27.125C18.2617 27.75 16.6797 28.0625 15 28.0625ZM11.25 9.3125L22.5 15.875L11.25 22.4375V9.3125Z"/></svg>'),
        array('icon-play-next','<svg class="icon icon-play-next" width="18" height="16" viewBox="0 0 18 16" xmlns="http://www.w3.org/2000/svg"><path d="M1.41211 15.5801C1.19727 15.5801 1.01172 15.502 0.855469 15.3457C0.699219 15.1895 0.621094 15.0039 0.621094 14.7891V0.990234C0.621094 0.755859 0.699219 0.570312 0.855469 0.433594C1.01172 0.277344 1.19727 0.199219 1.41211 0.199219L14.2441 7.28906C14.2441 7.28906 14.3125 7.41602 14.4492 7.66992C14.6055 7.9043 14.5371 8.16797 14.2441 8.46094C14.0879 8.61719 13.3262 9.07617 11.959 9.83789C10.6113 10.5801 9.15625 11.3809 7.59375 12.2402C6.03125 13.0996 4.60547 13.8711 3.31641 14.5547C2.04688 15.2383 1.41211 15.5801 1.41211 15.5801ZM14.7422 1.04883C14.7422 0.794922 14.8203 0.589844 14.9766 0.433594C15.1523 0.257812 15.3574 0.169922 15.5918 0.169922H16.5293C16.7637 0.169922 16.959 0.257812 17.1152 0.433594C17.291 0.589844 17.3789 0.794922 17.3789 1.04883V14.7012C17.3789 14.9551 17.291 15.1699 17.1152 15.3457C16.959 15.502 16.7637 15.5801 16.5293 15.5801H15.5918C15.3574 15.5801 15.1523 15.502 14.9766 15.3457C14.8203 15.1699 14.7422 14.9551 14.7422 14.7012V1.04883Z"/></svg>'),
        array('icon-play-prev','<svg class="icon icon-play-prev" width="18" height="16" viewBox="0 0 18 16" xmlns="http://www.w3.org/2000/svg"><path d="M16.5879 15.5801C16.8027 15.5801 16.9883 15.502 17.1445 15.3457C17.3008 15.1895 17.3789 15.0039 17.3789 14.7891V0.990234C17.3789 0.755859 17.3008 0.570312 17.1445 0.433594C16.9883 0.277344 16.8027 0.199219 16.5879 0.199219L3.75586 7.28906C3.75586 7.28906 3.67773 7.41602 3.52148 7.66992C3.38477 7.9043 3.46289 8.16797 3.75586 8.46094C3.91211 8.61719 4.66406 9.07617 6.01172 9.83789C7.37891 10.5801 8.84375 11.3809 10.4062 12.2402C11.9688 13.0996 13.3848 13.8711 14.6543 14.5547C15.9434 15.2383 16.5879 15.5801 16.5879 15.5801ZM3.25781 1.04883C3.25781 0.794922 3.16992 0.589844 2.99414 0.433594C2.83789 0.257812 2.64258 0.169922 2.4082 0.169922H1.4707C1.23633 0.169922 1.03125 0.257812 0.855469 0.433594C0.699219 0.589844 0.621094 0.794922 0.621094 1.04883V14.7012C0.621094 14.9551 0.699219 15.1699 0.855469 15.3457C1.03125 15.502 1.23633 15.5801 1.4707 15.5801H2.4082C2.64258 15.5801 2.83789 15.502 2.99414 15.3457C3.16992 15.1699 3.25781 14.9551 3.25781 14.7012V1.04883Z"/></svg>'),
        array('icon-plus','<svg class="icon icon-plus" width="13" height="14" viewBox="0 0 13 14" xmlns="http://www.w3.org/2000/svg"><path d="M12.8937 9.225H8.56865V13.625H4.44365V9.225H0.118652V5.3H4.44365V0.875H8.56865V5.3H12.8937V9.225Z" /></svg>'),
        array('icon-production','<svg class="icon icon-production" width="67" height="47" viewBox="0 0 67 47" xmlns="http://www.w3.org/2000/svg"><path d="M1.49363 19.2806C0.66872 19.2806 0 19.9493 0 20.7742V25.7128C0 26.5377 0.66872 27.2064 1.49363 27.2064C2.31854 27.2064 2.98726 26.5377 2.98726 25.7128V20.7742C2.98726 19.9491 2.31854 19.2806 1.49363 19.2806Z" /><path d="M7.31306 19.2806C6.48815 19.2806 5.81943 19.9493 5.81943 20.7742V25.7128C5.81943 26.5377 6.48815 27.2064 7.31306 27.2064C8.13797 27.2064 8.80669 26.5377 8.80669 25.7128V20.7742C8.80669 19.9491 8.13818 19.2806 7.31306 19.2806Z" /><path d="M13.1325 17.1909C12.3076 17.1909 11.6389 17.8597 11.6389 18.6846V27.8021C11.6389 28.627 12.3076 29.2957 13.1325 29.2957C13.9574 29.2957 14.6261 28.627 14.6261 27.8021V18.6846C14.6261 17.8597 13.9574 17.1909 13.1325 17.1909Z" /><path d="M18.9517 14.7218C18.1268 14.7218 17.4581 15.3905 17.4581 16.2154V30.2716C17.4581 31.0965 18.1268 31.7652 18.9517 31.7652C19.7767 31.7652 20.4454 31.0965 20.4454 30.2716V16.2154C20.4454 15.3903 19.7769 14.7218 18.9517 14.7218Z" /><path d="M24.7715 10.3528C23.9466 10.3528 23.2778 11.0215 23.2778 11.8464V34.64C23.2778 35.465 23.9466 36.1337 24.7715 36.1337C25.5964 36.1337 26.2651 35.465 26.2651 34.64V11.8464C26.2651 11.0215 25.5964 10.3528 24.7715 10.3528Z" /><path d="M30.5906 0.000488281C29.7657 0.000488281 29.097 0.669208 29.097 1.49412V44.9923C29.097 45.8172 29.7657 46.4859 30.5906 46.4859C31.4155 46.4859 32.0842 45.8172 32.0842 44.9923V1.49412C32.0842 0.669208 31.4155 0.000488281 30.5906 0.000488281Z" /><path d="M36.4096 3.70456C35.5847 3.70456 34.916 4.37328 34.916 5.19819V41.2886C34.916 42.1135 35.5847 42.7822 36.4096 42.7822C37.2345 42.7822 37.9032 42.1135 37.9032 41.2886V5.19819C37.9032 4.37307 37.2345 3.70456 36.4096 3.70456Z" /><path d="M42.2288 11.1125C41.4039 11.1125 40.7351 11.7812 40.7351 12.6062V33.8804C40.7351 34.7053 41.4039 35.374 42.2288 35.374C43.0537 35.374 43.7224 34.7053 43.7224 33.8804V12.6062C43.7224 11.7812 43.0537 11.1125 42.2288 11.1125Z" /><path d="M48.0485 15.576C47.2236 15.576 46.5548 16.2447 46.5548 17.0696V29.4164C46.5548 30.2413 47.2236 30.91 48.0485 30.91C48.8734 30.91 49.5421 30.2413 49.5421 29.4164V17.0696C49.5421 16.2447 48.8734 15.576 48.0485 15.576Z" /><path d="M53.8679 17.476C53.043 17.476 52.3743 18.1448 52.3743 18.9697V27.5173C52.3743 28.3422 53.043 29.0109 53.8679 29.0109C54.6928 29.0109 55.3615 28.3422 55.3615 27.5173V18.9697C55.3615 18.1448 54.6928 17.476 53.8679 17.476Z" /><path d="M59.6872 19.2806C58.8622 19.2806 58.1935 19.9493 58.1935 20.7742V25.7128C58.1935 26.5377 58.8622 27.2064 59.6872 27.2064C60.5121 27.2064 61.1808 26.5377 61.1808 25.7128V20.7742C61.1808 19.9491 60.5121 19.2806 59.6872 19.2806Z" /><path d="M65.5064 19.2806C64.6815 19.2806 64.0128 19.9493 64.0128 20.7742V25.7128C64.0128 26.5377 64.6815 27.2064 65.5064 27.2064C66.3313 27.2064 67.0001 26.5377 67.0001 25.7128V20.7742C67.0001 19.9491 66.3313 19.2806 65.5064 19.2806Z" /></svg>'),
        array('icon-production-grad','<svg class="icon icon-production-grad" width="67" height="47" viewBox="0 0 67 47" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.49363 19.2806C0.66872 19.2806 0 19.9493 0 20.7742V25.7128C0 26.5377 0.66872 27.2064 1.49363 27.2064C2.31854 27.2064 2.98726 26.5377 2.98726 25.7128V20.7742C2.98726 19.9491 2.31854 19.2806 1.49363 19.2806Z" fill="url(#paint0_linear)"/><path d="M7.31306 19.2806C6.48815 19.2806 5.81943 19.9493 5.81943 20.7742V25.7128C5.81943 26.5377 6.48815 27.2064 7.31306 27.2064C8.13797 27.2064 8.80669 26.5377 8.80669 25.7128V20.7742C8.80669 19.9491 8.13818 19.2806 7.31306 19.2806Z" fill="url(#paint0_linear)"/><path d="M13.1325 17.1909C12.3076 17.1909 11.6389 17.8597 11.6389 18.6846V27.8021C11.6389 28.627 12.3076 29.2957 13.1325 29.2957C13.9574 29.2957 14.6261 28.627 14.6261 27.8021V18.6846C14.6261 17.8597 13.9574 17.1909 13.1325 17.1909Z" fill="url(#paint2_linear)"/><path d="M18.9517 14.7218C18.1268 14.7218 17.4581 15.3905 17.4581 16.2154V30.2716C17.4581 31.0965 18.1268 31.7652 18.9517 31.7652C19.7767 31.7652 20.4454 31.0965 20.4454 30.2716V16.2154C20.4454 15.3903 19.7769 14.7218 18.9517 14.7218Z" fill="url(#paint3_linear)"/><path d="M24.7715 10.3528C23.9466 10.3528 23.2778 11.0215 23.2778 11.8464V34.64C23.2778 35.465 23.9466 36.1337 24.7715 36.1337C25.5964 36.1337 26.2651 35.465 26.2651 34.64V11.8464C26.2651 11.0215 25.5964 10.3528 24.7715 10.3528Z" fill="url(#paint4_linear)"/><path d="M30.5906 0.000488281C29.7657 0.000488281 29.097 0.669208 29.097 1.49412V44.9923C29.097 45.8172 29.7657 46.4859 30.5906 46.4859C31.4155 46.4859 32.0842 45.8172 32.0842 44.9923V1.49412C32.0842 0.669208 31.4155 0.000488281 30.5906 0.000488281Z" fill="url(#paint5_linear)"/><path d="M36.4096 3.70456C35.5847 3.70456 34.916 4.37328 34.916 5.19819V41.2886C34.916 42.1135 35.5847 42.7822 36.4096 42.7822C37.2345 42.7822 37.9032 42.1135 37.9032 41.2886V5.19819C37.9032 4.37307 37.2345 3.70456 36.4096 3.70456Z" fill="url(#paint6_linear)"/><path d="M42.2288 11.1125C41.4039 11.1125 40.7351 11.7812 40.7351 12.6062V33.8804C40.7351 34.7053 41.4039 35.374 42.2288 35.374C43.0537 35.374 43.7224 34.7053 43.7224 33.8804V12.6062C43.7224 11.7812 43.0537 11.1125 42.2288 11.1125Z" fill="url(#paint7_linear)"/><path d="M48.0485 15.576C47.2236 15.576 46.5548 16.2447 46.5548 17.0696V29.4164C46.5548 30.2413 47.2236 30.91 48.0485 30.91C48.8734 30.91 49.5421 30.2413 49.5421 29.4164V17.0696C49.5421 16.2447 48.8734 15.576 48.0485 15.576Z" fill="url(#paint8_linear)"/><path d="M53.8679 17.476C53.043 17.476 52.3743 18.1448 52.3743 18.9697V27.5173C52.3743 28.3422 53.043 29.0109 53.8679 29.0109C54.6928 29.0109 55.3615 28.3422 55.3615 27.5173V18.9697C55.3615 18.1448 54.6928 17.476 53.8679 17.476Z" fill="url(#paint9_linear)"/><path d="M59.6872 19.2806C58.8623 19.2806 58.1935 19.9493 58.1935 20.7742V25.7128C58.1935 26.5377 58.8623 27.2064 59.6872 27.2064C60.5121 27.2064 61.1808 26.5377 61.1808 25.7128V20.7742C61.1808 19.9491 60.5121 19.2806 59.6872 19.2806Z" fill="url(#paint10_linear)"/><path d="M65.5064 19.2806C64.6815 19.2806 64.0128 19.9493 64.0128 20.7742V25.7128C64.0128 26.5377 64.6815 27.2064 65.5064 27.2064C66.3313 27.2064 67.0001 26.5377 67.0001 25.7128V20.7742C67.0001 19.9491 66.3313 19.2806 65.5064 19.2806Z" fill="url(#paint11_linear)"/><defs><linearGradient id="paint0_linear" x1="67.1524" y1="24.794" x2="-0.00318621" y2="24.794" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint1_linear" x1="67.1524" y1="24.794" x2="-0.00318621" y2="24.794" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint2_linear" x1="67.1524" y1="24.794" x2="-0.00318621" y2="24.794" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint3_linear" x1="67.1524" y1="24.794" x2="-0.00318621" y2="24.794" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint4_linear" x1="67.1524" y1="24.794" x2="-0.00318621" y2="24.794" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint5_linear" x1="67.1524" y1="24.794" x2="-0.00318621" y2="24.794" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint6_linear" x1="67.1524" y1="24.794" x2="-0.00318621" y2="24.794" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint7_linear" x1="67.1524" y1="24.794" x2="-0.00318621" y2="24.794" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint8_linear" x1="67.1524" y1="24.794" x2="-0.00318621" y2="24.794" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint9_linear" x1="67.1524" y1="24.794" x2="-0.00318621" y2="24.794" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint10_linear" x1="67.1524" y1="24.794" x2="-0.00318621" y2="24.794" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint11_linear" x1="67.1524" y1="24.794" x2="-0.00318621" y2="24.794" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient></defs></svg>'),
        array('icon-quote','<svg class="icon icon-quote" width="168" height="144" viewBox="0 0 168 144" xmlns="http://www.w3.org/2000/svg"><path d="M9.30003 143.9C3.70003 119.167 0.900024 97.6999 0.900024 79.4999C0.900024 53.3666 6.96669 33.7666 19.1 20.6999C31.2334 7.16657 48.9667 0.399902 72.3 0.399902V28.3999C60.1667 28.3999 51.3 31.6666 45.7 38.1999C40.5667 44.7332 38 54.5332 38 67.5999V83.6999H73V143.9H9.30003ZM103.8 143.9C98.2 119.167 95.4 97.6999 95.4 79.4999C95.4 53.3666 101.467 33.7666 113.6 20.6999C125.733 7.16657 143.467 0.399902 166.8 0.399902V28.3999C154.667 28.3999 145.8 31.6666 140.2 38.1999C135.067 44.7332 132.5 54.5332 132.5 67.5999V83.6999H167.5V143.9H103.8Z" /></svg>'),
        array('icon-quote-1','<svg class="icon icon-quote-1" width="170" height="165" viewBox="0 0 170 165" xmlns="http://www.w3.org/2000/svg"><path d="M85 0.447266C73.2682 0.447266 62.2005 2.43945 51.7969 6.42383C41.5039 10.2975 32.4837 15.6654 24.7363 22.5273C17.0996 29.2786 11.0677 37.2474 6.64062 46.4336C2.21354 55.5091 0 65.1934 0 75.4863C0 80.7988 0.553385 85.9453 1.66016 90.9258C2.8776 95.9062 4.5931 100.665 6.80664 105.203C9.02018 109.741 11.6764 114.057 14.7754 118.152C17.985 122.137 21.582 125.789 25.5664 129.109C24.681 134.09 22.8548 138.406 20.0879 142.059C17.321 145.711 14.4987 148.865 11.6211 151.521C8.74349 154.067 6.19792 156.225 3.98438 157.996C1.88151 159.767 0.996094 161.372 1.32812 162.811C6.08724 164.692 11.7318 165.245 18.2617 164.471C24.9023 163.696 31.4323 162.312 37.8516 160.32C44.2708 158.439 50.1921 156.336 55.6152 154.012C61.0384 151.688 64.8568 149.972 67.0703 148.865C69.9479 149.419 72.8809 149.861 75.8691 150.193C78.8574 150.525 81.901 150.691 85 150.691C96.7318 150.691 107.744 148.699 118.037 144.715C128.441 140.73 137.461 135.363 145.098 128.611C152.845 121.86 158.932 113.947 163.359 104.871C167.786 95.6849 170 85.89 170 75.4863C170 65.1934 167.786 55.5091 163.359 46.4336C158.932 37.2474 152.845 29.2786 145.098 22.5273C137.461 15.6654 128.441 10.2975 118.037 6.42383C107.744 2.43945 96.7318 0.447266 85 0.447266ZM79.0234 78.6406C79.0234 88.8229 76.7546 96.7917 72.2168 102.547C67.7897 108.191 61.0938 111.567 52.1289 112.674C52.1289 112.674 52.0736 112.674 51.9629 112.674C51.9629 112.674 51.9076 112.674 51.7969 112.674C51.6862 112.674 51.5755 112.618 51.4648 112.508C51.3542 112.397 51.2435 112.286 51.1328 112.176C51.1328 112.065 51.1328 111.954 51.1328 111.844V101.551C51.1328 101.329 51.1882 101.163 51.2988 101.053C51.4095 100.942 51.5202 100.831 51.6309 100.721C55.7259 98.5072 58.7695 95.6849 60.7617 92.2539C62.8646 88.7122 63.9714 84.4512 64.082 79.4707H51.9629C51.7415 79.4707 51.5202 79.4154 51.2988 79.3047C51.1882 79.0833 51.1328 78.862 51.1328 78.6406V52.5762C51.1328 52.3548 51.1882 52.1888 51.2988 52.0781C51.5202 51.8568 51.7415 51.7461 51.9629 51.7461H78.1934C78.4147 51.7461 78.5807 51.8568 78.6914 52.0781C78.9128 52.1888 79.0234 52.3548 79.0234 52.5762V78.6406ZM125.176 78.6406C125.176 88.7122 123.073 96.4596 118.867 101.883C114.661 107.195 107.855 110.792 98.4473 112.674C98.4473 112.674 98.3919 112.674 98.2812 112.674C98.1706 112.674 98.0599 112.674 97.9492 112.674C97.8385 112.674 97.7832 112.618 97.7832 112.508C97.6725 112.397 97.5618 112.286 97.4512 112.176C97.4512 112.065 97.4512 111.954 97.4512 111.844V101.551C97.4512 101.329 97.4512 101.163 97.4512 101.053C97.5618 100.942 97.6725 100.831 97.7832 100.721C101.878 98.5072 104.922 95.6849 106.914 92.2539C109.017 88.7122 110.124 84.4512 110.234 79.4707H98.2812C98.0599 79.4707 97.8385 79.4154 97.6172 79.3047C97.5065 79.0833 97.4512 78.862 97.4512 78.6406V52.5762C97.4512 52.3548 97.5065 52.1888 97.6172 52.0781C97.8385 51.8568 98.0599 51.7461 98.2812 51.7461H124.346C124.567 51.7461 124.733 51.8568 124.844 52.0781C125.065 52.1888 125.176 52.3548 125.176 52.5762V78.6406Z" /></svg>'),
        array('icon-quote-post','<svg class="icon icon-quote-post" width="170" height="165" viewBox="0 0 170 165" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M85 0.447266C73.2682 0.447266 62.2005 2.43945 51.7969 6.42383C41.5039 10.2975 32.4837 15.6654 24.7363 22.5273C17.0996 29.2786 11.0677 37.2474 6.64062 46.4336C2.21354 55.5091 0 65.1934 0 75.4863C0 80.7988 0.553385 85.9453 1.66016 90.9258C2.8776 95.9062 4.5931 100.665 6.80664 105.203C9.02018 109.741 11.6764 114.057 14.7754 118.152C17.985 122.137 21.582 125.789 25.5664 129.109C24.681 134.09 22.8548 138.406 20.0879 142.059C17.321 145.711 14.4987 148.865 11.6211 151.521C8.74349 154.067 6.19792 156.225 3.98438 157.996C1.88151 159.767 0.996094 161.372 1.32812 162.811C6.08724 164.692 11.7318 165.245 18.2617 164.471C24.9023 163.696 31.4323 162.312 37.8516 160.32C44.2708 158.439 50.1921 156.336 55.6152 154.012C61.0384 151.688 64.8568 149.972 67.0703 148.865C69.9479 149.419 72.8809 149.861 75.8691 150.193C78.8574 150.525 81.901 150.691 85 150.691C96.7318 150.691 107.744 148.699 118.037 144.715C128.441 140.73 137.461 135.363 145.098 128.611C152.845 121.86 158.932 113.947 163.359 104.871C167.786 95.6849 170 85.89 170 75.4863C170 65.1934 167.786 55.5091 163.359 46.4336C158.932 37.2474 152.845 29.2786 145.098 22.5273C137.461 15.6654 128.441 10.2975 118.037 6.42383C107.744 2.43945 96.7318 0.447266 85 0.447266ZM79.0234 78.6406C79.0234 88.8229 76.7546 96.7917 72.2168 102.547C67.7897 108.191 61.0938 111.567 52.1289 112.674C52.1289 112.674 52.0736 112.674 51.9629 112.674C51.9629 112.674 51.9076 112.674 51.7969 112.674C51.6862 112.674 51.5755 112.618 51.4648 112.508C51.3542 112.397 51.2435 112.286 51.1328 112.176C51.1328 112.065 51.1328 111.954 51.1328 111.844V101.551C51.1328 101.329 51.1882 101.163 51.2988 101.053C51.4095 100.942 51.5202 100.831 51.6309 100.721C55.7259 98.5072 58.7695 95.6849 60.7617 92.2539C62.8646 88.7122 63.9714 84.4512 64.082 79.4707H51.9629C51.7415 79.4707 51.5202 79.4154 51.2988 79.3047C51.1882 79.0833 51.1328 78.862 51.1328 78.6406V52.5762C51.1328 52.3548 51.1882 52.1888 51.2988 52.0781C51.5202 51.8568 51.7415 51.7461 51.9629 51.7461H78.1934C78.4147 51.7461 78.5807 51.8568 78.6914 52.0781C78.9128 52.1888 79.0234 52.3548 79.0234 52.5762V78.6406ZM125.176 78.6406C125.176 88.7122 123.073 96.4596 118.867 101.883C114.661 107.195 107.855 110.792 98.4473 112.674C98.4473 112.674 98.3919 112.674 98.2812 112.674C98.1706 112.674 98.0599 112.674 97.9492 112.674C97.8385 112.674 97.7832 112.618 97.7832 112.508C97.6725 112.397 97.5618 112.286 97.4512 112.176C97.4512 112.065 97.4512 111.954 97.4512 111.844V101.551C97.4512 101.329 97.4512 101.163 97.4512 101.053C97.5618 100.942 97.6725 100.831 97.7832 100.721C101.878 98.5072 104.922 95.6849 106.914 92.2539C109.017 88.7122 110.124 84.4512 110.234 79.4707H98.2812C98.0599 79.4707 97.8385 79.4154 97.6172 79.3047C97.5065 79.0833 97.4512 78.862 97.4512 78.6406V52.5762C97.4512 52.3548 97.5065 52.1888 97.6172 52.0781C97.8385 51.8568 98.0599 51.7461 98.2812 51.7461H124.346C124.567 51.7461 124.733 51.8568 124.844 52.0781C125.065 52.1888 125.176 52.3548 125.176 52.5762V78.6406Z" fill="#F7F5F9"/></svg>'),
        array('icon-recording','<svg class="icon icon-recording" width="39" height="59" viewBox="0 0 39 59" xmlns="http://www.w3.org/2000/svg"><path d="M37.3639 19.6764C36.5991 19.6764 35.9787 20.2965 35.9787 21.0615V29.716C35.9787 38.8716 28.5301 46.3201 19.3744 46.3201C10.2187 46.3201 2.77023 38.8714 2.77023 29.7159V21.0614C2.77023 20.2963 2.14992 19.6763 1.38511 19.6763C0.620075 19.6763 0 20.2963 0 21.0614V29.7159C0 39.9333 7.95035 48.3276 17.9893 49.0402V56.2303H10.8247C10.0599 56.2303 9.43963 56.8504 9.43963 57.6154C9.43963 58.3804 10.0598 59.0005 10.8247 59.0005H27.9239C28.6887 59.0005 29.309 58.3804 29.309 57.6154C29.309 56.8504 28.6888 56.2303 27.9239 56.2303H20.7594V49.0402C30.7985 48.3276 38.7487 39.9332 38.7487 29.7159V21.0614C38.749 20.2965 38.1287 19.6764 37.3639 19.6764Z" /><path d="M20.2977 0.000488281H18.4517C12.1197 0.000488281 6.96826 5.15192 6.96826 11.4839V30.6389C6.96826 36.9709 12.1197 42.1224 18.4517 42.1224H20.2977C26.6297 42.1224 31.7812 36.9709 31.7812 30.6389V11.4839C31.7812 5.15192 26.6297 0.000488281 20.2977 0.000488281ZM29.0111 15.0792H23.9901C23.225 15.0792 22.605 15.6993 22.605 16.4643C22.605 17.2294 23.225 17.8495 23.9901 17.8495H29.0111V21.705H23.9901C23.225 21.705 22.605 22.325 22.605 23.0901C22.605 23.8551 23.225 24.4752 23.9901 24.4752H29.0111V28.3309H23.9901C23.225 28.3309 22.605 28.951 22.605 29.716C22.605 30.4811 23.225 31.1011 23.9901 31.1011H28.9986C28.7577 35.6916 24.9473 39.3523 20.2979 39.3523H18.4518C13.8023 39.3523 9.99201 35.6916 9.75105 31.1011H14.7596C15.5246 31.1011 16.1447 30.4811 16.1447 29.716C16.1447 28.951 15.5246 28.3309 14.7596 28.3309H9.73861V24.4752H14.7596C15.5246 24.4752 16.1447 23.8551 16.1447 23.0901C16.1447 22.325 15.5246 21.705 14.7596 21.705H9.73861V17.8495H14.7596C15.5246 17.8495 16.1447 17.2294 16.1447 16.4643C16.1447 15.6993 15.5246 15.0792 14.7596 15.0792H9.73861V11.4839C9.73861 8.03104 11.7575 5.04071 14.6768 3.63152V7.54752C14.6768 8.31256 15.297 8.93263 16.062 8.93263C16.8269 8.93263 17.4471 8.31256 17.4471 7.54752V2.83041C17.777 2.79227 20.9727 2.79227 21.3026 2.83041V7.54752C21.3026 8.31256 21.9227 8.93263 22.6877 8.93263C23.4525 8.93263 24.0728 8.31256 24.0728 7.54752V3.63152C26.9922 5.04071 29.0111 8.03081 29.0111 11.4838V15.0792Z" /></svg>'),
        array('icon-recording-grad','<svg class="icon icon-recording-grad" width="39" height="59" viewBox="0 0 39 59" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M37.3639 19.6764C36.5991 19.6764 35.9787 20.2965 35.9787 21.0615V29.716C35.9787 38.8716 28.5301 46.3201 19.3744 46.3201C10.2187 46.3201 2.77023 38.8714 2.77023 29.7159V21.0614C2.77023 20.2963 2.14992 19.6763 1.38511 19.6763C0.620075 19.6763 0 20.2963 0 21.0614V29.7159C0 39.9333 7.95035 48.3276 17.9893 49.0402V56.2303H10.8247C10.0599 56.2303 9.43963 56.8504 9.43963 57.6154C9.43963 58.3804 10.0598 59.0005 10.8247 59.0005H27.9239C28.6887 59.0005 29.309 58.3804 29.309 57.6154C29.309 56.8504 28.6888 56.2303 27.9239 56.2303H20.7594V49.0402C30.7985 48.3276 38.7487 39.9332 38.7487 29.7159V21.0614C38.749 20.2965 38.1287 19.6764 37.3639 19.6764Z" fill="url(#paint0_linear)"/><path d="M20.2977 0.000488281H18.4517C12.1197 0.000488281 6.96826 5.15192 6.96826 11.4839V30.6389C6.96826 36.9709 12.1197 42.1224 18.4517 42.1224H20.2977C26.6297 42.1224 31.7812 36.9709 31.7812 30.6389V11.4839C31.7812 5.15192 26.6297 0.000488281 20.2977 0.000488281ZM29.0111 15.0792H23.9901C23.225 15.0792 22.605 15.6993 22.605 16.4643C22.605 17.2294 23.225 17.8495 23.9901 17.8495H29.0111V21.705H23.9901C23.225 21.705 22.605 22.325 22.605 23.0901C22.605 23.8551 23.225 24.4752 23.9901 24.4752H29.0111V28.3309H23.9901C23.225 28.3309 22.605 28.951 22.605 29.716C22.605 30.4811 23.225 31.1011 23.9901 31.1011H28.9986C28.7577 35.6916 24.9473 39.3523 20.2979 39.3523H18.4518C13.8023 39.3523 9.99201 35.6916 9.75105 31.1011H14.7596C15.5246 31.1011 16.1447 30.4811 16.1447 29.716C16.1447 28.951 15.5246 28.3309 14.7596 28.3309H9.73861V24.4752H14.7596C15.5246 24.4752 16.1447 23.8551 16.1447 23.0901C16.1447 22.325 15.5246 21.705 14.7596 21.705H9.73861V17.8495H14.7596C15.5246 17.8495 16.1447 17.2294 16.1447 16.4643C16.1447 15.6993 15.5246 15.0792 14.7596 15.0792H9.73861V11.4839C9.73861 8.03104 11.7575 5.04071 14.6768 3.63152V7.54752C14.6768 8.31256 15.297 8.93263 16.062 8.93263C16.8269 8.93263 17.4471 8.31256 17.4471 7.54752V2.83041C17.777 2.79227 20.9727 2.79227 21.3026 2.83041V7.54752C21.3026 8.31256 21.9227 8.93263 22.6877 8.93263C23.4525 8.93263 24.0728 8.31256 24.0728 7.54752V3.63152C26.9922 5.04071 29.0111 8.03081 29.0111 11.4838V15.0792Z" fill="url(#paint0_linear)"/><defs><linearGradient id="paint0_linear" x1="31.8376" y1="22.4667" x2="6.96708" y2="22.4667" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint0_linear" x1="31.8376" y1="22.4667" x2="6.96708" y2="22.4667" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient></defs></svg>'),
        array('icon-recording-rates','<svg class="icon icon-recording-rates" width="21" height="37" viewBox="0 0 21 37" xmlns="http://www.w3.org/2000/svg"><path d="M15.0703 29.8867H11.4141V27.0742C12.6328 26.9805 13.7812 26.6641 14.8594 26.125C15.9375 25.5625 16.8633 24.8477 17.6367 23.9805C18.4336 23.1133 19.0547 22.1289 19.5 21.0273C19.9688 19.9023 20.2031 18.707 20.2031 17.4414V12.5547C20.2031 12.2969 20.1094 12.0859 19.9219 11.9219C19.7578 11.7344 19.5469 11.6406 19.2891 11.6406H18.3398C18.1055 11.6406 17.8945 11.7344 17.707 11.9219C17.5195 12.0859 17.4258 12.2969 17.4258 12.5547C17.4258 12.8125 17.5195 13.0352 17.707 13.2227C17.8945 13.3867 18.1055 13.4688 18.3398 13.4688L18.375 17.4414C18.375 18.5195 18.1641 19.5391 17.7422 20.5C17.3438 21.4609 16.7812 22.3047 16.0547 23.0312C15.3516 23.7344 14.5195 24.2969 13.5586 24.7188C12.5977 25.1172 11.5781 25.3164 10.5 25.3164C9.42188 25.3164 8.40234 25.1172 7.44141 24.7188C6.48047 24.2969 5.63672 23.7344 4.91016 23.0312C4.20703 22.3047 3.64453 21.4609 3.22266 20.5C2.82422 19.5391 2.625 18.5195 2.625 17.4414V13.4688H2.66016C2.89453 13.4688 3.10547 13.3867 3.29297 13.2227C3.48047 13.0352 3.57422 12.8125 3.57422 12.5547C3.57422 12.2969 3.48047 12.0859 3.29297 11.9219C3.10547 11.7344 2.89453 11.6406 2.66016 11.6406H1.71094C1.45312 11.6406 1.23047 11.7344 1.04297 11.9219C0.878906 12.0859 0.796875 12.2969 0.796875 12.5547V17.4414C0.796875 18.707 1.01953 19.9023 1.46484 21.0273C1.93359 22.1289 2.55469 23.1133 3.32812 23.9805C4.125 24.8477 5.0625 25.5625 6.14062 26.125C7.21875 26.6641 8.36719 26.9805 9.58594 27.0742V29.8867H5.92969C4.42969 29.8867 3.14062 30.4258 2.0625 31.5039C1.00781 32.5586 0.480469 33.8359 0.480469 35.3359C0.480469 35.5938 0.5625 35.8047 0.726562 35.9688C0.914062 36.1562 1.13672 36.25 1.39453 36.25H19.6055C19.8633 36.25 20.0742 36.1562 20.2383 35.9688C20.4258 35.8047 20.5195 35.5938 20.5195 35.3359C20.5195 33.8359 19.9805 32.5586 18.9023 31.5039C17.8477 30.4258 16.5703 29.8867 15.0703 29.8867ZM2.41406 34.4219C2.625 33.6484 3.04688 33.0039 3.67969 32.4883C4.33594 31.9492 5.08594 31.6797 5.92969 31.6797H15.0703C15.9141 31.6797 16.6523 31.9492 17.2852 32.4883C17.9414 33.0039 18.375 33.6484 18.5859 34.4219H2.41406ZM10.5 22.5742C12 22.5742 13.2891 22.0469 14.3672 20.9922C15.4453 19.9141 15.9844 18.625 15.9844 17.125V5.73438C15.9844 4.21094 15.4453 2.92188 14.3672 1.86719C13.2891 0.789063 12 0.25 10.5 0.25C9 0.25 7.71094 0.789063 6.63281 1.86719C5.55469 2.92188 5.01562 4.21094 5.01562 5.73438V17.125C5.01562 18.625 5.55469 19.9141 6.63281 20.9922C7.71094 22.0469 9 22.5742 10.5 22.5742ZM6.84375 5.73438C6.84375 4.72656 7.19531 3.87109 7.89844 3.16797C8.625 2.44141 9.49219 2.07812 10.5 2.07812C11.5078 2.07812 12.3633 2.44141 13.0664 3.16797C13.793 3.87109 14.1562 4.72656 14.1562 5.73438V17.125C14.1562 18.1094 13.793 18.9648 13.0664 19.6914C12.3633 20.3945 11.5078 20.7461 10.5 20.7461C9.49219 20.7461 8.625 20.3945 7.89844 19.6914C7.19531 18.9648 6.84375 18.1094 6.84375 17.125V5.73438ZM9.19922 8.44141C9.45703 8.44141 9.66797 8.35937 9.83203 8.19531C9.99609 8.00781 10.0781 7.78516 10.0781 7.52734C10.0781 7.26953 9.99609 7.05859 9.83203 6.89453C9.66797 6.70703 9.45703 6.61328 9.19922 6.61328C8.96484 6.61328 8.76562 6.70703 8.60156 6.89453C8.4375 7.05859 8.35547 7.26953 8.35547 7.52734C8.35547 7.78516 8.4375 8.00781 8.60156 8.19531C8.76562 8.35937 8.96484 8.44141 9.19922 8.44141ZM11.2031 7.52734C11.2031 7.78516 11.2852 8.00781 11.4492 8.19531C11.6133 8.35937 11.8125 8.44141 12.0469 8.44141C12.2812 8.44141 12.4805 8.35937 12.6445 8.19531C12.8086 8.00781 12.8906 7.78516 12.8906 7.52734C12.8906 7.26953 12.8086 7.05859 12.6445 6.89453C12.4805 6.70703 12.2812 6.61328 12.0469 6.61328C11.8125 6.61328 11.6133 6.70703 11.4492 6.89453C11.2852 7.05859 11.2031 7.26953 11.2031 7.52734ZM10.6406 5.59375C10.875 5.59375 11.0742 5.51172 11.2383 5.34766C11.4023 5.16016 11.4844 4.94922 11.4844 4.71484C11.4844 4.45703 11.4023 4.24609 11.2383 4.08203C11.0742 3.89453 10.875 3.80078 10.6406 3.80078C10.4062 3.80078 10.1953 3.89453 10.0078 4.08203C9.84375 4.24609 9.76172 4.45703 9.76172 4.71484C9.76172 4.94922 9.84375 5.16016 10.0078 5.34766C10.1953 5.51172 10.4062 5.59375 10.6406 5.59375Z"/></svg>'),
        array('icon-reference','<svg class="icon icon-reference" width="54" height="60" viewBox="0 0 54 60" xmlns="http://www.w3.org/2000/svg"><path d="M37.5 0C36.8529 0 36.3281 0.524766 36.3281 1.17188V6.5625C36.3281 7.20961 36.8529 7.73438 37.5 7.73438C38.1471 7.73438 38.6719 7.20961 38.6719 6.5625V1.17188C38.6719 0.524766 38.1471 0 37.5 0Z" /><path d="M10.5469 36.5625C9.9 36.5625 9.375 37.0875 9.375 37.7344C9.375 38.3813 9.9 38.9062 10.5469 38.9062C11.1938 38.9062 11.7188 38.3813 11.7188 37.7344C11.7188 37.0875 11.1938 36.5625 10.5469 36.5625Z" /><path d="M53.9062 34.2188C53.9062 31.6341 51.8034 29.5312 49.2188 29.5312H40.4705C41.8248 26.0621 42.373 21.9789 42.2673 18.3441C42.2471 17.6504 42.2205 17.2493 42.1846 16.9968C42.124 14.4647 40.0448 12.4219 37.5 12.4219C34.9153 12.4219 32.8125 14.5247 32.8125 17.1094V18.2812C32.8125 25.6929 23.2952 29.8571 16.1128 31.6429C15.5698 30.4014 14.3302 29.5312 12.8906 29.5312H1.17188C0.524766 29.5312 0 30.056 0 30.7031V58.8281C0 59.4752 0.524766 60 1.17188 60H12.8906C14.3205 60 15.553 59.1414 16.1017 57.913C16.6964 58.0656 17.2485 58.2097 17.7581 58.3429C21.8497 59.4115 24.1036 60 29.5852 60H42.1875C44.7722 60 46.875 57.8972 46.875 55.3125C46.875 54.3487 46.5824 53.4523 46.0816 52.7065C47.892 52.0733 49.2188 50.3436 49.2188 48.2812C49.2188 47.321 48.9333 46.4216 48.4341 45.6724C50.2364 45.0382 51.5625 43.3125 51.5625 41.25C51.5625 40.2862 51.2699 39.3898 50.7691 38.644C52.5795 38.0108 53.9062 36.2811 53.9062 34.2188ZM14.0625 56.4844C14.0625 57.1305 13.5368 57.6562 12.8906 57.6562H2.34375V31.875H12.8906C13.5368 31.875 14.0625 32.4007 14.0625 33.0469V56.4844ZM49.2188 36.5625C46.7052 36.5625 46.106 36.5625 43.3594 36.5625C42.7123 36.5625 42.1875 37.0873 42.1875 37.7344C42.1875 38.3815 42.7123 38.9062 43.3594 38.9062H46.875C48.1673 38.9062 49.2188 39.9577 49.2188 41.25C49.2188 42.5445 48.1695 43.5938 46.875 43.5938H41.0156C40.3685 43.5938 39.8438 44.1185 39.8438 44.7656C39.8438 45.4127 40.3685 45.9375 41.0156 45.9375H44.5312C45.8082 45.9375 46.875 46.9576 46.875 48.2812C46.875 49.5757 45.8257 50.625 44.5312 50.625C42.0177 50.625 41.4185 50.625 38.6719 50.625C38.0248 50.625 37.5 51.1498 37.5 51.7969C37.5 52.444 38.0248 52.9688 38.6719 52.9688H42.1875C43.4798 52.9688 44.5312 54.0202 44.5312 55.3125C44.5312 56.6048 43.4798 57.6562 42.1875 57.6562H29.5852C24.4046 57.6562 22.3813 57.1279 18.3504 56.0752C17.7599 55.9209 17.1122 55.7518 16.4062 55.5718V33.9873C24.8869 31.9672 35.1562 27.0364 35.1562 18.2812V17.1094C35.1562 15.817 36.2077 14.7656 37.5 14.7656C38.79 14.7656 39.8413 15.8154 39.8438 17.1057V17.1094C39.8438 17.6187 40.4794 23.8691 37.9305 29.5312H33.9844C33.3373 29.5312 32.8125 30.056 32.8125 30.7031C32.8125 31.3502 33.3373 31.875 33.9844 31.875C34.8027 31.875 47.883 31.875 49.2188 31.875C50.5111 31.875 51.5625 32.9264 51.5625 34.2188C51.5625 35.5132 50.5132 36.5625 49.2188 36.5625Z" /><path d="M10.5469 41.25C9.89977 41.25 9.375 41.7748 9.375 42.4219V51.7969C9.375 52.444 9.89977 52.9688 10.5469 52.9688C11.194 52.9688 11.7188 52.444 11.7188 51.7969V42.4219C11.7188 41.7748 11.194 41.25 10.5469 41.25Z" /><path d="M28.125 14.7656H23.4375C22.7904 14.7656 22.2656 15.2904 22.2656 15.9375C22.2656 16.5846 22.7904 17.1094 23.4375 17.1094H28.125C28.7721 17.1094 29.2969 16.5846 29.2969 15.9375C29.2969 15.2904 28.7721 14.7656 28.125 14.7656Z" /><path d="M51.5625 14.7656H46.875C46.2279 14.7656 45.7031 15.2904 45.7031 15.9375C45.7031 16.5846 46.2279 17.1094 46.875 17.1094H51.5625C52.2096 17.1094 52.7344 16.5846 52.7344 15.9375C52.7344 15.2904 52.2096 14.7656 51.5625 14.7656Z" /><path d="M48.2718 5.16551C47.814 4.70801 47.0722 4.70801 46.6144 5.16551L43.3004 8.47945C42.8428 8.93706 42.8428 9.67909 43.3004 10.1368C43.7583 10.5944 44.4999 10.5943 44.9578 10.1368L48.2718 6.82289C48.7294 6.36527 48.7294 5.62324 48.2718 5.16551Z" /><path d="M31.6992 8.47945L28.3852 5.16551C27.9275 4.70801 27.1857 4.70801 26.7278 5.16551C26.2702 5.62312 26.2702 6.36515 26.7278 6.82289L30.0418 10.1368C30.4998 10.5944 31.2414 10.5943 31.6992 10.1368C32.1568 9.67921 32.1568 8.93718 31.6992 8.47945Z" /></svg>'),
        array('icon-reference-grad','<svg class="icon icon-reference-grad" width="54" height="60" viewBox="0 0 54 60" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M37.5 0C36.8529 0 36.3281 0.524766 36.3281 1.17188V6.5625C36.3281 7.20961 36.8529 7.73438 37.5 7.73438C38.1471 7.73438 38.6719 7.20961 38.6719 6.5625V1.17188C38.6719 0.524766 38.1471 0 37.5 0Z" fill="url(#paint0_linear)"/><path d="M10.5469 36.5625C9.9 36.5625 9.375 37.0875 9.375 37.7344C9.375 38.3812 9.9 38.9062 10.5469 38.9062C11.1938 38.9062 11.7188 38.3812 11.7188 37.7344C11.7188 37.0875 11.1938 36.5625 10.5469 36.5625Z" fill="url(#paint1_linear)"/><path d="M53.9062 34.2188C53.9062 31.6341 51.8034 29.5312 49.2188 29.5312H40.4705C41.8248 26.0621 42.373 21.9789 42.2673 18.3441C42.2471 17.6504 42.2205 17.2493 42.1846 16.9968C42.124 14.4647 40.0448 12.4219 37.5 12.4219C34.9153 12.4219 32.8125 14.5247 32.8125 17.1094V18.2812C32.8125 25.6929 23.2952 29.8571 16.1128 31.6429C15.5698 30.4014 14.3302 29.5312 12.8906 29.5312H1.17188C0.524766 29.5312 0 30.056 0 30.7031V58.8281C0 59.4752 0.524766 60 1.17188 60H12.8906C14.3205 60 15.553 59.1414 16.1017 57.913C16.6964 58.0656 17.2485 58.2097 17.7581 58.3429C21.8497 59.4115 24.1036 60 29.5852 60H42.1875C44.7722 60 46.875 57.8972 46.875 55.3125C46.875 54.3488 46.5824 53.4523 46.0816 52.7065C47.892 52.0733 49.2188 50.3436 49.2188 48.2812C49.2188 47.321 48.9333 46.4216 48.4341 45.6724C50.2364 45.0382 51.5625 43.3125 51.5625 41.25C51.5625 40.2863 51.2699 39.3898 50.7691 38.644C52.5795 38.0108 53.9062 36.2811 53.9062 34.2188ZM14.0625 56.4844C14.0625 57.1305 13.5368 57.6562 12.8906 57.6562H2.34375V31.875H12.8906C13.5368 31.875 14.0625 32.4007 14.0625 33.0469V56.4844ZM49.2188 36.5625C46.7052 36.5625 46.106 36.5625 43.3594 36.5625C42.7123 36.5625 42.1875 37.0873 42.1875 37.7344C42.1875 38.3815 42.7123 38.9062 43.3594 38.9062H46.875C48.1673 38.9062 49.2188 39.9577 49.2188 41.25C49.2188 42.5445 48.1695 43.5938 46.875 43.5938H41.0156C40.3685 43.5938 39.8438 44.1185 39.8438 44.7656C39.8438 45.4127 40.3685 45.9375 41.0156 45.9375H44.5312C45.8082 45.9375 46.875 46.9576 46.875 48.2812C46.875 49.5757 45.8257 50.625 44.5312 50.625C42.0177 50.625 41.4185 50.625 38.6719 50.625C38.0248 50.625 37.5 51.1498 37.5 51.7969C37.5 52.444 38.0248 52.9688 38.6719 52.9688H42.1875C43.4798 52.9688 44.5312 54.0202 44.5312 55.3125C44.5312 56.6048 43.4798 57.6562 42.1875 57.6562H29.5852C24.4046 57.6562 22.3813 57.1279 18.3504 56.0752C17.7599 55.9209 17.1122 55.7518 16.4062 55.5718V33.9873C24.8869 31.9672 35.1562 27.0364 35.1562 18.2812V17.1094C35.1562 15.817 36.2077 14.7656 37.5 14.7656C38.79 14.7656 39.8413 15.8154 39.8438 17.1057V17.1094C39.8438 17.6187 40.4794 23.8691 37.9305 29.5312H33.9844C33.3373 29.5312 32.8125 30.056 32.8125 30.7031C32.8125 31.3502 33.3373 31.875 33.9844 31.875C34.8027 31.875 47.883 31.875 49.2188 31.875C50.5111 31.875 51.5625 32.9264 51.5625 34.2188C51.5625 35.5132 50.5132 36.5625 49.2188 36.5625Z" fill="url(#paint2_linear)"/><path d="M10.5469 41.25C9.89977 41.25 9.375 41.7748 9.375 42.4219V51.7969C9.375 52.444 9.89977 52.9688 10.5469 52.9688C11.194 52.9688 11.7188 52.444 11.7188 51.7969V42.4219C11.7188 41.7748 11.194 41.25 10.5469 41.25Z" fill="url(#paint3_linear)"/><path d="M28.125 14.7656H23.4375C22.7904 14.7656 22.2656 15.2904 22.2656 15.9375C22.2656 16.5846 22.7904 17.1094 23.4375 17.1094H28.125C28.7721 17.1094 29.2969 16.5846 29.2969 15.9375C29.2969 15.2904 28.7721 14.7656 28.125 14.7656Z" fill="url(#paint4_linear)"/><path d="M51.5625 14.7656H46.875C46.2279 14.7656 45.7031 15.2904 45.7031 15.9375C45.7031 16.5846 46.2279 17.1094 46.875 17.1094H51.5625C52.2096 17.1094 52.7344 16.5846 52.7344 15.9375C52.7344 15.2904 52.2096 14.7656 51.5625 14.7656Z" fill="url(#paint5_linear)"/><path d="M48.2718 5.16551C47.814 4.70801 47.0722 4.70801 46.6144 5.16551L43.3004 8.47945C42.8428 8.93706 42.8428 9.67909 43.3004 10.1368C43.7583 10.5944 44.4999 10.5943 44.9578 10.1368L48.2718 6.82289C48.7294 6.36527 48.7294 5.62324 48.2718 5.16551Z" fill="url(#paint6_linear)"/><path d="M31.6992 8.47945L28.3852 5.16551C27.9275 4.70801 27.1857 4.70801 26.7278 5.16551C26.2702 5.62312 26.2702 6.36515 26.7278 6.82289L30.0418 10.1368C30.4998 10.5944 31.2414 10.5943 31.6992 10.1368C32.1568 9.67921 32.1568 8.93718 31.6992 8.47945Z" fill="url(#paint7_linear)"/><defs><linearGradient id="paint0_linear" x1="54.0288" y1="32.0017" x2="-0.00256353" y2="32.0017" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint1_linear" x1="54.0288" y1="32.0017" x2="-0.00256353" y2="32.0017" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint2_linear" x1="54.0288" y1="32.0017" x2="-0.00256353" y2="32.0017" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint3_linear" x1="54.0288" y1="32.0017" x2="-0.00256353" y2="32.0017" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint4_linear" x1="54.0288" y1="32.0017" x2="-0.00256353" y2="32.0017" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint5_linear" x1="54.0288" y1="32.0017" x2="-0.00256353" y2="32.0017" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint6_linear" x1="54.0288" y1="32.0017" x2="-0.00256353" y2="32.0017" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint7_linear" x1="54.0288" y1="32.0017" x2="-0.00256353" y2="32.0017" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient></defs></svg>'),
        array('icon-sign','<svg class="icon icon-sign" width="158" height="48" viewBox="0 0 158 48" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><rect x="0.000244141" y="0.000915527" width="158" height="48" fill="url(#pattern0)"/><defs><pattern id="pattern0" patternContentUnits="objectBoundingBox" width="1" height="1"><use xlink:href="#image0" transform="translate(0 -0.00301227) scale(0.000865801 0.00284993)"/></pattern><image id="image0" width="1155" height="353" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABIMAAAFhCAYAAADjv2rZAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQ1IDc5LjE2MzQ5OSwgMjAxOC8wOC8xMy0xNjo0MDoyMiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTkgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6OTEwM0RCMzcxQzBEMTFFOTlCNTZGNDVFN0IxMURCMEYiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6OTEwM0RCMzgxQzBEMTFFOTlCNTZGNDVFN0IxMURCMEYiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo5MTAzREIzNTFDMEQxMUU5OUI1NkY0NUU3QjExREIwRiIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo5MTAzREIzNjFDMEQxMUU5OUI1NkY0NUU3QjExREIwRiIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PhLcPJoAAEQ0SURBVHja7N3NlePItSDgqHOeAxwT+Eyg1rOiTEiZkDIhZQLbhOz1rLJNYG1mzzYhywTWatZvCmpAhWbnD+MPCADfdw5PtVpSZRUIIG7cuHHjSwAAAGBqux+fff/r8Ln1ffT51v8KkO2LSwAAAFBFl+A5jD778DMBlKpLCv3ef772vwJEkQyC8gP+Pvx1pee9QX/4d99Hv34f/edv4ecqkNUgAOAjxx+fpz7uCH2i4Lf+V6b7DrrPkPzZTfAzu/hwnBj6XcwIfEYyCOLcru58luypMdgPCaLfDfgAQO/5x+fxnf/u1x+ff7pEVXTx4HH0acXX/nv/zVcEAHG6BM/Dj8/px+f843P98fmfRj+vPz4vfRC499UBwKY83hErPLtMxRz769lybDiOER99ZQDwtn0/UHYDe+uJn3sH/u7v0iWzdr5eAFh1DHNvfGDBKN2SEkAfJYXEhQAY1MMfVT+XsOzEzz2frmrowVcOAKvzEhEPiAXidFvAlpwAeuvT/V26vlKSQgBsxq4Pgl5WNqjHBgDPfXADACzbMTIOsF3ovnixu05rXyy8hrZ6HAFAUV3S4ylso/on9tNdEyuEALBcsfGNyf/HMePaqoDu+Tz56gFY02B+Ctut/rGHHADW756m0beVIPxVtzC29UXDF3EgAEu1lZLe2uXCyscBYBlxT+yilwqQP+tinlfx358WB7URgA354hKwcId+MHdqVjnffnz+9ePzm0sBAE16DnELON3Y/t8u238WD7vP3Cerdd/J99Gv3/t///3mf7fv/9y7/p9r/7n/+ePzq1sFgFYH8m51a0mrOd2f9dJ/XvvPNbS9le0crBABQGsOCWP61nsFdbHjXC0EupjvpY9du+9hX+geeOx/3xrx8MljBuunMoglOYafVUCt+BbeXtm5/Xf3BirjX/f9YD/+dY7qp1/CH5VCAMD8LiFusebrj8/fN3qthkqgKY9S/9Zf8+HzfYKfeejj45I9IFUIATC7VvZ0367szJGY2YefSbGuRLyr3rkG+8gBYAseEsbw/Uav1eNEMdK1jw8fG7nWD318WOLv5vQ5AGYbxOdKArWQ+LnXrh/4pzgO9RT0ZgKAucb72Lhoi9t9poofX0Jb1eq3uvg192CVLq7ce/QAmCrQmaMf0LVPpqyhEfWx/7vUuoavAgMAmNwpIbbZ0gJOieTHPf0UHxd2XXMrpF6DhUAAKhqSQFM29rv0gdWatz8d+r9j6cTQNSgdBoCp7BPG6scNXZtS26LeS4ZM2XOoVpydc43OHkEAagxOUyaBhhWdLVa2dFVPpVfMntzCAFBd7ET+spEYMrZaKjZmfFjZNcu5Xi8eQwBKDuBTJIGGPd1KXP9QOin04toCQNVxO3ZsXvuhD7WaQw9tA9Z8/Y4Z1+7R4whAiwP42kp6pwguSyWFLq41AFQRu9X7ecXX4hDq9AXq4tItHZJxSIzFt9aHCoDGB/DbKhW9bOKUSgpJCAFAWU8m6//W/Z2eQ50k0FYXD1MTQiePJQBzD+CqgMoqUbElIQQAZewTxuU19vJ7COUryrecBBpL3TLmVFkAJkkwbHVP9xy665l78piEEADki11Ie13Z379LOLwESaDaUnpSOV0MgA+TCvZ0L1OJSi4JIQBId0wYe9e0Tb7GYqL48X2njd9vADSSSJAEakNuWbYjSAEgTeyC2loqNWosJnbxiG1N5e+5V5cMgEGNVRxJoHntM4MyTQYBID6e2mIPl6dQNobsEmTaCcTFfHpUARA9eJyDJNCa5VR7Pbp8AHCXXcKEfOkLL7kLT29VrDy4lZLEJiIdNQ+wYaVPeNDYbz0Bgn3lABAntnfL0ifjpavKLSTmi03MWfQD2JjSvYEkgZYhtYT71XcLAB86hO1U35auKj8HfYHmug8vLhnAtgaJ3OPHNfZbrlPQUBoASotNjix1El6yGqiLR1Ufl/cSttezCoA7BvCSe7oN4MuUWhVmDz8A/NVDwpi6tObIu4Qkg0Mq5rH3XQAwHsBLlvM6fWD5UgK6a7B6BAC3MVZsxfXSqm2PoVxVeVcR5ZSwtuK8q8sFsE7HUK6c157udTkn3gMAwB9i+/EtrWl06vZyi4nziu0dpPobYGVKDeCO+VynLhhNOQ7W9kAA+GOBLHbB7WlBf7dSVeUWE+dxDhb7ADY5yS81gDvmc/33Smzp96vLBgDRW66XMn52C4Alqsq738PR5fN+jxpJA2zIPpTZ1939HvZ0CxaUegPAXx3DOg9iSD1k4q3eQJIL84uZE4jtABasS96UWMnpAgHVQNsSu7p5dY8AsGGx26xb34azD2lbxyUV2hbTMuLicgEsU0p1x1sTfL2Btiml78GzywaTP6eHYLUd5vaYEGO1/NyW2hamqrw9sY2kLfQBLEzsSRbKeSl1HwkaoJ5dP+k8vzNR6/69hu4w/XMZmzg5Nfz3KXXYyMmt0ayYrWLGFIAFKbG32wDO4OLegdl1K7kxWzdV6UG7cVer26pLHTbyKoHQvJiEn7gOYAFKDOIGcN6ahOodBPPoqjNj+3dJCEG7Y2T3afE0rWMosy3sRQywuvvWEfMAC5gw5J4YZgDnPbEl4xpFQp5dKLNVQ883qCt2Ea7FhrwlWgu0muTiffcm/64uFUC7SqzmmLzz2cQ0Jtn46pJB1js9N7k/fhYl+aGOlIM6Wmqm3L0bXoIm0Vt1Xuh9C8Bo0pCTCHJaGPeKPSnFfQXxE7MSPd+s1sM0z2ts0valoT9/iYpyVeXLFlMRZtEYoDHHkH9svEw/MYFvTOLRHnOIm5jFNmtf4gQU1iJ2G+c1tHNCa4mK8u7/L9G8bPoGASxUSmmyY+PJFVu14B6DaSZmtm3CdPZhudvxS/QHugSLiWuhbxDAwuQmgrrsvpJeUsSemqKsGOpPzO75eOdDObF9dl4X+ue2LWz99A0CWJDcRJCjhskVs5VFRQK8L7c/UMyzKIiHMlK26M/dQ6/UNlTbwtYnZrvj0eUCmE9sA19VGrRwH5qEwp91q+qxx1G/9T6PeRZt2YQyYpsuz91r5RDyG0VfJQJWK2aRWTIQYAEvayc7UXsiG9Pf5OSSwX+UWKF/ThgXgHwp2zrnTMTmxo5aC6xfzPZ/8RzADHJODXNiGDXEbG+5uFzwbyWOch5v9b23vF/jT8gXuxAy9+T5FPITQSb/2+BkSoBGHUL6KTMSQdS8LzWvhWne5e9NzO7daiYhC/lie3xdZxr7diG/UXT3Z1dRvh33VqsaSwAWMnnoVp/1iKCmmJ4ngkq8y8v3fFtKzxJYwzO8hGbLu5C/DfU1WEjcmnuTh6pMASayDxJBtC2md4JT7NiqY8hLBL23Qh/TC8ThAZAnNsEyRwVFiUbR+gNtU8yWQvcHQGW7jAFdIogpA09HzMP7chNBH63Qx2wDscoP6VKaMB8W9q6xaLNtTqYEaEROie8lyNgzrZjgUwDBluROzi4fPDO7IBELU8Vksc/x1E12H0N+o2hHhhuv7r1Xji4XQD2pTf9eg0QQ09M3CP4qt0fQZ5NJWzRhGrEncnXP/b7hP99bf16Te2IqvSUOARob1G0NYy4mpfDXoDonEXRPf5+YbcSSsJBmX+n5LaHEiWFiR8b3U+qplgAUkLInfY5VKLid+NquAj+fh5xE0D0rrrFjhYpRSHMO8cmVqSbuuSeGaRTNrXvHLgt7ADNOqG8TQRqDspQAQt8g1iznBMiY0vuYSeCLrwWSpCzQPUz0nsk9MUxlB2+5974yrgAUlNKcUCKIlsSsntprzhrlTtDunUTGLhzoBQJ1J8bjSpvW3zPGYErc82eXCmCeibQgnxbF9A2yIsna7MI0iaBOTI+Qi68Gqo9pU1W95m5B1Siaz9xbdSoZBDBjwGFlh9bEVCsoL2ZNcnt3HCs9Z8YJSJOy3bP2Iscx5CWCXoNKcj537+K0hQaAQoN7yqCucRstUq2A4LnuKv058vfXHBbiPSc8yzWftdxEUDfm6tVHyTHGYSAAmVK3FSjNpFX33s9Xl4qVyDnWOTYRFLt4YDsmxEtZpKtZgfcQnBhGe2OaZBBAppTV5ItBnZXc0+5jlu4UpukRNIjdiqYSAOo/ZzUrXR9DXiJIFTmx7k0GWdQDmHiAvwruaVxMab3eBWztHZ5TRRD78/Tlgmme61pj2VPISwQ9+TqpHMcBkCClMWHqSjJM6eR+ZgNytm2kTNB2CWOGZCvUf85qJV1zqg6Nr+SQDAKoLGV7mFJfliBmVdWqJUuUc7Rzag+f2ImhqiCo/5zVqtZ+Do6OZxnPge3+ABUny05eYmliGm9KcLI0qVWdOfd7ys+0nRjiHEIb27ByGtJfg4pA8kkGATQ0kdAniKXd407FY426oDe2sWyJSp3YKgFJVogXW7H9WuH9cg7piaBXsSKFxCSDAKgYbNQ+rhRqmCuYhtbe37lJz9gjrq/BSi3ESukBVrInj0QQLdEzCKCClO1hKidYopjqN1iC1Gaul5CenNn1kzynB0E9Kc/ZufDPT604zH3HwFskgwAqBBu2h7EVMYGtIJbWpR4h/5p5fz+HebetwBakHN9eKjbbh/hE1G1SyhhKaff2rbq6VAB1gnrbw9hCICEZROtit2mVauSa8nOdIARxUvo4ngr+7JxEkBMDmTuGkwwCuEPKCRW2h7FkMclP1W+saaJYIjGTsm3FxBDqTXpL9+Q6ZLxbNImnledCMgjgDrF7wW0PY+kkg1i6nD4ejxM+P54jSHMM81Rs5yaC9AWjtnubmUsGAXwi5YQKAz1LJxnE0sVWDJRasU+ZoBozIF5ssvdS4GfmJoK0D2AK9yaD9KkD+ERsqb8XK2sQc/LSweWiMSkNZUts703ZHnbxdUG0lKbwuT25chNBD742JnJvotScBaDwhEIDUNZAMoilSm0YXeJ455TtYZ4fiJNyumtuT66c/mNXsSETuzcZZDECoKFgA1oRkwwS5NKK1AlbiT5vKUmok68Moj1P/HznJoIkfJnavRWqDrsBKDAZ1juFLd//kkG0IGWLVqnqnJTJovJ8iJdyuutT5rOd+l6RCGIuFrEBMicVsYG9FV7WJCYZpA8CLUhtGF3i/k05tcwkEeKdw3RJV4kgljqHMXcByBDbK+ga8ntNwFKfAckglvbOLhkIPwfbw2AKKae7po5PEkEs1T44yRIgS2xVkJcpW55cSwYxp9SG0SV6JaRMTjXshHgp20BTn3GJILYyJj66XAB/Fntcqaog1kgyiCVIbez6WuC9nfKzSzSqhi2aqo9jTu8xzzctiFmkEL8B3Ijt/aDcnzWSDGKN7+tS/Xp2iT/bKizE2yc8a88TPtdDglkiiKXFb6rYAEZiT6lQFYRgwmlizCOlV0+phEzKz3ZqC6SJbQ6fEptJBLEWMVV07luAxBdo6soTrO1ZsLLE1FJ69ZR6Zz+GebalwRal9ASLTfhKBLEmMYsVxiWAkdh94ibBCCYEwkwrtU9QicbNh8SfrXoOponLYp9ziSDW5hxxDwPQi119enXJEExYWWJSqc1dSzR2TT1hyGmTkOYp1E28SgSxRpdgHgNQPegQ4COYsLLEtFL7BM3VMFqfIEh/5q4Vn7fu9z8HiSDW597n5uxSAfwUGxQIBFizeysgri4VE0np1VOqYfRL0CcIphSb+I2t/pMIYo12Qd9TgCQxK1BKK/E8eBaYTmqvnhLB7imkbUvTUw7Sn/ea2zElglirmJYXjy4XQFrgofSfNYtZWbq4XExwP6b06rmE/MqcOauRYKtit2TGLEq8hPREkEo/WhczZjnYACAx4Bfos2b7iGfBnnNqS5m8lWgYnXKktdJ7yPOQ8Mw93Pl7p/YcUxHEUsRUsrqnARJeno6UZ+1iKuVUyVFTamXOQ+bPTT2+XnIU0qU0jb73mXtKfJeUSCzDVBwrD5AgduVZqTBrFlMRoQqCWubqE5S6Lc02EsiT0p/rnsW51KSy3l8szb1jl36PACMxmXSnJ7F2MWX6J5eLClKPci/RJyiluazqAcizD3USv6nbPSWCWCJVrAAJYlaBNcxl7WLK6fXPooaU3h4lEjKpzWU14oQ854Tn/bPEb2p1oWeaJYrZ4q+qG2AkJljQI4W1iynVFzBTWkoD2RJ9glKbyz75ymDyZ/6zhYjUvl8l3iXQ+nNkIQ9gRDIIfoqpjrA1hpJSJ3C5q5wpvUqsrkIZsT26PqvQTu37ZZLMksVUdVvIAxiRDIL4wFz/LEpL7RM0VQCt5wLMN4G9ZyKb2m9MIoili1nIc9gBwEhMMshKMGunfxZzSKnOye0TlJoIKtGoGrYupRLwswW5c7Ddk21ykhhAIskg+ENMA0JVcpSSeuJPTm+P1OOmHSEPZcQ2bP8s+Zva98upmCzdTuwGkC5mb7mXKGvmWHnmCGKn7hOU2qTaEfJQRkoC+KPqHX2/8DypggNIErO/XJ8I1syx8kwt5Tj3nC2KqYkgTTdhnrjrs60tqVV+FvfYYuxmHAO4EbPHXJ8UTMz/+BxcLjKlTOJyqnNSt6M5bhrmfe4fCj/TFvbYauxmmzNAxktU4zXWLGa1VkBBjtRj5FMr0o6JP08VHJSTsi30vcTNIfGZPhu/WBnNowEyxDYdhLWKqc6AHCnHP6du60idNOqvAGWl9PZ5qwo1NZmsATxro3k0wMTBiUCCNdoH2yVpd0KYOonLqQjSJB3KOYQyDZ53Ie7gDw3gWTMHfwBkit2/Lphg6wGF1SVSpfb4OFa+p50yBHWdQ3zy5jYB3P3nlKrC7vfS5441illc0fsOoMCEQUDBGsWcRmHrDClSj5FPWc1MPWFIshPmj7Pe69V1DhrAQ+ozYTEb4A2xpcuaibJGMY3UBdbUvsdytiQ+hfREkFOGoKyUbV1vPffPQd8vuHXvAovm0QAfBCq2D7B1MaX3VpeINdUx8in9iJwyBPWkJGePBX4P8RprF9PrUcUrwAditi5YOWZtYhKiVpdICVinOEY+tXLAex3aefZvJ62pfcZMflm7mEUWuxoAPhCz59ax2qxNTLAtwCbWFMfIp2xBc09DXbHP5W01YGoiuXvnqPLD86WiG+AusSvKXqqsiebRtHBvpRwj3/3vUpvKSgRBPSkVPU83z/al8vsDlky/IIBCYvtZaKDLmsRMpp2mx71im/PH3mOpk0X9RKC+2GfzNomTUu3nCHmMrxY9AKpPWrxYWZOYMny4R8oJQjGVZ/vE318iCOpLaRg/XmRLbRh9dOnZiJhnRL8ggMIT4v8JypBZh5hE6MXl4k4pzZzvbeL8ENL6iEgEQX27hOfzfPN8pzzXJrxsSUxFt9YWAHeILUkWeLAGMatLJtHcI6VXyL3HyKdWDAyfk68HqkpJBA9bu1IbRnuu2Rr9ggAKiy1rdhQxaxCTBNUri8+kbg97vOP3zTkxzIQR6kvpE/ac+e6wbZ+tcQIsQKVJTGwQovSSpbu63ykoJWHzWbDa3Xc5jaKdggfTiD3Z7xp+brlPORXQ1mW26BTsYgBoYiJjpZkl20cG7fCRlF4f48ngWw4hrz+QRBC0+/w/JkxuHSHP1sUsjljEA4gQ2+vis4kMtCxma6RSYz6S0jT2s9N/Uk4ksioK8zz/sVu8hqqe1IbRjpBnq89aTMIUgEixAY2muixVTKNP1RV8JGWLx0fvzpRKAT2uYB4pz2uXCE6t/JPkZatikqfmJwAJUk6rUYbJEsUkPo8uF+9IqeB5b4tH9+9SEku3v7eqAZjGPqT1CUttGG2Cy5bFLOKJ2wASpGx3EJywxPs85h63HZL3JoIpK/tvJWsOiZPD260nkvMwndhei9f+GU1J+jrFla27Bn0eAapTHcTaxZQaC8B5T8qE7lTonauvFczrGNIauj8HDaOh5vNmPATIkFId5MXLkugXRK6UBM7ljXdt7rYw9yjMI7aSr/vfp2wr7eIxWz/ZOkfKAzQ+0bE/lzUG8YJwbpXYHnYM+cfGX713YTExUmpjeM3gIS5uU0UHMPGL1zGOLMXBPU2mS8ir3ilxWlh3b9qeC9NLqZ5+DWnJ35PLDVFx28XlAigjdT88tCxmRVdzdHLun9u+U/uQlkh66/ez8gnzSOn5cw0aRsMU4655CEBBsf0shpMyoFUxk3Hl+YylHCM9vBMfQv62MAlKmNehwDOsYTTUi9ts7QeYefJjNYu13M+CcVID0nEjy5RKAk0xYR3vAA2jYZq4zdZ+gApStkWYtNCimJNcJDXJfQ++hvjeaxpFw/LHj5yPilRIe+5UzgJUEjuhsV2MFr0E+86JN9XWkPeaYXqXwrxSmkanfDSMhj+LaVdh0QSgkpRm0ioraE1MMK9Mn8EUW0NMDKFdpwmedzET/NkuxC1CA1BRSt8L1RW0Iiahad85g5TtYSWax1rhhDbsg4bRMAdbxAAasgtp/S9MamhBTDJTUEFnju1hzyaF1cavbmLRbRXtqjz0ZeFe5wmee5WokPfsmWsATOAhpB+tDHOKSWSaKNKZcnvY1X1Xzf6d579LDEm8UTrmUUENZd7bqrlho/7LJWjWb/0nZtKy64Puv//4fHcJmcEhxCUkv24k0Lr9DBPj8XPa/fPvPz7f+l+38gw/helW67v77Z/9Nab8s38Obyd9Hvr//m/GJt5Ru29XF0/94jLDm+/nmOcIcd3c13x3c83DzTX/3l9z153FS90u9uLSMePEfutNPLsBatgmk3MqTvf/XftWpqm2h13774R69/w1aNxL/XFDnyAoK6Yyd6vbLMV10zj248Fzf60voczpkq/972mLI4t9MJRDs8agYk33aBconEJa8vae4GH8ufSD2mFj94sj49sUu2jhu+D23Vn7KHl9guD9588WMXHdXA79XOA8wTgwjgklhVic1KNW3exMPSmMuT/XMCnsnrGXMM9x6ENwdlrotZzi9DBHxtd/5mMTeiq0GKv9/nS/QZn5xVbGU3FdPaUqrPSQY5NSVtA1lKbVyf1l4X/Xx1BntSjns6SmyLWPkO6+G9UAbU7kHwrcOw/9+2YoIz/3//wcfp5gpgx/GZOumu8BW+bhY6o6xXW1Hfqx+drYtbVgyOKkllJfBMVMJCZhudTV2ocw7clXa10Fr3kN7cefxnOYZsvOuIw89medg6TgVt8D+gTBx2KSsZcVXwdxXXm7/s/d8nV1qjGrf3FbHWNKsZUeuwb//I/9oHB84893SJyMbn1g2/fXbjwhr7U97DXYGlvCkHx5+uBeSt26fO9YdAxlVxK3Wg4+vNceG3w2HkPdhvGqouFjMQn9lt+hu/DzdKkh3jj2n4dRbLcX11WL68bfxSm0WQW01V5Yu/CzmvrUPw/Gx4VLDaDsjaSmmMlhKycKHcP7zQGv/TOzC9P0tin5mfP6DoPOexP5Gvvwr95vxcaWt56FS6Fk3mcT9Nql5FsqBz++M8m5hDYqpXaVJwtWeuFzMc/gPvN5HydrbhM1j6OJ6qkfB4bTpM7959J/XsPPpsupzYMP4rricd0Sk0BrPmRgHz6vqH72Cly21PJ8ARK1xOyznqvkdRjQWmhcV/szZdZ/CKzmKAd+CVY4aiWB3tpy85DxXR3feSafwnR9GtZeOXa84zlsoWrmFOpuEwU+FvMuf30ncfNe0iY3YeOzvLhu6d/1GmKDjxa4W1+cJ1FqQ2n9E6gxaLS6RWzYJrGUUuAlnJLQQlLNlrD87/Ap8vv7v6FcpcZQBbSl1dXaE7vLQq7DoeL3e/Fow5vv+3FVzsMGYyJxXftx3VYSbaXnN7nf2cN/eUcu1t/7wGcf+bB3A8Dffny+uYQUElPp8/XH5/sEk42h989Wk5+7lV7T7t75pf+Qdl8MK7ux98j/TvyZ//zx+W2UtHia8R4a+oF9X8n3mXo957wOp4rvhn94xFnxuzv1g7hOrPy+3xc0J67xnUkGLdgQ+JwjXxDd/7bLIv59RQEx809I7vVrxUneQ3Ck9Pj9kDvgjPf2t3BNf+sTCzl/t91oED3cXKvfRkmLNQaRqUmgHL/013T42S2svh1X8D1377lT5vXs7v+vM/y5a1X0/TNY5GI59uGvSZu3/t0u2ArNeuO6FrS8uLgbzW9qfWc7yaBl67KZQ0Io9oUwJIQgd2J178vpe8HJx270clz7oPZ9NMk5RPx/YgOE8ae199w/+19T79HhXtl/MlH91gcGv67k3hmfJjX1MzIkXFo74nupE6vxiSD7Qu+Vqf/8taqCfg3rTeSynOfzNqHz3j+bhLP1uK4VrY0du/DnhJ3vjbulnjCm0SK5Yk6Hesn8Wfd0x5/7eMoSf7Zrf61uq5xirvXDB4PMY//sX0Lbe7ivIb3Z+EcnX2zh3bgP8/Tk2XrfhVrB4VMo38dh6glprdN79Ami5rO3Dz8XFMaNk8fNkr1X1/sR163389LIe+Yw89zGabwrkhr4P7p0ZARKMROUlNPsDn3w1fIANz7aPOfP+VagML4OsQ17jwsOEJ4TJqv7UPZo05cFPpOHyOByi5/HBb1fax3VO/W9va/093AoBiWTPMOpWK/BSVhb/4jrJIJqjoclGj+XSnayMqlZRafykCLmaNJrxO977Ae6Jay4jZMW+8Tf4/zJhGYXtrP6eEmY3NU8GeVxQc/iVk6HOfcTt4dRUBXz/289eVC7qmuOo+VfNv58Mm2i5zCaNI8reSR5fMR1PlNXfo+TPy1951fz//UOgq+JN4Q9zNRMPr58ct8u7UjLt16iKUcmn/tB4qH//+9Hn2Gf91YqPWJ6ywxbZ14n+J53Db/vHzcQUF76Cd1bvcFiqxOvDb9PjxM86+cZ7udjWN/KLvO98/YSPT7iukVd05ZizIcJ3lND8qfVRe1r/+4071+x1HLss0tHZFCWU322G2XKl5i02GdOeqwIpVUo1tw6897n1OCzN/U1mCMBdE+j5NMKEggPoX65/znMtwJ4CfMmjllWXHFb1fPS30MSPRI11/7Zv/Sfc/956T/PQVzXWgXOkAQ7z3zv1DxJdej50/KC9utoUe0vvhh7VumYmNzpTuz51eXjDkPW+x7dCQj/K/x5j/5SSxO7E63+Ht4+1SH1uVubrwnfb3eawz8+mSQ8hXlOxeq+6/8O05++9F7A8bDS++Zbfx/8Fu47OW6XkBT4R2jj5JAhGf4Y6m7Z6p7Ff4X0k/imHCdi/D2UO5mSae/7/ejX248E3zJ9H/36/ZN/l/Lfx9xfKYlicV35OPkf4edpaYOHPiEx1Tblr6H8aWHjhPWh8bnM1/7z2xvfBRuarNsuRi0xq72voa1Gd0PVQektFoewzdWf137CNzRJfEl47+w/GHhbqIKZ87SFKSpH/t+M1/acmOB6TrhP57af6H5+CfP3RtpV+nueDL/NJ3wO4Wdj5vE2LtUSy2muOyy+PISfC3jDFqchcdfafEFcVz6uq9GPp9aW6OHEtpKLhks7gXcci0NSsCzQ4t4JzdLKi28HiNjA9HLny3ULpzuMr+f+jUG+RBPY1rZCXWd4xqb4+3fPwf+ZMWhJXSHcFbrPpjJFP6BWkkA58Ydj5JeV8LGVq61xeVh4G7ZOPY8ScjG/136h96W4rmxcFxvrnxLeI0O1UOo1/nD7U+I7bUkntQ09FZ2qSfGX2N5l4wOnsJxVjeM7mf5ap+88hnUGCpc7B9yUYKzlJNDtsa61TXUq2Gt/rx4mvtal9u6fEv6+c0yYp2rw3VISKOUd2+opaFt3W+Ej4TNd/HKb1DmFn9uEhyqde7fWxSSizwu+V8V1ZeO6h8gxqIT96L3zOPoM933svf/e2HwMP/v8LKlq8aPFWPjwwYodvFUHUXLCP/X2r88mRbGlxLErDks/JeI1/CwTP0YMuCkl2oebgKv2ROM6Cq5jky61guRj/+eZYpI1biS8D9NN7Eo2cEzZfjRlVdBhwu8zp7qqphoJTcfI14sRxw2bbemqn9wZEju3J07tKn2/W3jOxHXl47qYZNAwxrcyHr23XXWJyex7F2Ph08mG3kGU8BDaekkOR3jGDEAx1XKpzU+fw7oTP7kB57gPz7Hy5OP8QZASG+CVqL4YSqOnShi8VTmym2jC9xrKn+LxFNqrChqqgKYoLW/9WNiHSvcvZZI+qnzKPYdDgmeo3BlXMLTSEPs5bCP2F9e1EdeNF2ZrPgdDE/o19ie77cNZndPEtuM5xGX8nSzGOJk4DnDm1J320HXGH7rkx57wNFQV3Puzck6RegxtrZR0pwn8fvMpdULWS4jbRvVr/6m12vEt/DxF4qNTFA4hrg9J93v9LeG6DadOHMN0qzvfR9f5280zcA51txV1P/uX/meXPoXtEvln/1f/Z6nhMJoA7ib4Pmtd05IB+qXwOy/1mdty0meYJI1/tcB33zP2vb/nxr++9e+WIPZ0rV/72H9pxHV14rrQJydKPVvfbp6jmKTPbvTZr/C983X0cfIX1QeFte8bpowpt65M1SBu+HvVXj16K3h4DctcGbp3QpyyVav2Nqh7nROu7Wc/Y99/7y8zPENDP6D3vvPa5e7PFe+3lF40pQPHff9cvTbyfbakRj85pfHvx3TD9i6VPvGVPMM2raEHyRqTZU8zvyunjFfFdXWcvTuqvIuGivUmev39l/F0M7rM4z8jkjw6k28zATQcIzp3YNStbnQZ8t/6fy4ZQMc8M6V+3rdKgdaw0vL7zT9PuXL5nHBNSjdj7u6TXxLvlV8jJ5z70Xt0vFK8G/33czw/v/V/l6+fTNYfKv78f4W6q1qPic9Hied4fMTyVO/AX/rrugRDkqykXz65n7diqPC5rfbhz+/hbx/88xbFvC+XXJEgrqunG9Od4lhuTvPVmEYLYvbVCjbWr6UKoGGfcc37LqafxTnz59SowLiGn6dAtWDuHlKlTlFa6h7zoX/MPc/MY8XndqoESez3lPMMD32AzjPc00ushnmpcF9tzVvHG6v2+eO5HzdfHip6bH8r975fcgWeuK6uZ++gpOr3p6CwghUMEJJBEkBTNYDeTfh3j52QfNSgenwSS+3TCi4NPpOvM943h5nei600Tn+oeN/HnB4ylZQtYrHNo4fqlqkTQNfQ7slgc9xfWzhGfpz4WdrxxrWSPcP2rVZ6FC5ZzMLv0hOv4rr67yonDH7e8Nlx7ywqALn3BrfiIgFUK2M+11a0XYE//3WG6/jc4D01RwKlZhVK68HOcDJXbLBxqHC/vszw/Kbeb6dPkj/DyW6vM36nSx9rS1+7tR0j/1bFzxb79bxV2cP8yZHHFTxf4rr613hr763PjnpvoaUGJLtn1dNRrss3lLS2kAB6Du2UIS9pQHsN7ZZvTzl5nmIrUovVQbnPTukVvTnvx+eQn4R+DvVXemtUdrXsKZRPNC7dFhM/Q1PUcXXPWhszryHGT62ebJW4bpqE0NYaSl/Cz6ofhxmwKvtPJghbKNGWAFrOCWBbmPRPfSpTaxPAz05SWmOC67MJcYlVp5IB8tPM99zSg9AhsbemHgK7wmPNdYHJg6G67LSBxM9thY+ET5uJyCW918V1y5xnvIb1JrNb7t8ExQOYl7DM/av82bGRBNBw/yzhJdryQHZewDWc4l47zRA07Wd8jkr3z3pe2TO91In2WraC1bzHhk/r1VLDce5PYd19fl7DX7d0SfgsQ0yD4+vKvldx3fQJuNeFvt/O4WdC25wXSaF+oLd/e3kJoFaaQC8pmB88hDYHqAfX7t/B7H7md+JUiYeXUKeBeqmGvi2tGi8pGbTGKqBbhwrPQovx0dBTam1VP+MqnyeTotXE82vtWSOua/u+m+PghZim9Oa4wGqC71No96jZpe09b6WseDhWdCnOYRtB01OFZ21IEtRuPJj7HZ0bDJyWMBm/hGlPR1zL99FKhcI+rO90ryHpY1K0frGVemu8D8R18xqqJx/7+cpL//65Fryur/3vOSR7NKUHNpEAWkJgusSB7ynYPhI7WVrLlrB7A5unjOdv2If+FKatErmu8Dl+Du0mwU9hWz0GSk+45uotdwg/t3y1usgSm4x8kfTZpNixec2HxIjr2k0UHcLP3Sjjz8Mbn2P/v9+7nsAWB/WcCWipAS0mOF7y3vOp9z2/hOWeSlA6yFpSj7IhMXt+434ZVqtaaUC4xu+ipS0ArZ2QOHVAXzJx8jzxMzxsZ1hy8mdIMo+bOLNtscnytd8z4joAFpkAmnMrxHiFO3aV6bSC76DGtqDxRHsNq0WltohttYR6KpeVPr9zvh+H4+kfNn5vnQqPOTXfiWtI/txu8bJCzlvxY+w9tRXiOgCatesnxHM2XXtvi8NW957vQpmGoZf+uq4teC8RVL0IniYJgO99/pe0mnmYeFL/GrZbAVRi0jn19rBxz5+lJX/GvX0cbUyM2HhtawltcR184ItLALMMSg8zTjC+/fj81n9+fyegjmkG3f0+/1jx93Xofx1/hv/ue389v48+w39eo5ztgN11+Vd/v1Df+ZN3TPc9/HOB9+pwkmKNBHR3Lb7278Wv77wf3VNl/NK/D0qMp+PeEkswjBO/33wgVmy81t1nfxOHi+sAmFYXsHarlUtocmrvOe9JXW1/DlbS5gh4n8M6j7rdhTInK6rEiBvDWtgeduy/+6Uc9X7b30dTZ0pSFQRkURkE9Rz6SUbtY6Tf81kF0HuTrJhA3SrTtsT2TOnuwX8Eq95zJ06GVdBvK/wuhqqQcWXI8P76Pvr1283HPRnnNZRLZPwt4vrvw59PnWk9qdzdW0NVmYofar/brxH/e/EaAFTWBa5zHgWfe8xxbHNQq0zbcgz3r4Y/uVywCiVPEbynWfmwFXDOEzVjq370EWFqqoIAoAFDI+i5ytZzE0Djv8c18udiYng7OTqZFMFq7EO5ZsyXT8bQ1hs/j7cV2u7F3M+lE8QAYEZz9gEqlQC6d5L/1kflx3aNT8K79M/BY5AEgrUpOcYdbiazT6Ht3j9OD2Itz6WqIAAooAtmu5XBOVYvr6HeMcexVUE5p0oB0L57t4Xeu3gwNH9ucfvXsOXrKcx30ifcG4eqCgKAiczZB6gLUGOb9qaIrQo6uS0AVq1k1U5r27+GsfUpOEmOZTkHVUEAUNXcfYDOYdpTyGIDdf0SANbrMSzj6PaUyh/JH5YqtlpPVRAARJizD9A5zNN3JTbof3abAKxW7LbhVj+SP6xN7AKlqiAA+MSwDWyO4PfSB6tzVtrEbn9TFQSwXrFHVrfY8BnW5iGoCgKAIubcBjacBNZCUkVVEACD2Oa0c35e+zFpyi3VMJfYhTtVQQBwo1sx7LaBTV0F1P280kfBzxFcqAoCWK/Y5rS2fkF9sQt3qoIAoLfvg8epTwOreRR8CbEniKkKAliv2G0oqn+gvl1C/GqrJAAC2zDPKufUJ4GlBhdOEAMgdcJZu5ee6h+IX7g7u2QAbFUXPHariFNvAxuC16WsXJ6CqiAA/qgimHN7WDded9u35zhNE1q2T4hnJVEB2JS5mkG32geoRnChKghgXePmHNunb7dR2/4F73sJFu4A4E3HhIGyxOclLHs/duyxwYILgHWYq3p2fJKmfiZwX4wbm2C1cAfAqs21mtmV0K+hhH2f8HcXXAAse9yco3p2nACydQXixD6vJ5cMgLWaowqoC2K7xNOakiFKjgG2YR/mqQKSAII8sUfJd8+47ZYArMocq5mtHwef4xBUBQGs3VyLJxJAUCb2jU3gPrpsAKzFHD0NhuPg1yz2tBhVQQDL0Y1hU28FewkSQFBS7Gmvry4ZAEs3RxXQGreBvecYVAUBrHHsnOtUsIvLD0Wl9HV8cNkAWKo5qoCWfhpYitgkm6oggLYnjXOdCjZ8VARBWbEV3BKyACzOHFVAl7CO08BSaEQIsA5DEuh/Zv5YMICyHoKELAArD2JPYbqVzKEZ9JYHyy6pE7t94MmtCtDc+NlCEmjYYm3BAOaN1V5cNgCWoNuSFVv6mtsMeqtVQLc0IgRYrkOY/mQwPUpgWrGJ3m6xU19HAJo1bAWbqqnltU98GBx/0ogQYJlaTAKpRoA6z3rsc6iCG4BmExBTNrV8kcB4V2w11tklA5h9DG0xCaQaAeqI7Z+pghuA5ky5FWw4Et42sPdpRAiwHC31BHrv8+hrgqKeEp7Do8sGQAum3gp2Ngje/b3EfidOhgGY531d82CFayizUOMIayhrn/Dc26YJQBMD2FSngukFFO8UHCUP0LLunftUcRztFgSGgxQuBX4/laNQVmyS1jZNAGbVVeVM1cugGyT1AoqX0jRaI0KA6XRjW62K2svN2PlY4Pc8+cqg+DtArAZA84atYCVWFu9Z9XgOVj5yxK40aUQIMI1DxbH0rW3Uu5BfeWSMgPJxdexzaZsmAJMPVjVL2G8HuaGcnXQpK02qrwDqj6e1mkN31brvbeE6Ffj99emDsp49hwC0aqqj4YcqIH0Iyk02YrcdWGkCqKvWospn4+e+0M8AyjmGtIQvAFR1CNP0A3IsfB0pK8AScQD1Jn2l+wLFHKhwLvCzjNNQTsqinecQgOoBa4ljZx0LP59DsNIE0MqEr8aWsJh+escCP88WYigr5b2gaTQAVXSBXu2m0BpCT+MSrDQBtDCult4S1i2kxFZxvhb4mUDZd0NKP00AKGZoCl3rSFtbwab3lPD9PLpsAMV0Cx6lt1l3E8GUatqnkL+IYwEHysbeKUliW/kBKDYQnUL9ptDdaqLS8mknIFZ8AebzWHhsfc0YR0scJW9bCpT14jkEYK5kQa3jbGNONaGOlO1hVnwB8nWJl5L99q4FJoC5471tKVCW7WEATK5Gyfp7gautYPNI2QpgpQmgzASvZDXQqcBYeijw57CoA+XYHgbApKY4Hv4SbAWb2z5YaQKYY3JXstr2JZSr1sw9EOLk64WibA8DYBJTJIFegtWKVqQE/b47gLxxttThC93vcyz4Z3ss8OdR5Qvl2B4GwCTBae0kkKPh25KyPcyKL8C0792PxtSSiZcSTaOPvmIoZh9sDwOgom7AKNm48q1+QCV6GFD+e7fiCzCN7t1ZasGldDXQ4BTyk1NAOSnV27aHAXBXMqBmEug1aAq9tgDDii9A2nhbaltYrerMfchf+DHeQzkpyVnbwwD4UDehr50EenSZm5ayTeHFZQOIVuq0sG6SV3PrR25c4DAIKBurO8UPgKIDS80kkJPBliFle5gVX4B4uduuptr2ccz885191VBMau8u28MAeHPyXzMJ5GSwZUnZHibJBxA3mSsx7nbv6ykOXcjZwnYNDoaAks7B9jAAMnXBWc3TwZwMtjwpq9RWfAHutwtpSfe5Tm7MPd1MNQLM+zxKyALwH92A8Bzqngxm0FmeY7A9DKD2+JvbKLp7705VjZl7lLxqBCjnkPgc6tMJwL+DulL9CRwPv74JSkrA7/QwgPsncrmNoqfaFjbIXTiyRRzKxfApiWSHewAYQP6dqClxWokk0Dql7D9/dtkA7nIsMAY/TzzWHgr8eYEyUhKzr+JzgG17CpJAfCylWkyAAXCfhwJj7hzbPHL6GtlCDOU8BpV5AEQOHLl9CSSB1i/1uGABBkC9d+w48T7H+zY3geWESSgjdXupPkEAG/QQJIG4T+r+cyfDAHwud2vYeaYxN3VscMIktPEs6hMEsDHdykGJo2olgbYjpU+QIB/gvjE5JxF0mvHPnnvQhNNEYb44zTZ+gA3pgq6XIAlEnKfEe0KQD/Cx3ETQnNs79pmxw8nXD7PFabbxA2xEzWPiJYHWP1HRAwKgvC6ZkpoI6v5/x5n//DmLSyoSoIzUXmP6BAFswGOoc0LYc1D5sXb2nwO09X6ds1F0iQno8Dm6BSBbakJZnAawcrWaQ78ESaCtSFn1tdoL8LmU/h7d59LIGJwTX5iIQhkp/T/FaQArdsgIMj9rBmxv8XbYfw5Qx3NITwS1MIlLHR+G7W0mojDfe0ScBrBC+4yB4bPgUzn3tjwk3iuOkQf42GNYdiKo+zMsteE1bP094vkDWKGnUL4v0GvQBHiLUvefO0Ye4GOpfXZaSQR1chadjBOQL/VgD6f3AawwsCzdF6j7/awcbFNqQ1P7zwHqvF9bSgSlTkKHj36DkMeCHQD/HgxyjnR9bx//k0n9pqX2mrL/HOBja2jIn9OPUFUC5OneBRpGA2xcjS1hzwaKzTsF+88Bakjpw9aN84eF/x3Gk1EgzznxPaIiD2AFamwJc0IYOUH+s0sH8KHUbR0tHdyQusWtxb8LLNHJswew3UCy9JawVwMEvUPiROXi0gF8KmU1v7WKy9SJqEUDyJd6cpgTXgEWrvSWsGuwrYefUld7lR0DfC6l6rK13jr7zJjDFnRIl3oCoSQswMJf/qW3hJ0EZdxIbQaqqgzgYynJ9hYrLnMqkx/cBpAsdYupym2ABQePpbeEvQRVHPzVc1B2DFBL7NaqFisuU6sSHGUN+fOBlEVhJ4cBLNRDKLsl7BJUcPC2p5CeWATgYylbq1rcwp1yjLWtxJAv9eQwh8IALDBoTN2uoy8QsVIbEVptArhPbIVvi4n21LFCBSlM+/6wLRNgwRPzktVAzybsfCC15N9qE8B9DmH5TZZ3GbGJfiWQLjURJAELsCClq4FsCeOeCUpqcO/eAqgzmWtxEpfaU+5/goUDmPq5O7l0AMtR8rj4a7AawOf2GfecLYcA979rY7fftia2ssmkFMrMDRwhD7BiXYCV2ozxvR4DtoTxmdQTKQT2AHFiV/ZbrLpMrVrWVw7SpPbncmIfwEKkZvzfC7hs2+EeXWCemoB0chhA3Ps2pgKzxYncQ0ZsIi6B6Z65S5B8BWjePpSrBrIljFipK7wagALEiV30aS15klNFavEA4qUmglThASxAyZPCukn93iUlQuqJFIIMgHgxCz8tJtxPIX2hypgBcVJPd301HwBo2y5jIv5WkKWBL1MG9YIMgDixjaMfGvzzO2QAppF6uus1OK0PoGldpj+1zFqDaEo4BT0fAKYUs0WsxRPEUhewNLCFOBJBACbhn77wH1xOJr4H3XMAaWK2iLV2SmPqdpXuo5IU7peaCBKjATSsZJNo1UCkykkEaUwOkB4DxLxvW1vdT41fjBtwvy7paismwMqUahLdlY3L+pMqJxH07PIBZMUBS90iFvNnb32rG7QqJxEk6QrQoF0/iS5RDfQcVAORLicR5DhggDwxsUBLW8R2GRNUvUvgPhJBACtTalvYNWjYSx6JIIB5xRwa0dKYn7qgpZoU7pPTj0siCKDRF3uJbWHdCRyqgcghEQQwr13ku7eVcf8Q0reHiV3gcw8ZMdrJ5QNoT8zRsRrBUVNOIshRwADTT/ha6rNzDk40ghbeCxJBAI3bZQRO40+3tcw+e3LlJoKs6gKUEbNI1Mr2qtSJqopSqPd8SQQBNKhL3sT0A/CCp6acpuVdMlIiCGCed3ILVcG7xJjmavyAT+XsIDBPAGjMQ8jvD6RJNKW8BIkggKW+l1uIBVInq7a3w8dyqrYlggAaU6I/0IsJOAXkblOUCAKoI+Zk0bm3iXcnoaYscOkzBx/LWayTCAJoTM5WHEdCUtIucrLh5BeA6cQkV+Z+F6dOWPe+Zng3RstZrJMIAljRS922MErqAvCcflUSQQB13ZsMus785zwGC1tQOkbLWayTCAJoSG4FxrAdxwoaJRxCXr8qW8MA6ltKMiglvrn4euHdGC1nsU4iCKAhuRUYLR0Zy/IdQ14iyPHxANNYQjLoMXEsOfh6oXiMptoOoCG5FRhO2aCkh5DftByAabSeDNolxjgqF6B8jGa+ANDYSz0nEdRVE1k5o5TcE+wkggCm1XoyKOW4a/3moGyMpp8oQGNys/t6slDSS7BNEWBpYraYTx0zHBLHE5NW+GmXGaNdg4VjgKaknqqhAoMaQUZu43Ll/ADziHl/T33ARMrpqBYW4KfcE8Neg4NlAJqSmwgy8aaU3NMoNCIEmFdMxcCUFTcp1c9dBYOKZ/g5X3CqK8DKXuwm3rQgt1+VRoQA84vpyTPlOztloeHB1wn/ltvD0amuAI3JzfALkmglyHA/ArQh5tj2qbaYp4wxZ18lZPcH0koCoEE5iSAnAFBSbpChESFAW/FFTP+Q2vYJ8c416GsCuf2B9NwCaNAhpCeCHB1PKSUaRWtECNDeuz3mPV5760jKgoMtx2xd7u4BrSQAGrQP6Q16TbxpKciw/xygTTGJ/pqJl5Sj5G0PY+tKbN2XUAVoTE4lhkQQLQUZyo4B2hXTRLpm8iUl5hHrsOV5wjnkb93XSgKgQam9WSSCaCXIUHYM0L7YY9xrVHk+BuML3KtExfbFfAGgTTGrdBJBlHYI6dsTx6tNTgwDaN8ucmJZIwkTO+ZcfG2YI2SdGGbrPkCDYlfonKZBSSW2hWlcDrAsMdXIpU8ViznRbPgYY9iaEqeFqagDaPxFn1L2KRFErl3IPzZe2THAMsUuRJWs/IytdDj5utjg85m7LUx/IIDGpWT8u5e7FTJylNgWpuwYYNliJpslt2nFVKS++prYmOdgoQ5g9VL3AMvyk+Mx5AcZyo4BtjfpLFUdFFOVZPGLreju9RLbwizUASzghZ/ygtegl1TdClGJ08KUHQOsZ1yI7Q9XapJ5T3Wq7WFsRYn+jRbqABZgF9K26HjBk6rE3vPucw5WmwDWJLZ3XKkEzWdNpM++GjagVDWQE10BFiJlL/Czy0aCUk2irdACrHcyGjselOpF0iWEXt+Y1J6ChQfWr1Q10GvQHwhgtUHXRVBEYpBdohrIahPAusVuIb4U/vn7fsw6iHfYyFygRDXQsFjsmQFYiNiXvyPkibULZU6icBoFwHYmp6pFob5S1UAW6gAWJub0jOHz6LIRGdCXODLeaRQA25KyiOAwAbg/PitVDdRV8lmoA1iQlKbRLy4bEffXKZRbbZKEBNjeOBK7tVj1MnyuVHzmMBmAhYotC70GVRnc560GnLaFARDrMWheCy3GZ93vc3BJAZYnZbVNZQb33FelTgrT/wGATmwz6WGiagEL/rAvHJ/Ztg+wYLErbWeXjDvuqRInhQ1BvL4PAAwT2ZTxxcmn8MdOgFLxmSbRACsQWyKqDJSPgvSUVVtHkgJwr5QDLySE2LKSW8Js2wdY0eCgaTQllGxAaLUJgBpjjoQQW1J6S5ht+wArElvFoSqIW6VXmxxJCsA9Uo/C7sYZCSHWruSWsCGRah4AsBK7oFcQ6WqsNmlMDkDMOJS6GCEhxFo9hrKLdFfxGcA6B4uYwUATX0IfPJfcEqYaCIBUqQ2lHYfN2jyEskkgJ4UBrFhMVcfV5SKUPSXMahMAJRwyxibjEEvXLdambpl0kivARsUETs8u1+YD7dKBRpeMVA0EQKlxKmexQpzDEu/5kie4jhtEqwYCWLHYU8SsDmxTjb5ATgoDoIXYxnHZLNGhQmymQTTAhjwFW8R439AXqOSWsGHl1WoTALU8BAsWrFONBTpbJQE26Dk4RYy/6hI1pY8itfccgCnlJoSGrTLQglqVQLbsA2xUTP8XAdE21EgCuX8AmEPsiakWMmjNQyjfr3G8Jcy9DbBRMZN+5dLrD5hLH0XquHgAWhjfSixydOOZXipMYajQrhGXSQIB8O+BRvNoaiWBut9TAhGAFhwKjnX63lFLt3hWo1ej2AyAP4lNBlkNW5daSaAugHlyeQFoMO4pdQS3ZruUVLMfkPsVgDdJBm0vEK5ZdqwBIQCtizlJVT8hasdktfoBjRfoVLIB8Be2iW1D7bLjLpCRLARgKY6Fx8SzOIk7ddu0alYBDUmgLu6TBALgXTEDi/LS5VF2DABv6xZKSldlXIyLvBOPPYd6i3J6WgEQLWa70LPLtRjd6mSpvghWnABYs2fjJBV0ycaaW/Nv77fnYKs+AJUCoKvL1bTa/YCGj+AWgLV5qDh+drGWrdTbicW6yrCaC3K3Pav0BAIgyWPQN2jpuu+k9t7zIZi14gTAmifyp4rjaJcgcKz3+nSJvtqNoN/ajuheAiDLPmHwoY3vbarSYyeEAbC1MbbmIks3dp+CaqEl6xbinieKw25jMvcNAMXEDmQaI85nihMoBBwA8MeEv/Zk/7VPKqi8btuw/auLjaZoAv1W/ykLcwAUF7tV7CpJMHkwOmXwcfb9AsB/PE00Bg9NgCWG5rfrv4cuCTPl9q/bROFj0A8IgMoDXmyQ82pwqmooP55y9UklEAC8HyvVOHXso8RQNy4/iLcmse+vdfcdz5X80VsKgFmkNEx8DUpWS5ojAaT0GADudwjTnRR1myA49bGC5FCZ73HY9vUa5k3+jE8FE48BMLmU6qAhmaCcOf2az7n/3FGkAJCmm7RPvYBzmzx46eMIVb0f665PV2nTJdPOM35n720L9P0BMLuHkHfsuMTCfQFJC/vPAYB8Xewz1eme95z4+tzHc/sNfg/jpE8rFT/vbcu3DQyA2Xx559/nDFDff3z+9ePzq8v7H10wdhx95kqYff3x+aX/FQAor4ufnkI7lR5dXPat/4z/efzvlhZT7frPvv8cRv/csi7++q3/fPeoADCn95JB3QB7yRxUfw9/JIW2mHjogpLj6Nc5q6W+9UHHr/0/AwDTxAJdUmgJ1R/fwttJoiFhMf61dBJjN/p1SPB89OvSfOtjsN/EYQC05MsH/1036F4KDLxrHwSHkuRxAqiFYOXr6LoDAPPo4qnHsL7jwe9JFO0++XWtfg8/q4B+9wgAsERdYqNkg73zwoOhYbtXt9LX4j707s/jVDAAaNMcJ4b6TNMEemjkLQYDYBG+3Bm4nCv87N/Dz5WT7teWqoZu96EPnxaTWN/DzyogvYAAYBm6+Oqh/1UCYXlU/wCwaF/u/N91iZAuIVQzGTIkNX4Pf212WKPJ3v6DzxIql4YGhF+DJoQAsGTDCVhbPAFsKYY4VewFwCp8ifjfdsHJS5jndIwhOfQ9vJ0c+n7zz7tPPkvlFAoAWLchMXQM7ZxItlW/h5/JH9U/AKzKl8j/fZdIeQ7LOBljLSSAAGCbhl6F4y3r1PH7zeebuAuANfuS+P/rApOToKQKZcgAwFvGJ5gOp5juXJZoEj8AbN6XzP9/d2rCSSBSJCj5OvoAANxjfNiFrWVvx1i3HwDYvC8Ffo8uEfTUf7jP9/DnfejfXBIAoJAhOTQcijE+JGONMdW38OeDR4Z/lvgBgHd8Kfh7dQFG10voMTgJ461AZaj6sSoFAMxlfHLqWyeqthY/fZTssZgGAIm+VPp9uzLlx7DdvexdcDIkflT+AABLMSSJhn/ejf75o393+999H/36/Y1/99l/p48PAFT0pfLv3wUED/3nENaZGBrKkMcfwQsAAADQpC8T/7yhueHQ4HBJyaGhLNnpEwAAAMBifZn554+PR21hv/pbe9HtSwcAAABW40ujf67bZoa3+9c/+rVzuxf9rb3pmhACAAAAm/P/BRgAQ6NOCpE4LpkAAAAASUVORK5CYII="/></defs></svg>'),
        array('icon-sound','<svg class="icon icon-sound" width="60" height="53" viewBox="0 0 60 53" xmlns="http://www.w3.org/2000/svg"><path d="M43.3122 1.99531C42.6675 1.73391 41.9301 2.03519 41.6642 2.66812C41.3981 3.30104 41.7048 4.02592 42.3491 4.28711C51.5383 8.01401 57.4759 16.733 57.4759 26.4999C57.4759 39.7449 46.5074 50.5204 33.025 50.5204C32.3279 50.5204 31.763 51.0756 31.763 51.7602C31.763 52.4448 32.3279 53 33.025 53C47.899 53 60 41.1122 60 26.4999C60 15.7255 53.4497 6.10675 43.3122 1.99531Z" /><path d="M33.025 43.7133C42.6867 43.7133 50.547 35.9913 50.547 26.4999C50.547 17.0085 42.6867 9.28648 33.025 9.28648C32.3281 9.28648 31.763 9.84171 31.763 10.5263C31.763 11.2111 32.3281 11.7661 33.025 11.7661C41.2949 11.7661 48.0229 18.3756 48.0229 26.4999C48.0229 34.6242 41.2949 41.2337 33.025 41.2337C32.3281 41.2337 31.763 41.7887 31.763 42.4735C31.763 43.1583 32.3281 43.7133 33.025 43.7133Z" /><path d="M37.1327 30.8345C36.6228 31.3011 36.5944 32.0857 37.0696 32.5866C37.3182 32.8488 37.6552 32.9815 37.9934 32.9815C38.3013 32.9815 38.6101 32.8713 38.8532 32.6488C40.5845 31.0645 41.5775 28.8233 41.5775 26.4999C41.5775 21.8673 37.741 18.0983 33.0252 18.0983C32.3284 18.0983 31.7632 18.6535 31.7632 19.3381C31.7632 20.0227 32.3284 20.5779 33.0252 20.5779C36.3492 20.5779 39.0535 23.2344 39.0535 26.4999C39.0533 28.1617 38.3712 29.7009 37.1327 30.8345Z" /><path d="M27.5101 0.0944587C27.0387 -0.0972999 26.4961 0.00829119 26.1349 0.362259L12.7978 13.4448H1.26203C0.565178 13.4448 0 14.0001 0 14.6846V38.3152C0 38.9998 0.565178 39.555 1.26203 39.555H13.3199C14.0167 39.555 14.5819 38.9998 14.5819 38.3152C14.5819 37.6306 14.0167 37.0754 13.3199 37.0754H2.52406V15.9245H13.3199C13.6543 15.9245 13.9749 15.7941 14.2115 15.562L25.7645 4.22967V48.7704L19.5328 42.6574C19.0394 42.1737 18.2403 42.1741 17.7481 42.6589C17.2557 43.1434 17.2563 43.9284 17.7496 44.4122L26.1351 52.6376C26.3764 52.8744 26.699 53 27.0272 53C27.1898 53 27.354 52.9692 27.5103 52.9054C27.9817 52.7134 28.289 52.2613 28.289 51.7602V1.23964C28.2886 0.738338 27.9813 0.286424 27.5101 0.0944587Z" /></svg>'),
        array('icon-sound-grad','<svg class="icon icon-sound-grad" width="60" height="53" viewBox="0 0 60 53" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M43.3122 1.99531C42.6675 1.73391 41.9301 2.03519 41.6642 2.66812C41.3981 3.30104 41.7048 4.02592 42.3491 4.28711C51.5383 8.01401 57.4759 16.733 57.4759 26.4999C57.4759 39.7449 46.5074 50.5204 33.025 50.5204C32.3279 50.5204 31.763 51.0756 31.763 51.7602C31.763 52.4448 32.3279 53 33.025 53C47.899 53 60 41.1122 60 26.4999C60 15.7255 53.4497 6.10675 43.3122 1.99531Z" fill="url(#paint0_linear)"/><path d="M33.025 43.7133C42.6867 43.7133 50.547 35.9913 50.547 26.4999C50.547 17.0085 42.6867 9.28648 33.025 9.28648C32.3281 9.28648 31.763 9.84171 31.763 10.5263C31.763 11.2111 32.3281 11.7661 33.025 11.7661C41.2949 11.7661 48.0229 18.3756 48.0229 26.4999C48.0229 34.6242 41.2949 41.2337 33.025 41.2337C32.3281 41.2337 31.763 41.7887 31.763 42.4735C31.763 43.1583 32.3281 43.7133 33.025 43.7133Z" fill="url(#paint2_linear)"/><path d="M37.1327 30.8345C36.6228 31.3011 36.5944 32.0857 37.0696 32.5866C37.3182 32.8488 37.6552 32.9815 37.9934 32.9815C38.3013 32.9815 38.6101 32.8713 38.8532 32.6488C40.5845 31.0645 41.5775 28.8233 41.5775 26.4999C41.5775 21.8673 37.741 18.0983 33.0252 18.0983C32.3284 18.0983 31.7632 18.6535 31.7632 19.3381C31.7632 20.0227 32.3284 20.5779 33.0252 20.5779C36.3492 20.5779 39.0535 23.2344 39.0535 26.4999C39.0533 28.1617 38.3712 29.7009 37.1327 30.8345Z" fill="url(#paint2_linear)"/><path d="M27.5101 0.0944587C27.0387 -0.0972999 26.4961 0.00829119 26.1349 0.362259L12.7978 13.4448H1.26203C0.565178 13.4448 0 14.0001 0 14.6846V38.3152C0 38.9998 0.565178 39.555 1.26203 39.555H13.3199C14.0167 39.555 14.5819 38.9998 14.5819 38.3152C14.5819 37.6306 14.0167 37.0754 13.3199 37.0754H2.52406V15.9245H13.3199C13.6543 15.9245 13.9749 15.7941 14.2115 15.562L25.7645 4.22967V48.7704L19.5328 42.6574C19.0394 42.1737 18.2403 42.1741 17.7481 42.6589C17.2557 43.1434 17.2563 43.9284 17.7496 44.4122L26.1351 52.6376C26.3764 52.8744 26.699 53 27.0272 53C27.1898 53 27.354 52.9692 27.5103 52.9054C27.9817 52.7134 28.289 52.2613 28.289 51.7602V1.23964C28.2886 0.738338 27.9813 0.286424 27.5101 0.0944587Z" fill="url(#paint3_linear)"/><defs><linearGradient id="paint0_linear" x1="60.1364" y1="28.2682" x2="-0.00285332" y2="28.2682" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint1_linear" x1="60.1364" y1="28.2682" x2="-0.00285332" y2="28.2682" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint2_linear" x1="60.1364" y1="28.2682" x2="-0.00285332" y2="28.2682" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint3_linear" x1="60.1364" y1="28.2682" x2="-0.00285332" y2="28.2682" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient></defs></svg>'),
        array('icon-sound-design','<svg class="icon icon-sound-design" width="54" height="54" viewBox="0 0 54 54" xmlns="http://www.w3.org/2000/svg"><path d="M47.5094 0.000488281H6.49062C3.35389 0.000488281 0 1.69211 0 6.45505V47.5459C0 52.3449 3.35389 54.0005 6.49062 54.0005H47.5094C50.6461 54.0005 54 52.3089 54 47.5579V6.45505C54 1.69211 50.6461 0.000488281 47.5094 0.000488281ZM13.2225 51.589H6.49062C4.63271 51.589 2.42493 50.8812 2.42493 47.5459V17.3966H9.45845V35.7885C9.45845 36.4511 9.99863 36.9883 10.6649 36.9883H13.2225V51.589ZM11.8713 34.5888V17.3966H16.9987V34.5888H11.8713ZM25.7936 51.589H15.6354V36.9883H18.193C18.8593 36.9883 19.3995 36.4511 19.3995 35.7885V17.3966H22.0174V35.7885C22.0174 36.4511 22.5576 36.9883 23.2239 36.9883H25.7936V51.589ZM24.4424 34.5888V17.3966H29.5697V34.5888H24.4424ZM38.3646 51.589H28.2064V36.9883H30.7761C31.4424 36.9883 31.9826 36.4511 31.9826 35.7885V17.3966H34.6005V35.7885C34.6005 36.4511 35.1407 36.9883 35.807 36.9883H38.3646V51.589ZM37.0013 34.5888V17.3966H42.1287V34.5888H37.0013ZM47.5094 51.601H40.7775V36.9883H43.3351C44.0014 36.9883 44.5416 36.4511 44.5416 35.7885V17.3966H51.5751V47.5459C51.5751 50.8932 49.3552 51.601 47.5094 51.601ZM51.5751 15.0092H2.42493V6.45505C2.42493 3.1078 4.64477 2.41195 6.50268 2.41195H47.5094C49.3673 2.41195 51.5871 3.1198 51.5871 6.46705L51.5751 15.0092Z" /><path d="M8.62607 4.55957C6.40065 4.55957 4.59658 6.35362 4.59658 8.56668C4.59658 10.7797 6.40065 12.5738 8.62607 12.5738C10.8515 12.5738 12.6556 10.7797 12.6556 8.56668C12.6489 6.35632 10.8488 4.56617 8.62607 4.55957ZM8.62607 10.1983V10.1863C7.73316 10.1863 7.00945 9.46663 7.00945 8.57867C7.00945 7.69072 7.73316 6.97103 8.62607 6.97103C9.51883 6.97103 10.2427 7.69072 10.2427 8.57867C10.2427 9.46858 9.52079 10.1917 8.62607 10.1983Z" /><path d="M18.2051 4.55957C15.9797 4.55957 14.1757 6.35362 14.1757 8.56668C14.1757 10.7797 15.9797 12.5738 18.2051 12.5738C20.4306 12.5738 22.2346 10.7797 22.2346 8.56668C22.228 6.35632 20.4279 4.56617 18.2051 4.55957ZM18.2051 10.1983V10.1863C17.3124 10.1863 16.5885 9.46648 16.5885 8.57867C16.5885 7.69072 17.3122 6.97103 18.2051 6.97103C19.0981 6.97103 19.8218 7.69072 19.8218 8.57867C19.8218 9.46858 19.0999 10.1917 18.2051 10.1983Z" /></svg>'),
        array('icon-sound-design-grad','<svg class="icon icon-sound-design-grad" width="54" height="54" viewBox="0 0 54 54" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M47.5094 0.000488281H6.49062C3.35389 0.000488281 0 1.69211 0 6.45505V47.5459C0 52.3449 3.35389 54.0005 6.49062 54.0005H47.5094C50.6461 54.0005 54 52.3089 54 47.5579V6.45505C54 1.69211 50.6461 0.000488281 47.5094 0.000488281ZM13.2225 51.589H6.49062C4.63271 51.589 2.42493 50.8812 2.42493 47.5459V17.3966H9.45845V35.7885C9.45845 36.4511 9.99863 36.9883 10.6649 36.9883H13.2225V51.589ZM11.8713 34.5888V17.3966H16.9987V34.5888H11.8713ZM25.7936 51.589H15.6354V36.9883H18.193C18.8593 36.9883 19.3995 36.4511 19.3995 35.7885V17.3966H22.0174V35.7885C22.0174 36.4511 22.5576 36.9883 23.2239 36.9883H25.7936V51.589ZM24.4424 34.5888V17.3966H29.5697V34.5888H24.4424ZM38.3646 51.589H28.2064V36.9883H30.7761C31.4424 36.9883 31.9826 36.4511 31.9826 35.7885V17.3966H34.6005V35.7885C34.6005 36.4511 35.1407 36.9883 35.807 36.9883H38.3646V51.589ZM37.0013 34.5888V17.3966H42.1287V34.5888H37.0013ZM47.5094 51.601H40.7775V36.9883H43.3351C44.0014 36.9883 44.5416 36.4511 44.5416 35.7885V17.3966H51.5751V47.5459C51.5751 50.8932 49.3552 51.601 47.5094 51.601ZM51.5751 15.0092H2.42493V6.45505C2.42493 3.1078 4.64477 2.41195 6.50268 2.41195H47.5094C49.3673 2.41195 51.5871 3.1198 51.5871 6.46705L51.5751 15.0092Z" fill="url(#paint0_linear)"/><path d="M8.62607 4.55957C6.40065 4.55957 4.59658 6.35362 4.59658 8.56668C4.59658 10.7797 6.40065 12.5738 8.62607 12.5738C10.8515 12.5738 12.6556 10.7797 12.6556 8.56668C12.6489 6.35632 10.8488 4.56617 8.62607 4.55957ZM8.62607 10.1983V10.1863C7.73316 10.1863 7.00945 9.46663 7.00945 8.57867C7.00945 7.69072 7.73316 6.97103 8.62607 6.97103C9.51883 6.97103 10.2427 7.69072 10.2427 8.57867C10.2427 9.46858 9.52079 10.1917 8.62607 10.1983Z" fill="url(#paint0_linear)"/><path d="M18.2051 4.55957C15.9797 4.55957 14.1757 6.35362 14.1757 8.56668C14.1757 10.7797 15.9797 12.5738 18.2051 12.5738C20.4306 12.5738 22.2346 10.7797 22.2346 8.56668C22.228 6.35632 20.4279 4.56617 18.2051 4.55957ZM18.2051 10.1983V10.1863C17.3124 10.1863 16.5885 9.46648 16.5885 8.57867C16.5885 7.69072 17.3122 6.97103 18.2051 6.97103C19.0981 6.97103 19.8218 7.69072 19.8218 8.57867C19.8218 9.46858 19.0999 10.1917 18.2051 10.1983Z" fill="url(#paint2_linear)"/><defs><linearGradient id="paint0_linear" x1="54.1228" y1="28.802" x2="-0.00256799" y2="28.802" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint1_linear" x1="54.1228" y1="28.802" x2="-0.00256799" y2="28.802" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint2_linear" x1="54.1228" y1="28.802" x2="-0.00256799" y2="28.802" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient></defs></svg>'),
        array('icon-spectr','<svg class="icon icon-spectr" width="14" height="13" viewBox="0 0 14 13" xmlns="http://www.w3.org/2000/svg"><path d="M3.315 9.72754H0.572813C0.437396 9.72754 0.318906 9.77832 0.217344 9.87988C0.115781 9.98145 0.0650001 10.1042 0.0650001 10.248V11.6191C0.0650001 11.7546 0.115781 11.873 0.217344 11.9746C0.318906 12.0762 0.437396 12.127 0.572813 12.127H3.315C3.45888 12.127 3.57737 12.0762 3.67047 11.9746C3.77203 11.873 3.82281 11.7546 3.82281 11.6191V10.248C3.82281 10.1042 3.77203 9.98145 3.67047 9.87988C3.57737 9.77832 3.45888 9.72754 3.315 9.72754ZM3.315 6.65527H0.572813C0.437396 6.65527 0.318906 6.70605 0.217344 6.80762C0.115781 6.90918 0.0650001 7.02767 0.0650001 7.16309V8.53418C0.0650001 8.67806 0.115781 8.80078 0.217344 8.90234C0.318906 9.00391 0.437396 9.05469 0.572813 9.05469H3.315C3.45888 9.05469 3.57737 9.00391 3.67047 8.90234C3.77203 8.80078 3.82281 8.67806 3.82281 8.53418V7.16309C3.82281 7.02767 3.77203 6.90918 3.67047 6.80762C3.57737 6.70605 3.45888 6.65527 3.315 6.65527ZM3.315 3.57031H0.572813C0.437396 3.57031 0.318906 3.62109 0.217344 3.72266C0.115781 3.82422 0.0650001 3.94694 0.0650001 4.09082V5.46191C0.0650001 5.59733 0.115781 5.71582 0.217344 5.81738C0.318906 5.91895 0.437396 5.96973 0.572813 5.96973H3.315C3.45888 5.96973 3.57737 5.91895 3.67047 5.81738C3.77203 5.71582 3.82281 5.59733 3.82281 5.46191V4.09082C3.82281 3.94694 3.77203 3.82422 3.67047 3.72266C3.57737 3.62109 3.45888 3.57031 3.315 3.57031ZM7.93609 9.72754H5.19391C5.05003 9.72754 4.9273 9.77832 4.82574 9.87988C4.73264 9.98145 4.68609 10.1042 4.68609 10.248V11.6191C4.68609 11.7546 4.73264 11.873 4.82574 11.9746C4.9273 12.0762 5.05003 12.127 5.19391 12.127H7.93609C8.07151 12.127 8.19 12.0762 8.29156 11.9746C8.39313 11.873 8.44391 11.7546 8.44391 11.6191V10.248C8.44391 10.1042 8.39313 9.98145 8.29156 9.87988C8.19846 9.77832 8.07997 9.72754 7.93609 9.72754ZM7.93609 6.65527H5.19391C5.05003 6.65527 4.9273 6.70605 4.82574 6.80762C4.73264 6.90918 4.68609 7.02767 4.68609 7.16309V8.53418C4.68609 8.67806 4.73264 8.80078 4.82574 8.90234C4.9273 9.00391 5.05003 9.05469 5.19391 9.05469H7.93609C8.07151 9.05469 8.19 9.00391 8.29156 8.90234C8.39313 8.80078 8.44391 8.67806 8.44391 8.53418V7.16309C8.44391 7.02767 8.39313 6.90918 8.29156 6.80762C8.19846 6.70605 8.07997 6.65527 7.93609 6.65527ZM12.5572 9.72754H9.815C9.67112 9.72754 9.5484 9.77832 9.44684 9.87988C9.35374 9.98145 9.30719 10.1042 9.30719 10.248V11.6191C9.30719 11.7546 9.35374 11.873 9.44684 11.9746C9.5484 12.0762 9.67112 12.127 9.815 12.127H12.5572C12.6926 12.127 12.8111 12.0762 12.9127 11.9746C13.0142 11.873 13.065 11.7546 13.065 11.6191V10.248C13.065 10.1042 13.0142 9.98145 12.9127 9.87988C12.8111 9.77832 12.6926 9.72754 12.5572 9.72754ZM12.5572 6.65527H9.815C9.67112 6.65527 9.5484 6.70605 9.44684 6.80762C9.35374 6.90918 9.30719 7.02767 9.30719 7.16309V8.53418C9.30719 8.67806 9.35374 8.80078 9.44684 8.90234C9.5484 9.00391 9.67112 9.05469 9.815 9.05469H12.5572C12.6926 9.05469 12.8111 9.00391 12.9127 8.90234C13.0142 8.80078 13.065 8.67806 13.065 8.53418V7.16309C13.065 7.02767 13.0142 6.90918 12.9127 6.80762C12.8111 6.70605 12.6926 6.65527 12.5572 6.65527ZM12.5572 3.57031H9.815C9.67112 3.57031 9.5484 3.62109 9.44684 3.72266C9.35374 3.82422 9.30719 3.94694 9.30719 4.09082V5.46191C9.30719 5.59733 9.35374 5.71582 9.44684 5.81738C9.5484 5.91895 9.67112 5.96973 9.815 5.96973H12.5572C12.6926 5.96973 12.8111 5.91895 12.9127 5.81738C13.0142 5.71582 13.065 5.59733 13.065 5.46191V4.09082C13.065 3.94694 13.0142 3.82422 12.9127 3.72266C12.8111 3.62109 12.6926 3.57031 12.5572 3.57031ZM12.5572 0.498047H9.815C9.67112 0.498047 9.5484 0.548828 9.44684 0.650391C9.35374 0.751953 9.30719 0.870443 9.30719 1.00586V2.37695C9.30719 2.52083 9.35374 2.64355 9.44684 2.74512C9.5484 2.84668 9.67112 2.89746 9.815 2.89746H12.5572C12.6926 2.89746 12.8111 2.84668 12.9127 2.74512C13.0142 2.64355 13.065 2.52083 13.065 2.37695V1.00586C13.065 0.870443 13.0142 0.751953 12.9127 0.650391C12.8111 0.548828 12.6926 0.498047 12.5572 0.498047Z" /></svg>'),
        array('icon-star','<svg class="icon icon-star" width="86" height="15" viewBox="0 0 86 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.3408 5.16699L11.21 4.78613C11.083 4.7666 10.9658 4.71777 10.8584 4.63965C10.751 4.56152 10.6729 4.46387 10.624 4.34668L9.14453 0.757812C9.02734 0.464844 8.80762 0.318359 8.48535 0.318359C8.16309 0.318359 7.94336 0.464844 7.82617 0.757812L6.36133 4.34668C6.3125 4.46387 6.23438 4.56152 6.12695 4.63965C6.01953 4.71777 5.90234 4.7666 5.77539 4.78613L1.64453 5.16699C1.33203 5.19629 1.12695 5.3623 1.0293 5.66504C0.941406 5.95801 1.00977 6.20703 1.23438 6.41211L4.35449 9.15137C4.45215 9.23926 4.52051 9.34668 4.55957 9.47363C4.59863 9.59082 4.60352 9.71289 4.57422 9.83984L3.63672 13.6777C3.56836 13.9805 3.65625 14.2246 3.90039 14.4102C4.1543 14.6055 4.41797 14.625 4.69141 14.4688L8.13379 12.4326C8.25098 12.374 8.37305 12.3447 8.5 12.3447C8.62695 12.3447 8.74902 12.374 8.86621 12.4326L12.3086 14.4688C12.582 14.625 12.8408 14.6104 13.085 14.4248C13.3389 14.2393 13.4316 13.9902 13.3633 13.6777L12.4404 9.83984C12.4111 9.71289 12.416 9.59082 12.4551 9.47363C12.4941 9.34668 12.5625 9.23926 12.6602 9.15137L15.7803 6.41211C16.0049 6.20703 16.0635 5.95801 15.9561 5.66504C15.8584 5.3623 15.6533 5.19629 15.3408 5.16699ZM32.5908 5.16699L28.46 4.78613C28.333 4.7666 28.2158 4.71777 28.1084 4.63965C28.001 4.56152 27.9229 4.46387 27.874 4.34668L26.3945 0.757812C26.2773 0.464844 26.0576 0.318359 25.7354 0.318359C25.4131 0.318359 25.1934 0.464844 25.0762 0.757812L23.6113 4.34668C23.5625 4.46387 23.4844 4.56152 23.377 4.63965C23.2695 4.71777 23.1523 4.7666 23.0254 4.78613L18.8945 5.16699C18.582 5.19629 18.377 5.3623 18.2793 5.66504C18.1914 5.95801 18.2598 6.20703 18.4844 6.41211L21.6045 9.15137C21.7021 9.23926 21.7705 9.34668 21.8096 9.47363C21.8486 9.59082 21.8535 9.71289 21.8242 9.83984L20.8867 13.6777C20.8184 13.9805 20.9062 14.2246 21.1504 14.4102C21.4043 14.6055 21.668 14.625 21.9414 14.4688L25.3838 12.4326C25.501 12.374 25.623 12.3447 25.75 12.3447C25.877 12.3447 25.999 12.374 26.1162 12.4326L29.5586 14.4688C29.832 14.625 30.0908 14.6104 30.335 14.4248C30.5889 14.2393 30.6816 13.9902 30.6133 13.6777L29.6904 9.83984C29.6611 9.71289 29.666 9.59082 29.7051 9.47363C29.7441 9.34668 29.8125 9.23926 29.9102 9.15137L33.0303 6.41211C33.2549 6.20703 33.3135 5.95801 33.2061 5.66504C33.1084 5.3623 32.9033 5.19629 32.5908 5.16699ZM49.8408 5.16699L45.71 4.78613C45.583 4.7666 45.4658 4.71777 45.3584 4.63965C45.251 4.56152 45.1729 4.46387 45.124 4.34668L43.6445 0.757812C43.5273 0.464844 43.3076 0.318359 42.9854 0.318359C42.6631 0.318359 42.4434 0.464844 42.3262 0.757812L40.8613 4.34668C40.8125 4.46387 40.7344 4.56152 40.627 4.63965C40.5195 4.71777 40.4023 4.7666 40.2754 4.78613L36.1445 5.16699C35.832 5.19629 35.627 5.3623 35.5293 5.66504C35.4414 5.95801 35.5098 6.20703 35.7344 6.41211L38.8545 9.15137C38.9521 9.23926 39.0205 9.34668 39.0596 9.47363C39.0986 9.59082 39.1035 9.71289 39.0742 9.83984L38.1367 13.6777C38.0684 13.9805 38.1562 14.2246 38.4004 14.4102C38.6543 14.6055 38.918 14.625 39.1914 14.4688L42.6338 12.4326C42.751 12.374 42.873 12.3447 43 12.3447C43.127 12.3447 43.249 12.374 43.3662 12.4326L46.8086 14.4688C47.082 14.625 47.3408 14.6104 47.585 14.4248C47.8389 14.2393 47.9316 13.9902 47.8633 13.6777L46.9404 9.83984C46.9111 9.71289 46.916 9.59082 46.9551 9.47363C46.9941 9.34668 47.0625 9.23926 47.1602 9.15137L50.2803 6.41211C50.5049 6.20703 50.5635 5.95801 50.4561 5.66504C50.3584 5.3623 50.1533 5.19629 49.8408 5.16699ZM67.0908 5.16699L62.96 4.78613C62.833 4.7666 62.7158 4.71777 62.6084 4.63965C62.501 4.56152 62.4229 4.46387 62.374 4.34668L60.8945 0.757812C60.7773 0.464844 60.5576 0.318359 60.2354 0.318359C59.9131 0.318359 59.6934 0.464844 59.5762 0.757812L58.1113 4.34668C58.0625 4.46387 57.9844 4.56152 57.877 4.63965C57.7695 4.71777 57.6523 4.7666 57.5254 4.78613L53.3945 5.16699C53.082 5.19629 52.877 5.3623 52.7793 5.66504C52.6914 5.95801 52.7598 6.20703 52.9844 6.41211L56.1045 9.15137C56.2021 9.23926 56.2705 9.34668 56.3096 9.47363C56.3486 9.59082 56.3535 9.71289 56.3242 9.83984L55.3867 13.6777C55.3184 13.9805 55.4062 14.2246 55.6504 14.4102C55.9043 14.6055 56.168 14.625 56.4414 14.4688L59.8838 12.4326C60.001 12.374 60.123 12.3447 60.25 12.3447C60.377 12.3447 60.499 12.374 60.6162 12.4326L64.0586 14.4688C64.332 14.625 64.5908 14.6104 64.835 14.4248C65.0889 14.2393 65.1816 13.9902 65.1133 13.6777L64.1904 9.83984C64.1611 9.71289 64.166 9.59082 64.2051 9.47363C64.2441 9.34668 64.3125 9.23926 64.4102 9.15137L67.5303 6.41211C67.7549 6.20703 67.8135 5.95801 67.7061 5.66504C67.6084 5.3623 67.4033 5.19629 67.0908 5.16699ZM84.3408 5.16699L80.21 4.78613C80.083 4.7666 79.9658 4.71777 79.8584 4.63965C79.751 4.56152 79.6729 4.46387 79.624 4.34668L78.1445 0.757812C78.0273 0.464844 77.8076 0.318359 77.4854 0.318359C77.1631 0.318359 76.9434 0.464844 76.8262 0.757812L75.3613 4.34668C75.3125 4.46387 75.2344 4.56152 75.127 4.63965C75.0195 4.71777 74.9023 4.7666 74.7754 4.78613L70.6445 5.16699C70.332 5.19629 70.127 5.3623 70.0293 5.66504C69.9414 5.95801 70.0098 6.20703 70.2344 6.41211L73.3545 9.15137C73.4521 9.23926 73.5205 9.34668 73.5596 9.47363C73.5986 9.59082 73.6035 9.71289 73.5742 9.83984L72.6367 13.6777C72.5684 13.9805 72.6562 14.2246 72.9004 14.4102C73.1543 14.6055 73.418 14.625 73.6914 14.4688L77.1338 12.4326C77.251 12.374 77.373 12.3447 77.5 12.3447C77.627 12.3447 77.749 12.374 77.8662 12.4326L81.3086 14.4688C81.582 14.625 81.8408 14.6104 82.085 14.4248C82.3389 14.2393 82.4316 13.9902 82.3633 13.6777L81.4404 9.83984C81.4111 9.71289 81.416 9.59082 81.4551 9.47363C81.4941 9.34668 81.5625 9.23926 81.6602 9.15137L84.7803 6.41211C85.0049 6.20703 85.0635 5.95801 84.9561 5.66504C84.8584 5.3623 84.6533 5.19629 84.3408 5.16699Z" fill="url(#paint0_linear)"/><defs><linearGradient id="paint0_linear" x1="88.1978" y1="7.86698" x2="0.995863" y2="7.86698" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient></defs></svg>'),
        array('icon-testimonials','<svg class="icon icon-testimonials" width="14" height="14" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg"><path d="M12.5331 0H1.62687C1.28312 0 0.98625 0.119792 0.73625 0.359375C0.496667 0.598958 0.376875 0.885417 0.376875 1.21875V10.3438C0.376875 10.6875 0.496667 10.9792 0.73625 11.2188C0.98625 11.4479 1.28312 11.5625 1.62687 11.5625H6.17375L7.81437 13.75C7.86646 13.8333 7.93417 13.8958 8.0175 13.9375C8.11125 13.9792 8.205 14 8.29875 14C8.3925 14 8.48104 13.9792 8.56437 13.9375C8.65812 13.8958 8.73104 13.8333 8.78312 13.75L10.4237 11.5625H12.5331C12.8769 11.5625 13.1685 11.4479 13.4081 11.2188C13.6581 10.9792 13.7831 10.6875 13.7831 10.3438V1.21875C13.7831 0.885417 13.6581 0.598958 13.4081 0.359375C13.1685 0.119792 12.8769 0 12.5331 0ZM12.5331 10.3438H10.1269C10.0331 10.3438 9.93937 10.3646 9.84562 10.4062C9.76229 10.4479 9.69458 10.5104 9.6425 10.5938L8.29875 12.375L6.955 10.5938C6.90292 10.5104 6.83 10.4479 6.73625 10.4062C6.65292 10.3646 6.56437 10.3438 6.47062 10.3438H1.59562L1.62687 1.21875H12.5644L12.5331 10.3438ZM11.3456 2.70312H2.81437V3.92188H11.3456V2.70312ZM11.3456 5.14062H2.81437V6.35938H11.3456V5.14062ZM11.3456 7.57812H2.81437V8.78125H11.3456V7.57812Z"/></svg>'),
        array('icon-time','<svg class="icon icon-time" width="20" height="21" viewBox="0 0 20 21" xmlns="http://www.w3.org/2000/svg"><path d="M10 0.25C8.61979 0.25 7.32422 0.516927 6.11328 1.05078C4.90234 1.57161 3.84115 2.28776 2.92969 3.19922C2.03125 4.09766 1.3151 5.15234 0.78125 6.36328C0.260417 7.57422 0 8.86979 0 10.25C0 11.6302 0.260417 12.9258 0.78125 14.1367C1.3151 15.3477 2.03125 16.4089 2.92969 17.3203C3.84115 18.2188 4.90234 18.9284 6.11328 19.4492C7.32422 19.9831 8.61979 20.25 10 20.25C11.3802 20.25 12.6758 19.9831 13.8867 19.4492C15.0977 18.9284 16.1523 18.2188 17.0508 17.3203C17.9622 16.4089 18.6784 15.3477 19.1992 14.1367C19.7331 12.9258 20 11.6302 20 10.25C20 8.86979 19.7331 7.57422 19.1992 6.36328C18.6784 5.15234 17.9622 4.09766 17.0508 3.19922C16.1523 2.28776 15.0977 1.57161 13.8867 1.05078C12.6758 0.516927 11.3802 0.25 10 0.25ZM10 18.2578C8.90625 18.2578 7.87109 18.0495 6.89453 17.6328C5.91797 17.2031 5.0651 16.6302 4.33594 15.9141C3.61979 15.1849 3.04688 14.332 2.61719 13.3555C2.20052 12.3789 1.99219 11.3438 1.99219 10.25C1.99219 9.15625 2.20052 8.12109 2.61719 7.14453C3.04688 6.16797 3.61979 5.32161 4.33594 4.60547C5.0651 3.8763 5.91797 3.30339 6.89453 2.88672C7.87109 2.45703 8.90625 2.24219 10 2.24219C11.0938 2.24219 12.1289 2.45703 13.1055 2.88672C14.082 3.30339 14.9284 3.8763 15.6445 4.60547C16.3737 5.32161 16.9466 6.16797 17.3633 7.14453C17.793 8.12109 18.0078 9.15625 18.0078 10.25C18.0078 11.3438 17.793 12.3789 17.3633 13.3555C16.9466 14.332 16.3737 15.1849 15.6445 15.9141C14.9284 16.6302 14.082 17.2031 13.1055 17.6328C12.1289 18.0495 11.0938 18.2578 10 18.2578ZM10.5078 5.25H9.00391V11.2461L14.1992 14.4492L15 13.1406L10.5078 10.4453V5.25Z"/></svg>'),
        array('icon-twitter','<svg class="icon icon-twitter" width="13" height="18" viewBox="0 0 13 18" xmlns="http://www.w3.org/2000/svg"><path d="M6.51758 13.2734C6.22461 13.2734 5.95508 13.2266 5.70898 13.1328C5.47461 13.0273 5.25781 12.875 5.05859 12.6758C4.85938 12.4766 4.70703 12.2539 4.60156 12.0078C4.50781 11.7617 4.46094 11.498 4.46094 11.2168V9.75781H10.2969C10.5547 9.75781 10.7949 9.71094 11.0176 9.61719C11.252 9.52344 11.4629 9.38281 11.6504 9.19531C11.8379 9.00781 11.9785 8.80273 12.0723 8.58008C12.166 8.3457 12.2129 8.09961 12.2129 7.8418C12.2129 7.57227 12.166 7.32617 12.0723 7.10352C11.9785 6.88086 11.8379 6.66992 11.6504 6.4707C11.4629 6.2832 11.252 6.14258 11.0176 6.04883C10.7949 5.95508 10.5547 5.9082 10.2969 5.9082H4.46094V2.90234C4.46094 2.62109 4.4082 2.35742 4.30273 2.11133C4.20898 1.86523 4.0625 1.64258 3.86328 1.44336C3.65234 1.23242 3.42383 1.08008 3.17773 0.986328C2.94336 0.880859 2.68555 0.828125 2.4043 0.828125C2.11133 0.828125 1.8418 0.880859 1.5957 0.986328C1.34961 1.08008 1.12695 1.22656 0.927734 1.42578C0.728516 1.625 0.576172 1.84766 0.470703 2.09375C0.376953 2.33984 0.330078 2.60938 0.330078 2.90234V11.2168C0.330078 12.0723 0.476562 12.8691 0.769531 13.6074C1.07422 14.334 1.53125 14.9961 2.14062 15.5938C2.73828 16.2031 3.40039 16.6602 4.12695 16.9648C4.86523 17.2695 5.66211 17.4219 6.51758 17.4219H10.6133C10.8945 17.4219 11.1523 17.3691 11.3867 17.2637C11.6328 17.1699 11.8613 17.0176 12.0723 16.8066C12.2715 16.6074 12.418 16.3848 12.5117 16.1387C12.6172 15.8926 12.6699 15.6289 12.6699 15.3477C12.6699 15.0664 12.6172 14.8027 12.5117 14.5566C12.418 14.3105 12.2715 14.0879 12.0723 13.8887C11.8613 13.6777 11.6328 13.5254 11.3867 13.4316C11.1523 13.3262 10.8945 13.2734 10.6133 13.2734H6.51758Z"/></svg>'),
        array('icon-update','<svg class="icon icon-update" width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M1.92175 8.73779C1.89087 8.48047 1.875 8.22485 1.875 8C1.875 4.64368 4.64368 1.875 8 1.875C9.56555 1.875 11.0312 2.50623 12.1094 3.4906L11.5687 4.04065C11.4469 4.16248 11.4 4.34058 11.4469 4.5094C11.5032 4.6687 11.6344 4.79065 11.8031 4.82812C11.8975 4.84705 14.9973 5.84595 14.7999 5.80627C15.051 5.88989 15.4224 5.62207 15.3531 5.25317C15.3341 5.15869 14.6478 1.71521 14.6875 1.91248C14.65 1.74377 14.5281 1.60315 14.3594 1.55627C14.2001 1.5094 14.0219 1.55627 13.9 1.6781L13.4407 2.12805C12.025 0.806274 10.0812 0 8 0C3.60315 0 0 3.60315 0 8V8.01868C0 8.28296 0.012085 8.48718 0.0261231 8.64343C0.0447998 8.85046 0.197388 9.02002 0.401245 9.06091L1.36426 9.25342C1.67773 9.31616 1.95959 9.05334 1.92175 8.73779Z" /><path d="M15.6013 6.93835L14.6355 6.74157C14.3217 6.67761 14.0379 6.94067 14.0764 7.25769C14.1099 7.53125 14.1248 7.79724 14.1248 8C14.1248 11.3562 11.3561 14.125 7.99977 14.125C6.43422 14.125 4.96852 13.4938 3.8904 12.5L4.43105 11.9593C4.55287 11.8375 4.59975 11.6594 4.55287 11.4906C4.4966 11.3312 4.36537 11.2093 4.19667 11.1719C4.10231 11.1528 1.00246 10.154 1.19984 10.1937C1.04042 10.1656 0.880997 10.2125 0.777969 10.3249C0.665421 10.4281 0.618546 10.5968 0.646622 10.7468C0.665665 10.8412 1.35207 14.2534 1.31239 14.0561C1.34975 14.225 1.4717 14.3656 1.6404 14.4123C1.83608 14.4614 1.99941 14.4021 2.09975 14.2905L2.54982 13.8406C3.96535 15.1625 5.9092 16 7.99977 16C12.3966 16 15.9998 12.3968 15.9998 8V7.9718C15.9998 7.76404 15.9922 7.56006 15.9749 7.3573C15.957 7.15014 15.8051 6.97998 15.6013 6.93835Z" /></svg>'),
        array('icon-user','<svg class="icon icon-user" width="17" height="13" viewBox="0 0 17 13" xmlns="http://www.w3.org/2000/svg"><path d="M8.93164 7.84082C9.46289 7.45345 9.87793 6.96094 10.1768 6.36328C10.4756 5.75456 10.625 5.11263 10.625 4.4375C10.625 3.85091 10.5143 3.30306 10.293 2.79395C10.0716 2.27376 9.76725 1.81999 9.37988 1.43262C8.99251 1.04525 8.53874 0.740885 8.01855 0.519531C7.50944 0.298177 6.96159 0.1875 6.375 0.1875C5.78841 0.1875 5.23503 0.298177 4.71484 0.519531C4.20573 0.740885 3.75749 1.04525 3.37012 1.43262C2.98275 1.81999 2.67839 2.27376 2.45703 2.79395C2.23568 3.30306 2.125 3.85091 2.125 4.4375C2.125 5.11263 2.27441 5.75456 2.57324 6.36328C2.87207 6.96094 3.28711 7.45345 3.81836 7.84082C3.30924 8.07324 2.83333 8.361 2.39062 8.7041C1.95898 9.0472 1.57715 9.4401 1.24512 9.88281C0.913086 10.3255 0.636393 10.807 0.415039 11.3271C0.204753 11.8363 0.0664062 12.373 0 12.9375H1.41113C1.49967 12.3398 1.69336 11.7809 1.99219 11.2607C2.29102 10.7406 2.66178 10.2923 3.10449 9.91602C3.5472 9.52865 4.04525 9.22982 4.59863 9.01953C5.16309 8.79818 5.75521 8.6875 6.375 8.6875C6.99479 8.6875 7.58138 8.79818 8.13477 9.01953C8.69922 9.22982 9.2028 9.52865 9.64551 9.91602C10.0882 10.2923 10.459 10.7406 10.7578 11.2607C11.0566 11.7809 11.2503 12.3398 11.3389 12.9375H12.75C12.6836 12.373 12.5397 11.8363 12.3184 11.3271C12.1081 10.807 11.8369 10.3255 11.5049 9.88281C11.1729 9.4401 10.7855 9.0472 10.3428 8.7041C9.91113 8.361 9.44076 8.07324 8.93164 7.84082ZM6.375 7.27637C5.60026 7.27637 4.93066 6.99967 4.36621 6.44629C3.81283 5.88184 3.53613 5.21224 3.53613 4.4375C3.53613 3.66276 3.81283 2.9987 4.36621 2.44531C4.93066 1.88086 5.60026 1.59863 6.375 1.59863C7.14974 1.59863 7.8138 1.88086 8.36719 2.44531C8.93164 2.9987 9.21387 3.66276 9.21387 4.4375C9.21387 5.21224 8.93164 5.88184 8.36719 6.44629C7.8138 6.99967 7.14974 7.27637 6.375 7.27637ZM14.6592 7.69141C14.9469 7.33724 15.1738 6.9388 15.3398 6.49609C15.5059 6.05339 15.5889 5.60514 15.5889 5.15137C15.5889 4.50944 15.4561 3.91732 15.1904 3.375C14.9248 2.82161 14.5706 2.35124 14.1279 1.96387C13.6963 1.56543 13.1927 1.27214 12.6172 1.08398C12.0527 0.884766 11.4606 0.823893 10.8408 0.901367C10.9404 1.00098 11.029 1.12272 11.1064 1.2666C11.1839 1.39941 11.2614 1.53776 11.3389 1.68164C11.4053 1.78125 11.4606 1.88639 11.5049 1.99707C11.5492 2.09668 11.5879 2.20182 11.6211 2.3125C12.429 2.45638 13.0544 2.79948 13.4971 3.3418C13.9398 3.87305 14.1611 4.47624 14.1611 5.15137C14.1611 5.60514 14.0505 6.03678 13.8291 6.44629C13.6188 6.84473 13.3532 7.16569 13.0322 7.40918C12.9215 7.48665 12.8441 7.5752 12.7998 7.6748C12.7666 7.77441 12.75 7.87402 12.75 7.97363C12.75 8.15072 12.7998 8.30566 12.8994 8.43848C12.999 8.57129 13.1374 8.6543 13.3145 8.6875C13.9564 8.83138 14.4932 9.16341 14.9248 9.68359C15.3675 10.1927 15.5889 10.7793 15.5889 11.4434H17C17 10.6686 16.7842 9.93815 16.3525 9.25195C15.932 8.56576 15.3675 8.04557 14.6592 7.69141Z"/></svg>'),
        array('icon-user-1','<svg class="icon icon-user-1" width="21" height="25" viewBox="0 0 21 25" xmlns="http://www.w3.org/2000/svg"><path d="M16.4147 6.05469C16.4147 6.83594 16.2662 7.5625 15.9694 8.23438C15.6881 8.90625 15.2975 9.5 14.7975 10.0156C14.2975 10.5156 13.7037 10.9141 13.0162 11.2109C12.3444 11.4922 11.6256 11.6328 10.86 11.6328C10.0944 11.6328 9.36781 11.4922 8.68031 11.2109C8.00844 10.9141 7.4225 10.5156 6.9225 10.0156C6.4225 9.5 6.02406 8.90625 5.72719 8.23438C5.44594 7.5625 5.30531 6.83594 5.30531 6.05469C5.30531 5.28906 5.44594 4.57031 5.72719 3.89844C6.02406 3.22656 6.4225 2.64062 6.9225 2.14062C7.4225 1.625 8.00844 1.22656 8.68031 0.945312C9.36781 0.648438 10.0944 0.5 10.86 0.5C11.6256 0.5 12.3444 0.648438 13.0162 0.945312C13.7037 1.22656 14.2975 1.625 14.7975 2.14062C15.2975 2.64062 15.6881 3.22656 15.9694 3.89844C16.2662 4.57031 16.4147 5.28906 16.4147 6.05469ZM10.86 14.4219C9.46937 14.4219 8.15687 14.6875 6.9225 15.2188C5.70375 15.7344 4.63344 16.4531 3.71156 17.375C2.80531 18.2812 2.08656 19.3516 1.55531 20.5859C1.03969 21.8047 0.781875 23.1094 0.781875 24.5H20.9381C20.9381 23.1094 20.6725 21.8047 20.1412 20.5859C19.6256 19.3516 18.9069 18.2812 17.985 17.375C17.0787 16.4531 16.0084 15.7344 14.7741 15.2188C13.5553 14.6875 12.2506 14.4219 10.86 14.4219Z" /></svg>'),
        array('icon-video','<svg class="icon icon-video" width="52" height="58" viewBox="0 0 52 58" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M49.9105 23.413H11.2622L48.3843 12.6592C48.6729 12.5756 48.9162 12.3804 49.0614 12.1176C49.2065 11.8543 49.241 11.5446 49.1574 11.256L47.2148 4.54988C46.4387 1.8714 43.9447 0.000488281 41.1498 0.000488281C40.5609 0.000488281 39.9741 0.0841217 39.405 0.248733L4.55114 10.3454C2.9391 10.8122 1.60318 11.884 0.788524 13.3624C-0.0256851 14.8408 -0.216847 16.5431 0.249995 18.1547L2.1479 24.7064V51.6961C2.1479 55.1724 4.97595 58.0005 8.45182 58.0005H22.0642C22.6899 58.0005 23.197 57.4934 23.197 56.8677C23.197 56.242 22.6899 55.7349 22.0642 55.7349H8.45227C6.22514 55.7349 4.41352 53.9232 4.41352 51.6961V36.2801H10.217H10.2196H10.2218H19.0932H19.0958H19.0985H27.9698H27.9725H27.9751H36.8465H36.8491H36.8513H48.7777V51.6961C48.7777 53.9232 46.9661 55.7349 44.739 55.7349H31.1267C30.5014 55.7349 29.9938 56.242 29.9938 56.8677C29.9938 57.4934 30.5014 58.0005 31.1267 58.0005H44.739C48.2153 58.0005 51.0434 55.1724 51.0434 51.6961V24.5458C51.0434 23.9201 50.5362 23.413 49.9105 23.413V23.413ZM29.9354 34.0145L34.7486 25.6786H41.0087L36.196 34.0145H29.9354ZM21.0588 34.0145L25.8719 25.6786H32.132L27.3193 34.0145H21.0588ZM12.1826 34.0145L16.9953 25.6786H23.2558L18.4427 34.0145H12.1826ZM16.3943 19.3495L8.33456 11.6083L14.3734 9.85905C14.4159 9.92101 14.4655 9.97942 14.5221 10.0338L22.5819 17.775L16.543 19.5242C16.5005 19.4623 16.4505 19.4034 16.3943 19.3495ZM31.574 5.09416L39.6338 12.8353L33.5949 14.5846C33.5525 14.5226 33.5029 14.4638 33.4463 14.4098L25.3865 6.66859L31.4253 4.91937C31.4678 4.98132 31.5174 5.03973 31.574 5.09416ZM23.0478 7.56422L31.1076 15.305L25.0688 17.0546C25.0263 16.9927 24.9767 16.9338 24.9201 16.8798L16.8603 9.13866L22.8992 7.38943C22.9421 7.45094 22.9916 7.5098 23.0478 7.56422ZM40.0356 2.42497C40.3993 2.31966 40.7741 2.26611 41.1498 2.26611C42.9424 2.26611 44.5412 3.46442 45.0386 5.18045L46.6661 10.798L42.1211 12.1145C42.0782 12.0526 42.0287 11.9941 41.972 11.9397L33.9127 4.19897L40.0356 2.42497ZM2.77316 14.4554C3.29531 13.5071 4.15068 12.8203 5.18171 12.5216L5.84724 12.3287C5.89016 12.3906 5.93972 12.4495 5.99592 12.5035L14.0557 20.2446L4.05377 23.1422L2.42623 17.5246C2.12754 16.494 2.251 15.4041 2.77316 14.4554ZM4.41352 25.6786H14.3792L9.56649 34.0145H4.41352V25.6786ZM38.8121 34.0145L43.6248 25.6786H48.7777V34.0145H38.8121Z" /><path fill-rule="evenodd" clip-rule="evenodd" d="M34.4285 45.8922C34.4285 45.4873 34.2125 45.1134 33.862 44.9112L23.9097 39.1653C23.5592 38.9631 23.1273 38.9631 22.7769 39.1653C22.4264 39.3675 22.2104 39.7414 22.2104 40.1463V51.6382C22.2104 52.0426 22.4264 52.4165 22.7769 52.6188C22.9521 52.7201 23.1477 52.771 23.3433 52.771C23.5388 52.771 23.7344 52.7201 23.9097 52.6188L33.862 46.8733C34.2125 46.671 34.4285 46.2971 34.4285 45.8922ZM24.4761 49.6761V42.1084L31.03 45.8922L24.4761 49.6761Z" /><path fill-rule="evenodd" clip-rule="evenodd" d="M26.5952 55.7349C25.9713 55.7349 25.4624 56.2437 25.4624 56.8677C25.4624 57.4916 25.9713 58.0005 26.5952 58.0005C27.2196 58.0005 27.728 57.4916 27.728 56.8677C27.728 56.2437 27.2196 55.7349 26.5952 55.7349Z" /></svg>'),
        array('icon-video-grad','<svg class="icon icon-video-grad" width="52" height="58" viewBox="0 0 52 58" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M49.9105 23.413H11.2622L48.3843 12.6592C48.6729 12.5756 48.9162 12.3804 49.0614 12.1176C49.2065 11.8543 49.241 11.5446 49.1574 11.256L47.2148 4.54988C46.4387 1.8714 43.9447 0.000488281 41.1498 0.000488281C40.5609 0.000488281 39.9741 0.0841217 39.405 0.248733L4.55114 10.3454C2.9391 10.8122 1.60318 11.884 0.788524 13.3624C-0.0256851 14.8408 -0.216847 16.5431 0.249995 18.1547L2.1479 24.7064V51.6961C2.1479 55.1724 4.97595 58.0005 8.45182 58.0005H22.0642C22.6899 58.0005 23.197 57.4934 23.197 56.8677C23.197 56.242 22.6899 55.7349 22.0642 55.7349H8.45227C6.22514 55.7349 4.41352 53.9232 4.41352 51.6961V36.2801H48.7777V51.6961C48.7777 53.9232 46.9661 55.7349 44.739 55.7349H31.1267C30.5014 55.7349 29.9938 56.242 29.9938 56.8677C29.9938 57.4934 30.5014 58.0005 31.1267 58.0005H44.739C48.2153 58.0005 51.0434 55.1724 51.0434 51.6961V24.5458C51.0434 23.9201 50.5363 23.413 49.9105 23.413ZM29.9354 34.0145L34.7486 25.6786H41.0087L36.196 34.0145H29.9354ZM21.0588 34.0145L25.8719 25.6786H32.132L27.3193 34.0145H21.0588ZM12.1826 34.0145L16.9953 25.6786H23.2558L18.4427 34.0145H12.1826ZM16.3943 19.3495L8.33456 11.6083L14.3734 9.85905C14.4159 9.92101 14.4655 9.97942 14.5221 10.0338L22.5819 17.775L16.543 19.5242C16.5005 19.4623 16.4505 19.4034 16.3943 19.3495ZM31.574 5.09416L39.6338 12.8353L33.595 14.5846C33.5525 14.5226 33.5029 14.4638 33.4463 14.4098L25.3865 6.66859L31.4253 4.91937C31.4678 4.98132 31.5174 5.03973 31.574 5.09416ZM23.0478 7.56422L31.1076 15.305L25.0688 17.0546C25.0263 16.9927 24.9767 16.9338 24.9201 16.8798L16.8603 9.13866L22.8992 7.38943C22.9421 7.45094 22.9916 7.5098 23.0478 7.56422ZM40.0356 2.42497C40.3993 2.31966 40.7742 2.26611 41.1498 2.26611C42.9424 2.26611 44.5412 3.46442 45.0386 5.18045L46.6661 10.798L42.1211 12.1145C42.0782 12.0526 42.0287 11.9941 41.972 11.9397L33.9127 4.19897L40.0356 2.42497ZM2.77316 14.4554C3.29531 13.5071 4.15068 12.8203 5.18171 12.5216L5.84724 12.3287C5.89016 12.3906 5.93972 12.4495 5.99592 12.5035L14.0557 20.2446L4.05377 23.1422L2.42623 17.5246C2.12754 16.494 2.251 15.4041 2.77316 14.4554ZM4.41352 25.6786H14.3792L9.56649 34.0145H4.41352V25.6786ZM38.8121 34.0145L43.6248 25.6786H48.7777V34.0145H38.8121Z" fill="url(#paint0_linear)"/><path fill-rule="evenodd" clip-rule="evenodd" d="M34.4285 45.8922C34.4285 45.4873 34.2125 45.1134 33.8621 44.9112L23.9097 39.1653C23.5592 38.963 23.1273 38.963 22.7769 39.1653C22.4264 39.3675 22.2105 39.7414 22.2105 40.1463V51.6381C22.2105 52.0426 22.4264 52.4165 22.7769 52.6187C22.9521 52.7201 23.1477 52.771 23.3433 52.771C23.5389 52.771 23.7344 52.7201 23.9097 52.6187L33.8621 46.8733C34.2125 46.671 34.4285 46.2971 34.4285 45.8922ZM24.4761 49.6761V42.1084L31.03 45.8922L24.4761 49.6761Z" fill="url(#paint0_linear)"/><path fill-rule="evenodd" clip-rule="evenodd" d="M26.5953 55.7349C25.9714 55.7349 25.4625 56.2437 25.4625 56.8677C25.4625 57.4916 25.9714 58.0005 26.5953 58.0005C27.2197 58.0005 27.7282 57.4916 27.7282 56.8677C27.7282 56.2437 27.2197 55.7349 26.5953 55.7349Z" fill="url(#paint0_linear)"/><defs><linearGradient id="paint0_linear" x1="51.1594" y1="30.9355" x2="-0.00242739" y2="30.9355" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint1_linear" x1="51.1594" y1="30.9355" x2="-0.00242739" y2="30.9355" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint2_linear" x1="51.1594" y1="30.9355" x2="-0.00242739" y2="30.9355" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient></defs></svg>'),
        array('icon-video-play','<svg class="icon icon-video-play" width="10" height="12" viewBox="0 0 10 12" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M8.72668 5.26101L1.65318 0.804285C1.44407 0.679788 1.18441 0.70053 0.988295 0.70053C0.203857 0.70053 0.207337 1.30617 0.207337 1.4596V10.5686C0.207337 10.6984 0.203903 11.3278 0.988295 11.3278C1.18441 11.3278 1.44411 11.3484 1.65318 11.224L8.72664 6.76729C9.30723 6.42182 9.20691 6.01413 9.20691 6.01413C9.20691 6.01413 9.30727 5.60643 8.72668 5.26101Z" /></svg>'),
        array('icon-vision',' <svg class="icon icon-vision" width="54" height="54" viewBox="0 0 54 54" xmlns="http://www.w3.org/2000/svg"><path d="M9.00394 32.2771C9.58644 32.2771 10.0586 31.8013 10.0586 31.2189V31.204C10.0586 30.6216 9.58644 30.153 9.00394 30.153C8.42144 30.153 7.94925 30.629 7.94925 31.2115V31.2261C7.94925 31.8086 8.42144 32.2771 9.00394 32.2771Z" fill="url(#paint0_linear)"/><path d="M40.2388 40.7028C40.2652 40.7048 40.2917 40.7058 40.3182 40.7058C40.5968 40.7058 40.8654 40.5954 41.0639 40.3968C44.2888 37.1712 46.0647 32.8831 46.0647 28.322C46.0647 23.0739 43.6847 18.3721 39.9481 15.2368L41.9589 13.2259H44.9971C45.5796 13.2259 46.0518 12.7536 46.0518 12.1712C46.0518 11.5888 45.5796 11.1165 44.9971 11.1165H41.5221C41.2424 11.1165 40.9741 11.2277 40.7763 11.4254L38.2324 13.9694C35.5659 12.2456 32.3911 11.2437 28.9865 11.2437C28.404 11.2437 27.9318 11.716 27.9318 12.2984V22.3232C27.9318 22.9056 28.404 23.3779 28.9865 23.3779C31.7128 23.3779 33.9307 25.5958 33.9307 28.3221C33.9307 29.6426 33.4164 30.8843 32.4826 31.818C32.0707 32.2299 32.0707 32.8977 32.4826 33.3097L39.5697 40.3968C39.748 40.5751 39.9871 40.6838 40.2388 40.7028ZM30.0412 21.3471V13.3898C32.4649 13.5594 34.7313 14.3085 36.7025 15.4992L35.8957 16.306C35.4838 16.7179 35.4838 17.3857 35.8957 17.7977C36.1016 18.0035 36.3715 18.1066 36.6414 18.1066C36.9113 18.1066 37.1813 18.0035 37.3872 17.7977L38.4508 16.734C41.8083 19.4814 43.9553 23.6555 43.9553 28.322C43.9553 31.9666 42.6614 35.4125 40.2911 38.1351L34.6647 32.5088C35.5574 31.3032 36.0399 29.8496 36.0399 28.322C36.04 24.7912 33.4319 21.8578 30.0412 21.3471Z" fill="url(#paint0_linear)"/><path d="M9.00394 48.3045H16.3196C16.5993 48.3045 16.8676 48.1933 17.0653 47.9956L18.1904 46.8705C20.3016 47.7962 22.6202 48.3045 25.0275 48.3045C29.5899 48.3045 33.8791 46.5275 37.1049 43.3011C37.391 43.015 37.4868 42.5903 37.3536 42.2083C37.2966 42.0445 37.2013 41.9009 37.0793 41.7866L30.015 34.7223C29.6031 34.3106 28.9353 34.3106 28.5234 34.7223C27.5895 35.6561 26.348 36.1704 25.0274 36.1704C23.6662 36.1704 22.4318 35.6173 21.5368 34.7243L21.5333 34.7204L21.5294 34.7169C20.6363 33.8219 20.0832 32.5875 20.0832 31.2262C20.0832 28.5001 22.3011 26.2822 25.0273 26.2822C25.6098 26.2822 26.082 25.8099 26.082 25.2275V15.2027C26.082 14.6203 25.6098 14.148 25.0273 14.148C21.6043 14.148 18.3617 15.1753 15.6392 16.9683L13.2245 14.5536C13.0267 14.3559 12.7584 14.2447 12.4787 14.2447H9.00394C8.42144 14.2447 7.94925 14.717 7.94925 15.2994C7.94925 15.8818 8.42144 16.3541 9.00394 16.3541H12.0421L13.936 18.248C11.3915 20.4187 9.47307 23.3368 8.54979 26.7222C8.39655 27.2841 8.72782 27.8639 9.28976 28.0171C9.8517 28.1704 10.4316 27.8391 10.5848 27.2772C11.4093 24.2543 13.14 21.6579 15.433 19.7449L16.6137 20.9256C16.8197 21.1315 17.0896 21.2345 17.3595 21.2345C17.6294 21.2345 17.8994 21.1315 18.1053 20.9256C18.5171 20.5138 18.5171 19.8459 18.1053 19.434L17.1672 18.4959C19.1886 17.2471 21.5133 16.4681 23.9728 16.2943V24.2512C20.5821 24.7618 17.9741 27.695 17.9741 31.2259C17.9741 32.7909 18.4871 34.2379 19.3527 35.4092L13.725 41.0369C12.2844 39.3833 11.1942 37.4004 10.5888 35.1896C10.4349 34.6278 9.85444 34.2971 9.29303 34.451C8.7312 34.6048 8.40055 35.185 8.55433 35.7468C9.74011 40.0767 12.5551 43.6412 16.2253 45.8522L15.8827 46.1951H9.00394C8.42144 46.1951 7.94925 46.6674 7.94925 47.2498C7.94925 47.8322 8.42144 48.3045 9.00394 48.3045ZM15.2187 42.5267L20.8443 36.9011C22.0155 37.7668 23.4625 38.2798 25.0275 38.2798C26.5552 38.2798 28.0089 37.7974 29.2143 36.9046L34.8406 42.531C32.1182 44.9012 28.6723 46.1951 25.0275 46.1951C23.2078 46.1951 21.4463 45.8633 19.809 45.252L21.2109 43.8501C21.6227 43.4382 21.6227 42.7704 21.2109 42.3585C20.799 41.9467 20.1312 41.9467 19.7192 42.3585L17.7677 44.3101C16.8582 43.8046 16.0037 43.2066 15.2187 42.5267Z" fill="url(#paint2_linear)"/><path d="M50.8364 18.8048C50.559 18.8048 50.2869 18.9176 50.0908 19.1138C49.8946 19.31 49.7817 19.5821 49.7817 19.8595C49.7817 20.1369 49.8946 20.409 50.0908 20.6051C50.2869 20.8012 50.559 20.9142 50.8364 20.9142C51.1138 20.9142 51.3859 20.8013 51.5821 20.6051C51.7783 20.409 51.8911 20.1369 51.8911 19.8595C51.8911 19.5821 51.7783 19.31 51.5821 19.1138C51.3859 18.9176 51.1138 18.8048 50.8364 18.8048Z" fill="url(#paint3_linear)"/><path d="M52.9458 -0.000244141H1.05518C0.472672 -0.000244141 0.000488281 0.472045 0.000488281 1.05444V6.74976C0.000488281 7.33215 0.472672 7.80444 1.05518 7.80444H2.10986V52.9451C2.10986 53.5275 2.58205 53.9998 3.16455 53.9998H50.8364C51.4189 53.9998 51.8911 53.5275 51.8911 52.9451V24.0782C51.8911 23.4958 51.4189 23.0235 50.8364 23.0235C50.2539 23.0235 49.7817 23.4958 49.7817 24.0782V51.8904H4.21924V7.80444H49.7817V15.6407C49.7817 16.2231 50.2539 16.6954 50.8364 16.6954C51.4189 16.6954 51.8911 16.2231 51.8911 15.6407V7.80444H52.9458C53.5283 7.80444 54.0005 7.33215 54.0005 6.74976V1.05444C54.0005 0.472045 53.5283 -0.000244141 52.9458 -0.000244141ZM51.8911 5.69507H2.10986V2.10913H51.8911V5.69507Z" fill="url(#paint4_linear)"/><defs><linearGradient id="paint0_linear" x1="54.1232" y1="28.8013" x2="-0.00207971" y2="28.8013" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint1_linear" x1="54.1232" y1="28.8013" x2="-0.00207971" y2="28.8013" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint2_linear" x1="54.1232" y1="28.8013" x2="-0.00207971" y2="28.8013" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint3_linear" x1="54.1232" y1="28.8013" x2="-0.00207971" y2="28.8013" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint4_linear" x1="54.1232" y1="28.8013" x2="-0.00207971" y2="28.8013" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient></defs></svg>'),
        array('icon-voice','<svg class="icon icon-voice" width="58" height="58" viewBox="0 0 58 58" xmlns="http://www.w3.org/2000/svg"><path d="M53.2729 39.4259C53.0132 38.6294 52.6899 37.5048 52.3194 36.2185C50.7817 30.8899 49.3657 26.259 47.8456 23.972C53.5887 23.0409 58 18.0856 58 12.0839C58 5.42145 52.579 0.000488281 45.9166 0.000488281C39.2542 0.000488281 33.8334 5.42145 33.8334 12.0839C33.8334 12.6864 33.9257 13.2641 34.0112 13.8432L27.3146 21.5517C26.9318 21.372 26.55 21.2364 26.175 21.1593C25.0209 20.9174 24.032 21.1947 23.265 21.9405C21.7019 23.4596 21.5101 25.5569 22.0047 27.6647L11.1229 40.1941C10.1835 41.2526 9.66674 42.6132 9.66674 44.0268C9.66674 45.455 10.2019 46.7923 11.1465 47.8534C10.2816 49.3891 8.91591 50.3926 7.01415 50.7742C0.0802031 52.1606 0 56.6034 0 56.7921C0 57.4482 0.523926 57.9698 1.18005 57.9851C1.18945 57.9851 1.19897 57.9862 1.20837 57.9862C1.85271 57.9862 2.38604 57.4647 2.41674 56.8179C2.4215 56.7082 2.59607 54.1216 7.48608 53.1433C10.2947 52.5815 11.9674 51.0993 12.9596 49.6042C13.925 50.3354 15.0831 50.7505 16.3125 50.7505C17.8017 50.7505 19.2036 50.1699 20.2608 49.1149L27.6905 41.6853C27.8119 43.1033 28.1955 44.7186 30.1446 47.3214C31.4048 49.004 33.045 49.9682 34.7797 50.9888C37.1539 52.3859 39.6083 53.8303 41.7465 57.4117C41.9661 57.7774 42.3602 58.0005 42.785 58.0005C53.9101 58.0005 57.8773 48.2713 57.9152 48.1733C58.0757 47.7686 58.0049 47.3096 57.7334 46.9709C57.6979 46.9296 54.3561 42.763 53.2729 39.4259ZM45.9166 2.41712C51.248 2.41712 55.5833 6.75364 55.5833 12.0837C55.5833 14.3133 54.7938 16.3433 53.5211 17.9806L40.0203 4.47895C41.6573 3.20646 43.687 2.41712 45.9166 2.41712ZM38.3116 6.18757L51.8125 19.6893C50.1757 20.9615 48.146 21.7505 45.9166 21.7505C40.5854 21.7505 36.25 17.414 36.25 12.0839C36.25 9.85448 37.0391 7.82471 38.3116 6.18757ZM34.7523 16.6789C36.1194 19.9874 38.9291 22.5113 42.3799 23.5775L34.8863 31.072C34.3155 30.058 33.8043 28.9893 33.3967 28.0069C32.8397 26.6703 31.2199 24.4663 29.3457 22.9021L34.7523 16.6789ZM39.0585 32.8272C38.9216 33.0668 38.8036 33.3276 38.6832 33.5954C38.4778 34.0497 38.2536 34.5465 37.9445 34.9347C37.3668 34.5322 36.7864 33.8967 36.2272 33.1483L38.4004 30.975C38.6108 31.6089 38.845 32.2855 39.0585 32.8272ZM18.5522 47.4052C17.3533 48.604 15.2718 48.604 14.0728 47.4052L13.4977 46.8306C13.4946 46.8273 13.4913 46.8246 13.4883 46.8213L13.0674 46.4009C12.4326 45.7649 12.0833 44.9224 12.0833 44.0268C12.0833 43.2055 12.3854 42.4137 12.94 41.7884L22.9421 30.2742C23.3371 31.0866 23.793 31.8688 24.2917 32.5701C25.7165 34.5788 26.8166 36.8491 27.3044 38.6541L18.5522 47.4052ZM43.4481 55.5708C41.0692 51.8868 38.2725 50.2419 36.0046 48.9062C34.4187 47.9727 33.0499 47.1668 32.0799 45.8724C30.173 43.3271 30.1187 42.1718 30.0479 40.7087C30.0313 40.3759 30.0148 40.0384 29.9818 39.682C29.7552 37.3739 28.2944 34.0321 26.2601 31.1706C24.4853 28.6713 23.3171 25.2587 24.9479 23.6751C25.0825 23.5466 25.2571 23.4392 25.6866 23.5264C27.5063 23.9005 30.4303 27.1738 31.1642 28.9356C32.0611 31.0903 34.4849 36.2422 37.6661 37.5225C38.0249 37.6713 38.4426 37.6299 38.773 37.4163C39.953 36.6516 40.4935 35.4598 40.8852 34.5901C40.9938 34.3483 41.1449 34.0178 41.1236 34.0061C41.6334 33.6638 41.8057 32.9948 41.5248 32.4496C41.2605 31.9349 40.7151 30.308 40.3205 29.055L44.9354 24.4396C45.1708 24.5865 45.3582 24.7237 45.4448 24.8078C46.9293 26.2487 48.8504 32.9086 49.9974 36.8876C50.3773 38.2056 50.7077 39.3573 50.9744 40.1739C51.9467 43.1617 54.3658 46.5412 55.3876 47.8912C54.441 49.7652 51.0238 55.2652 43.4481 55.5708Z" /></svg>'),
        array('icon-voice-grad','<svg class="icon icon-voice-grad" width="58" height="58" viewBox="0 0 58 58" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M53.2729 39.4259C53.0132 38.6294 52.6899 37.5048 52.3194 36.2185C50.7817 30.8899 49.3657 26.259 47.8456 23.972C53.5887 23.0409 58 18.0856 58 12.0839C58 5.42145 52.579 0.000488281 45.9166 0.000488281C39.2542 0.000488281 33.8334 5.42145 33.8334 12.0839C33.8334 12.6864 33.9257 13.2641 34.0112 13.8432L27.3146 21.5517C26.9318 21.372 26.55 21.2364 26.175 21.1593C25.0209 20.9174 24.032 21.1947 23.265 21.9405C21.7019 23.4596 21.5101 25.5569 22.0047 27.6647L11.1229 40.1941C10.1835 41.2526 9.66674 42.6132 9.66674 44.0268C9.66674 45.455 10.2019 46.7923 11.1465 47.8534C10.2816 49.3891 8.91591 50.3926 7.01415 50.7742C0.0802031 52.1606 0 56.6034 0 56.7921C0 57.4482 0.523926 57.9698 1.18005 57.9851C1.18945 57.9851 1.19897 57.9862 1.20837 57.9862C1.85271 57.9862 2.38604 57.4647 2.41674 56.8179C2.4215 56.7082 2.59607 54.1216 7.48608 53.1433C10.2947 52.5815 11.9674 51.0993 12.9596 49.6042C13.925 50.3354 15.0831 50.7505 16.3125 50.7505C17.8017 50.7505 19.2036 50.1699 20.2608 49.1149L27.6905 41.6853C27.8119 43.1033 28.1955 44.7186 30.1446 47.3214C31.4048 49.004 33.045 49.9682 34.7797 50.9888C37.1539 52.3859 39.6083 53.8303 41.7465 57.4117C41.9661 57.7774 42.3602 58.0005 42.785 58.0005C53.9101 58.0005 57.8773 48.2713 57.9152 48.1733C58.0757 47.7686 58.0049 47.3096 57.7334 46.9709C57.6979 46.9296 54.3561 42.763 53.2729 39.4259ZM45.9166 2.41712C51.248 2.41712 55.5833 6.75364 55.5833 12.0837C55.5833 14.3133 54.7938 16.3433 53.5211 17.9806L40.0203 4.47895C41.6573 3.20646 43.687 2.41712 45.9166 2.41712ZM38.3116 6.18757L51.8125 19.6893C50.1757 20.9615 48.146 21.7505 45.9166 21.7505C40.5854 21.7505 36.25 17.414 36.25 12.0839C36.25 9.85448 37.0391 7.82471 38.3116 6.18757ZM34.7523 16.6789C36.1194 19.9874 38.9291 22.5113 42.3799 23.5775L34.8863 31.072C34.3155 30.058 33.8043 28.9893 33.3967 28.0069C32.8397 26.6703 31.2199 24.4663 29.3457 22.9021L34.7523 16.6789ZM39.0585 32.8272C38.9216 33.0668 38.8036 33.3276 38.6832 33.5954C38.4778 34.0497 38.2536 34.5465 37.9445 34.9347C37.3668 34.5322 36.7864 33.8967 36.2272 33.1483L38.4004 30.975C38.6108 31.6089 38.845 32.2855 39.0585 32.8272ZM18.5522 47.4052C17.3533 48.604 15.2718 48.604 14.0728 47.4052L13.4977 46.8306C13.4946 46.8273 13.4913 46.8246 13.4883 46.8213L13.0674 46.4009C12.4326 45.7649 12.0833 44.9224 12.0833 44.0268C12.0833 43.2055 12.3854 42.4137 12.94 41.7884L22.9421 30.2742C23.3371 31.0866 23.793 31.8688 24.2917 32.5701C25.7165 34.5788 26.8166 36.8491 27.3044 38.6541L18.5522 47.4052ZM43.4481 55.5708C41.0692 51.8868 38.2725 50.2419 36.0046 48.9062C34.4187 47.9727 33.0499 47.1668 32.0799 45.8724C30.173 43.3271 30.1187 42.1718 30.0479 40.7087C30.0313 40.3759 30.0148 40.0384 29.9818 39.682C29.7552 37.3739 28.2944 34.0321 26.2601 31.1706C24.4853 28.6713 23.3171 25.2587 24.9479 23.6751C25.0825 23.5466 25.2571 23.4392 25.6866 23.5264C27.5063 23.9005 30.4303 27.1738 31.1642 28.9356C32.0611 31.0903 34.4849 36.2422 37.6661 37.5225C38.0249 37.6713 38.4426 37.6299 38.773 37.4163C39.953 36.6516 40.4935 35.4598 40.8852 34.5901C40.9938 34.3483 41.1449 34.0178 41.1236 34.0061C41.6334 33.6638 41.8056 32.9948 41.5248 32.4496C41.2605 31.9349 40.7151 30.308 40.3205 29.055L44.9354 24.4396C45.1708 24.5865 45.3582 24.7237 45.4448 24.8078C46.9292 26.2487 48.8504 32.9086 49.9974 36.8876C50.3773 38.2056 50.7077 39.3573 50.9744 40.1739C51.9467 43.1617 54.3658 46.5412 55.3876 47.8912C54.441 49.7652 51.0238 55.2652 43.4481 55.5708Z" fill="url(#paint0_linear)"/><defs><linearGradient id="paint0_linear" x1="58.1319" y1="30.9355" x2="-0.00275821" y2="30.9355" gradientUnits="userSpaceOnUse"><stop stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient></defs></svg>'),
        array('icon-volume','<svg class="icon icon-volume" width="20" height="14" viewBox="0 0 20 14" xmlns="http://www.w3.org/2000/svg"><path d="M1.11328 9.47656C0.800781 9.47656 0.533854 9.58724 0.3125 9.80859C0.104167 10.0169 0 10.2773 0 10.5898V12.7969C0 13.1094 0.104167 13.3763 0.3125 13.5977C0.533854 13.806 0.800781 13.9102 1.11328 13.9102C1.41276 13.9102 1.67318 13.806 1.89453 13.5977C2.11589 13.3763 2.22656 13.1094 2.22656 12.7969V10.5898C2.22656 10.2773 2.11589 10.0169 1.89453 9.80859C1.67318 9.58724 1.41276 9.47656 1.11328 9.47656ZM5.54688 7.25C5.2474 7.25 4.98698 7.36068 4.76562 7.58203C4.55729 7.79036 4.45312 8.05078 4.45312 8.36328V12.7969C4.45312 13.1094 4.55729 13.3763 4.76562 13.5977C4.98698 13.806 5.2474 13.9102 5.54688 13.9102C5.85938 13.9102 6.11979 13.806 6.32812 13.5977C6.54948 13.3763 6.66016 13.1094 6.66016 12.7969V8.36328C6.66016 8.05078 6.54948 7.79036 6.32812 7.58203C6.11979 7.36068 5.85938 7.25 5.54688 7.25ZM10 5.02344C9.6875 5.02344 9.42057 5.13411 9.19922 5.35547C8.99089 5.57682 8.88672 5.83724 8.88672 6.13672V12.7969C8.88672 13.1094 8.99089 13.3763 9.19922 13.5977C9.42057 13.806 9.6875 13.9102 10 13.9102C10.3125 13.9102 10.5729 13.806 10.7812 13.5977C11.0026 13.3763 11.1133 13.1094 11.1133 12.7969V6.13672C11.1133 5.83724 11.0026 5.57682 10.7812 5.35547C10.5729 5.13411 10.3125 5.02344 10 5.02344ZM14.4531 2.79688C14.1406 2.79688 13.8737 2.90755 13.6523 3.12891C13.444 3.35026 13.3398 3.61068 13.3398 3.91016V12.7969C13.3398 13.1094 13.444 13.3763 13.6523 13.5977C13.8737 13.806 14.1406 13.9102 14.4531 13.9102C14.7526 13.9102 15.0065 13.806 15.2148 13.5977C15.4362 13.3763 15.5469 13.1094 15.5469 12.7969V3.91016C15.5469 3.61068 15.4362 3.35026 15.2148 3.12891C15.0065 2.90755 14.7526 2.79688 14.4531 2.79688ZM18.8867 0.589844C18.5872 0.589844 18.3268 0.700521 18.1055 0.921875C17.8841 1.13021 17.7734 1.39062 17.7734 1.70312V12.7969C17.7734 13.1094 17.8841 13.3763 18.1055 13.5977C18.3268 13.806 18.5872 13.9102 18.8867 13.9102C19.1992 13.9102 19.4596 13.806 19.668 13.5977C19.8893 13.3763 20 13.1094 20 12.7969V1.70312C20 1.39062 19.8893 1.13021 19.668 0.921875C19.4596 0.700521 19.1992 0.589844 18.8867 0.589844Z" /></svg>'),
        array('icon-pause','<svg class="icon icon-pause" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 30 31" style="enable-background:new 0 0 30 31;" xml:space="preserve"><path d="M8.8,8.5h4.1V24H8.8V8.5z M16.6,24.1h4.1V8.5h-4.1V24.1z M30,15.9c0,2.1-0.4,4-1.2,5.9c-0.8,1.8-1.9,3.4-3.2,4.8c-1.3,1.3-2.9,2.4-4.8,3.2c-1.8,0.8-3.8,1.2-5.8,1.2s-4-0.4-5.9-1.2c-1.8-0.8-3.4-1.8-4.8-3.2c-1.3-1.4-2.4-3-3.2-4.8C0.4,19.9,0,17.9,0,15.9s0.4-4,1.2-5.8C2,8.2,3,6.6,4.4,5.3c1.4-1.4,3-2.4,4.8-3.2C11,1.3,12.9,0.9,15,0.9s4,0.4,5.8,1.2c1.8,0.8,3.4,1.9,4.8,3.2C27,6.6,28,8.2,28.8,10C29.6,11.9,30,13.8,30,15.9z M27.2,15.9c0-1.7-0.3-3.3-1-4.7c-0.6-1.5-1.5-2.8-2.6-3.9c-1.1-1.1-2.4-2-3.9-2.6c-1.5-0.6-3.1-1-4.7-1s-3.3,0.3-4.7,1C8.8,5.3,7.5,6.1,6.4,7.3c-1.1,1.1-2,2.4-2.6,3.9c-0.6,1.5-0.9,3.1-0.9,4.7s0.3,3.3,0.9,4.7c0.6,1.5,1.5,2.8,2.6,3.9c1.1,1.1,2.4,2,3.9,2.6c1.5,0.6,3.1,0.9,4.7,0.9s3.3-0.3,4.7-0.9c1.5-0.6,2.8-1.5,3.9-2.6c1.1-1.1,2-2.4,2.6-3.9C26.9,19.1,27.2,17.6,27.2,15.9z"/></svg>'),
    );
    $atts = shortcode_atts( array(
        'icon' => '',
        'class' => '',
        'link' => ''
    ), $atts, 'voicer_icon' ) ;

    $class = "{$atts['class']}";
    $icon = "{$atts['icon']}";
    $link = "{$atts['link']}";

    foreach ($ch_icons as $ch_icon) :
        $ch_short = $ch_icon [0];
        $ch_svg = $ch_icon [1];

        if ($icon == $ch_short ) :
            if (isset($link) && $link != '') {
                return '<a href="'.esc_url($link).'" '.(isset($class) && $class != '' ? 'class="'.esc_attr($class).'"' : '').'>'.($ch_svg)."$content".'</a>';
            } else {
                if (isset($class) && $class != '') {
                    return '<div class="'.esc_attr($class).'">'.($ch_svg)."$content".'</div>';
                } else {
                    return $ch_svg;
                }
            }
        endif;
    endforeach;
}
add_shortcode( 'voicer_icon', 'voicer_icon_func' );


function voicer_logo_svg0 () {
    $logo_svg = '<a class="header-logo" href="'.esc_url( home_url( '/' ) ).'" rel="home">
<svg class="icon ch-icon-logo" width="258" height="59" viewBox="0 0 258 59" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M33.4942 54C31.9671 53.3232 31.5079 52.1387 31.5399 50.5206C31.6253 46.248 31.5933 41.9754 31.5719 37.7028C31.5613 35.8203 30.5467 34.7627 28.9021 34.7945C27.3536 34.8262 26.4459 35.8732 26.3818 37.7028C26.3712 38.1152 26.3818 38.5277 26.3818 38.9402C26.3818 42.8003 26.4032 46.6604 26.3925 50.5206C26.3818 52.5511 25.41 53.7145 23.7975 53.651C22.281 53.5981 21.3412 52.4136 21.3412 50.5206C21.3412 45.476 21.3626 40.4313 21.3626 35.3867C21.3626 34.8791 21.3946 34.3397 21.2665 33.8532C20.9034 32.5418 19.9743 31.8861 18.5967 31.9707C17.2831 32.0554 16.4608 32.7745 16.29 34.0542C16.1618 35.0166 16.2473 36.0107 16.1939 36.9836C16.0977 38.6229 15.0085 39.7439 13.5988 39.7016C12.2425 39.6593 11.2387 38.5594 11.1746 36.9836C11.1319 36.1059 11.196 35.2387 11.1639 34.3609C11.0999 32.6899 10.1067 31.6006 8.67569 31.5689C7.10584 31.5371 6.102 32.5736 6.01656 34.3397C6.00588 34.5935 6.02724 34.8579 5.98452 35.1117C5.76026 36.4549 4.69234 37.3432 3.38947 37.2903C2.07593 37.2375 1.06141 36.2962 1.04005 34.9002C0.986651 31.9707 0.986651 29.0307 1.04005 26.1012C1.06141 24.6841 2.20408 23.6265 3.49627 23.6265C4.74574 23.6265 5.80298 24.5995 5.98452 25.9532C6.02724 26.3127 5.98453 26.6723 6.01656 27.0319C6.14471 28.4385 7.19128 29.3903 8.60093 29.3797C9.98923 29.3691 11.0892 28.4067 11.1426 27.0002C11.2173 25.308 11.1639 23.6053 11.1853 21.9027C11.2067 20.1365 12.2212 18.9309 13.6415 18.9097C15.1153 18.8886 16.1084 20.0202 16.1832 21.8075C16.2045 22.368 16.1832 22.9391 16.1939 23.5102C16.2259 25.5196 17.1763 26.6829 18.7782 26.6935C20.3908 26.704 21.384 25.5196 21.384 23.5419C21.3946 20.5067 21.3626 17.4714 21.4053 14.4362C21.4267 12.522 22.8684 11.2952 24.5023 11.7711C25.8265 12.1624 26.3818 13.1248 26.3712 14.4573C26.3605 16.9744 26.3605 19.502 26.3712 22.019C26.3818 24.2293 27.3536 25.4878 29.0196 25.4667C30.6642 25.4455 31.5719 24.2716 31.5719 22.093C31.5826 15.9697 31.5826 9.84632 31.5826 3.72297C31.5826 3.36339 31.5719 3.00382 31.5826 2.64424C31.668 1.03673 32.6185 0.0214629 34.0281 0.000311481C35.5232 -0.02084 36.5271 1.03673 36.5271 2.71827C36.5484 7.96384 36.5484 13.22 36.5591 18.4655C36.5591 18.7194 36.5378 18.9838 36.5591 19.2376C36.6873 20.6759 37.6804 21.6488 39.0687 21.6806C40.5318 21.7229 41.6424 20.7499 41.7065 19.227C41.7919 16.9109 41.7492 14.5948 41.7813 12.2787C41.8133 10.3963 42.8278 9.22235 44.3549 9.26465C45.818 9.30695 46.7685 10.4597 46.7791 12.2787C46.8005 15.6207 46.7791 18.9732 46.8112 22.3151C46.8325 24.2399 47.783 25.308 49.3849 25.2975C50.9867 25.2869 51.8838 24.2082 51.9265 22.2728C51.9372 21.9132 51.9158 21.5537 51.9586 21.1941C52.1401 19.7346 53.176 18.7722 54.5216 18.804C55.8992 18.8357 56.9137 19.7981 56.9458 21.2998C57.0098 24.0284 56.9885 26.7569 56.9885 29.4855C56.9885 30.9766 57.0205 32.4678 56.9778 33.959C56.9351 35.6723 55.9739 36.7087 54.4895 36.7193C52.9304 36.7404 51.9479 35.6617 51.9052 33.8744C51.8838 33.0495 51.9372 32.2246 51.8945 31.4102C51.8197 29.8344 50.8372 28.8826 49.3421 28.8932C47.8471 28.9038 46.8432 29.845 46.8325 31.442C46.8005 35.1963 46.8325 38.9507 46.8325 42.7157C46.8325 43.181 46.8539 43.6464 46.7791 44.1011C46.5442 45.4231 45.4229 46.3537 44.152 46.2586C42.7851 46.1528 41.8881 45.3808 41.7813 44.0271C41.6531 42.4407 41.7279 40.8438 41.7172 39.2469C41.7065 37.1846 40.8201 36.0741 39.1755 36.0636C37.4989 36.053 36.5805 37.1423 36.5805 39.194C36.5698 42.9484 36.5271 46.7133 36.6232 50.4677C36.6659 52.0858 36.1853 53.2597 34.7116 54C34.3272 54 33.9107 54 33.4942 54Z" fill="url(#paint0_linear)"/><path d="M76.946 6.264L83.666 27.684L90.344 6.264H99.122L88.958 36H78.332L68.168 6.264H76.946ZM113.365 5.802C116.165 5.802 118.713 6.46 121.009 7.776C123.333 9.064 125.153 10.87 126.469 13.194C127.813 15.518 128.485 18.136 128.485 21.048C128.485 23.96 127.813 26.578 126.469 28.902C125.125 31.226 123.291 33.046 120.967 34.362C118.671 35.65 116.137 36.294 113.365 36.294C110.593 36.294 108.045 35.65 105.721 34.362C103.397 33.046 101.563 31.226 100.219 28.902C98.8749 26.578 98.2029 23.96 98.2029 21.048C98.2029 18.136 98.8749 15.518 100.219 13.194C101.563 10.87 103.397 9.064 105.721 7.776C108.045 6.46 110.593 5.802 113.365 5.802ZM113.365 13.446C111.265 13.446 109.613 14.132 108.409 15.504C107.205 16.848 106.603 18.696 106.603 21.048C106.603 23.344 107.205 25.178 108.409 26.55C109.613 27.922 111.265 28.608 113.365 28.608C115.437 28.608 117.075 27.922 118.279 26.55C119.483 25.178 120.085 23.344 120.085 21.048C120.085 18.696 119.483 16.848 118.279 15.504C117.103 14.132 115.465 13.446 113.365 13.446ZM137.938 6.264V36H129.664V6.264H137.938ZM153.715 5.97C156.263 5.97 158.531 6.446 160.519 7.398C162.535 8.322 164.173 9.652 165.433 11.388C166.693 13.096 167.547 15.084 167.995 17.352H159.301C158.825 16.176 158.083 15.266 157.075 14.622C156.067 13.95 154.905 13.614 153.589 13.614C151.769 13.614 150.299 14.3 149.179 15.672C148.059 17.016 147.499 18.822 147.499 21.09C147.499 23.358 148.059 25.178 149.179 26.55C150.299 27.922 151.769 28.608 153.589 28.608C154.905 28.608 156.067 28.272 157.075 27.6C158.083 26.928 158.825 26.004 159.301 24.828H167.995C167.323 28.3 165.727 31.072 163.207 33.144C160.715 35.188 157.551 36.21 153.715 36.21C150.775 36.21 148.199 35.58 145.987 34.32C143.803 33.032 142.109 31.24 140.905 28.944C139.729 26.648 139.141 24.03 139.141 21.09C139.141 18.15 139.729 15.532 140.905 13.236C142.109 10.94 143.803 9.162 145.987 7.902C148.199 6.614 150.775 5.97 153.715 5.97ZM177.441 12.858V17.772H187.059V24.03H177.441V29.406H188.319V36H169.167V6.264H188.319V12.858H177.441ZM204.694 36L198.688 25.038H197.848V36H189.574V6.264H202.636C205.016 6.264 207.032 6.684 208.684 7.524C210.364 8.336 211.624 9.47 212.464 10.926C213.304 12.382 213.724 14.02 213.724 15.84C213.724 17.912 213.15 19.718 212.002 21.258C210.854 22.77 209.202 23.834 207.046 24.45L213.808 36H204.694ZM197.848 19.494H201.922C204.218 19.494 205.366 18.458 205.366 16.386C205.366 15.406 205.072 14.636 204.484 14.076C203.924 13.516 203.07 13.236 201.922 13.236H197.848V19.494Z" fill="#CECECE"/><path d="M76.946 6.264L83.666 27.684L90.344 6.264H99.122L88.958 36H78.332L68.168 6.264H76.946ZM113.365 5.802C116.165 5.802 118.713 6.46 121.009 7.776C123.333 9.064 125.153 10.87 126.469 13.194C127.813 15.518 128.485 18.136 128.485 21.048C128.485 23.96 127.813 26.578 126.469 28.902C125.125 31.226 123.291 33.046 120.967 34.362C118.671 35.65 116.137 36.294 113.365 36.294C110.593 36.294 108.045 35.65 105.721 34.362C103.397 33.046 101.563 31.226 100.219 28.902C98.8749 26.578 98.2029 23.96 98.2029 21.048C98.2029 18.136 98.8749 15.518 100.219 13.194C101.563 10.87 103.397 9.064 105.721 7.776C108.045 6.46 110.593 5.802 113.365 5.802ZM113.365 13.446C111.265 13.446 109.613 14.132 108.409 15.504C107.205 16.848 106.603 18.696 106.603 21.048C106.603 23.344 107.205 25.178 108.409 26.55C109.613 27.922 111.265 28.608 113.365 28.608C115.437 28.608 117.075 27.922 118.279 26.55C119.483 25.178 120.085 23.344 120.085 21.048C120.085 18.696 119.483 16.848 118.279 15.504C117.103 14.132 115.465 13.446 113.365 13.446ZM137.938 6.264V36H129.664V6.264H137.938ZM153.715 5.97C156.263 5.97 158.531 6.446 160.519 7.398C162.535 8.322 164.173 9.652 165.433 11.388C166.693 13.096 167.547 15.084 167.995 17.352H159.301C158.825 16.176 158.083 15.266 157.075 14.622C156.067 13.95 154.905 13.614 153.589 13.614C151.769 13.614 150.299 14.3 149.179 15.672C148.059 17.016 147.499 18.822 147.499 21.09C147.499 23.358 148.059 25.178 149.179 26.55C150.299 27.922 151.769 28.608 153.589 28.608C154.905 28.608 156.067 28.272 157.075 27.6C158.083 26.928 158.825 26.004 159.301 24.828H167.995C167.323 28.3 165.727 31.072 163.207 33.144C160.715 35.188 157.551 36.21 153.715 36.21C150.775 36.21 148.199 35.58 145.987 34.32C143.803 33.032 142.109 31.24 140.905 28.944C139.729 26.648 139.141 24.03 139.141 21.09C139.141 18.15 139.729 15.532 140.905 13.236C142.109 10.94 143.803 9.162 145.987 7.902C148.199 6.614 150.775 5.97 153.715 5.97ZM177.441 12.858V17.772H187.059V24.03H177.441V29.406H188.319V36H169.167V6.264H188.319V12.858H177.441ZM204.694 36L198.688 25.038H197.848V36H189.574V6.264H202.636C205.016 6.264 207.032 6.684 208.684 7.524C210.364 8.336 211.624 9.47 212.464 10.926C213.304 12.382 213.724 14.02 213.724 15.84C213.724 17.912 213.15 19.718 212.002 21.258C210.854 22.77 209.202 23.834 207.046 24.45L213.808 36H204.694ZM197.848 19.494H201.922C204.218 19.494 205.366 18.458 205.366 16.386C205.366 15.406 205.072 14.636 204.484 14.076C203.924 13.516 203.07 13.236 201.922 13.236H197.848V19.494Z" fill="url(#paint1_linear)"/><path d="M75.22 53L73.69 50.33H73.3V53H71.59V45.93H74.51C75.07 45.93 75.5433 46.0267 75.93 46.22C76.3167 46.4133 76.6067 46.68 76.8 47.02C76.9933 47.3533 77.09 47.7367 77.09 48.17C77.09 48.6833 76.9467 49.12 76.66 49.48C76.38 49.84 75.97 50.0867 75.43 50.22L77.11 53H75.22ZM73.3 49.16H74.36C74.7 49.16 74.95 49.0867 75.11 48.94C75.27 48.7867 75.35 48.5633 75.35 48.27C75.35 47.99 75.2667 47.77 75.1 47.61C74.94 47.45 74.6933 47.37 74.36 47.37H73.3V49.16ZM82.1574 47.29V48.77H84.5474V50.06H82.1574V51.63H84.8474V53H80.4474V45.93H84.8474V47.29H82.1574ZM91.5485 45.86C92.4485 45.86 93.1918 46.0967 93.7785 46.57C94.3718 47.0433 94.7552 47.6833 94.9285 48.49H93.1185C92.9852 48.1633 92.7785 47.9067 92.4985 47.72C92.2252 47.5333 91.8985 47.44 91.5185 47.44C91.0185 47.44 90.6152 47.6233 90.3085 47.99C90.0018 48.3567 89.8485 48.8467 89.8485 49.46C89.8485 50.0733 90.0018 50.5633 90.3085 50.93C90.6152 51.29 91.0185 51.47 91.5185 51.47C91.8985 51.47 92.2252 51.3767 92.4985 51.19C92.7785 51.0033 92.9852 50.75 93.1185 50.43H94.9285C94.7552 51.23 94.3718 51.87 93.7785 52.35C93.1918 52.8233 92.4485 53.06 91.5485 53.06C90.8618 53.06 90.2585 52.91 89.7385 52.61C89.2185 52.3033 88.8152 51.8767 88.5285 51.33C88.2485 50.7833 88.1085 50.16 88.1085 49.46C88.1085 48.76 88.2485 48.1367 88.5285 47.59C88.8152 47.0433 89.2185 46.62 89.7385 46.32C90.2585 46.0133 90.8618 45.86 91.5485 45.86ZM101.747 45.82C102.414 45.82 103.017 45.9767 103.557 46.29C104.104 46.5967 104.534 47.0267 104.847 47.58C105.16 48.1267 105.317 48.7467 105.317 49.44C105.317 50.1333 105.157 50.7567 104.837 51.31C104.524 51.8633 104.094 52.2967 103.547 52.61C103.007 52.9167 102.407 53.07 101.747 53.07C101.087 53.07 100.484 52.9167 99.9369 52.61C99.3969 52.2967 98.9669 51.8633 98.6469 51.31C98.3335 50.7567 98.1769 50.1333 98.1769 49.44C98.1769 48.7467 98.3335 48.1267 98.6469 47.58C98.9669 47.0267 99.3969 46.5967 99.9369 46.29C100.484 45.9767 101.087 45.82 101.747 45.82ZM101.747 47.41C101.187 47.41 100.74 47.5933 100.407 47.96C100.08 48.32 99.9169 48.8133 99.9169 49.44C99.9169 50.06 100.08 50.5533 100.407 50.92C100.74 51.2867 101.187 51.47 101.747 51.47C102.3 51.47 102.744 51.2867 103.077 50.92C103.41 50.5533 103.577 50.06 103.577 49.44C103.577 48.82 103.41 48.3267 103.077 47.96C102.75 47.5933 102.307 47.41 101.747 47.41ZM112.408 53L110.878 50.33H110.488V53H108.778V45.93H111.698C112.258 45.93 112.731 46.0267 113.118 46.22C113.504 46.4133 113.794 46.68 113.988 47.02C114.181 47.3533 114.278 47.7367 114.278 48.17C114.278 48.6833 114.134 49.12 113.848 49.48C113.568 49.84 113.158 50.0867 112.618 50.22L114.298 53H112.408ZM110.488 49.16H111.548C111.888 49.16 112.138 49.0867 112.298 48.94C112.458 48.7867 112.538 48.5633 112.538 48.27C112.538 47.99 112.454 47.77 112.288 47.61C112.128 47.45 111.881 47.37 111.548 47.37H110.488V49.16ZM123.995 49.45C123.995 50.1433 123.845 50.76 123.545 51.3C123.252 51.8333 122.825 52.25 122.265 52.55C121.712 52.85 121.058 53 120.305 53H117.635V45.93H120.305C121.065 45.93 121.722 46.0767 122.275 46.37C122.828 46.6633 123.252 47.0767 123.545 47.61C123.845 48.1433 123.995 48.7567 123.995 49.45ZM120.155 51.47C120.822 51.47 121.338 51.2933 121.705 50.94C122.078 50.5867 122.265 50.09 122.265 49.45C122.265 48.81 122.078 48.3133 121.705 47.96C121.338 47.6067 120.822 47.43 120.155 47.43H119.345V51.47H120.155ZM129.179 45.93V53H127.469V45.93H129.179ZM139.14 53H137.43L134.57 48.66V53H132.86V45.93H134.57L137.43 50.31V45.93H139.14V53ZM146.13 45.86C147.017 45.86 147.747 46.0767 148.32 46.51C148.894 46.9433 149.25 47.53 149.39 48.27H147.58C147.46 48.0167 147.277 47.8167 147.03 47.67C146.784 47.5167 146.487 47.44 146.14 47.44C145.6 47.44 145.167 47.6233 144.84 47.99C144.514 48.35 144.35 48.84 144.35 49.46C144.35 50.1333 144.52 50.65 144.86 51.01C145.207 51.37 145.697 51.55 146.33 51.55C146.737 51.55 147.094 51.44 147.4 51.22C147.707 50.9933 147.924 50.6733 148.05 50.26H145.89V49.03H149.48V50.72C149.347 51.1333 149.134 51.5167 148.84 51.87C148.547 52.2233 148.17 52.51 147.71 52.73C147.257 52.95 146.737 53.06 146.15 53.06C145.437 53.06 144.814 52.91 144.28 52.61C143.747 52.3033 143.334 51.8767 143.04 51.33C142.754 50.7833 142.61 50.16 142.61 49.46C142.61 48.76 142.754 48.1367 143.04 47.59C143.334 47.0433 143.744 46.62 144.27 46.32C144.804 46.0133 145.424 45.86 146.13 45.86ZM162.52 51.01C162.52 51.3833 162.423 51.7267 162.23 52.04C162.043 52.3533 161.763 52.6033 161.39 52.79C161.023 52.9767 160.576 53.07 160.05 53.07C159.256 53.07 158.603 52.8767 158.09 52.49C157.576 52.1033 157.296 51.5633 157.25 50.87H159.07C159.096 51.1367 159.19 51.3467 159.35 51.5C159.516 51.6533 159.726 51.73 159.98 51.73C160.2 51.73 160.373 51.67 160.5 51.55C160.626 51.43 160.69 51.27 160.69 51.07C160.69 50.89 160.63 50.74 160.51 50.62C160.396 50.5 160.253 50.4033 160.08 50.33C159.906 50.25 159.666 50.1567 159.36 50.05C158.913 49.8967 158.546 49.75 158.26 49.61C157.98 49.4633 157.736 49.25 157.53 48.97C157.33 48.6833 157.23 48.3133 157.23 47.86C157.23 47.44 157.336 47.0767 157.55 46.77C157.763 46.4633 158.056 46.23 158.43 46.07C158.81 45.9033 159.243 45.82 159.73 45.82C160.516 45.82 161.14 46.0067 161.6 46.38C162.066 46.7533 162.33 47.2667 162.39 47.92H160.54C160.506 47.6867 160.42 47.5033 160.28 47.37C160.146 47.23 159.963 47.16 159.73 47.16C159.53 47.16 159.366 47.2133 159.24 47.32C159.12 47.4267 159.06 47.5833 159.06 47.79C159.06 47.9567 159.113 48.1 159.22 48.22C159.333 48.3333 159.473 48.4267 159.64 48.5C159.806 48.5733 160.046 48.6667 160.36 48.78C160.813 48.9333 161.183 49.0867 161.47 49.24C161.756 49.3867 162.003 49.6033 162.21 49.89C162.416 50.1767 162.52 50.55 162.52 51.01ZM171.045 45.93V47.29H169.125V53H167.405V47.29H165.505V45.93H171.045ZM175.926 45.93V50.01C175.926 50.4767 176.029 50.8333 176.236 51.08C176.449 51.3267 176.756 51.45 177.156 51.45C177.556 51.45 177.859 51.3267 178.066 51.08C178.279 50.8333 178.386 50.4767 178.386 50.01V45.93H180.096V50.01C180.096 50.6767 179.966 51.24 179.706 51.7C179.446 52.1533 179.089 52.4967 178.636 52.73C178.189 52.9567 177.682 53.07 177.116 53.07C176.549 53.07 176.049 52.9567 175.616 52.73C175.182 52.5033 174.842 52.16 174.596 51.7C174.349 51.24 174.226 50.6767 174.226 50.01V45.93H175.926ZM190.098 49.45C190.098 50.1433 189.948 50.76 189.648 51.3C189.355 51.8333 188.928 52.25 188.368 52.55C187.815 52.85 187.162 53 186.408 53H183.738V45.93H186.408C187.168 45.93 187.825 46.0767 188.378 46.37C188.932 46.6633 189.355 47.0767 189.648 47.61C189.948 48.1433 190.098 48.7567 190.098 49.45ZM186.258 51.47C186.925 51.47 187.442 51.2933 187.808 50.94C188.182 50.5867 188.368 50.09 188.368 49.45C188.368 48.81 188.182 48.3133 187.808 47.96C187.442 47.6067 186.925 47.43 186.258 47.43H185.448V51.47H186.258ZM195.282 45.93V53H193.572V45.93H195.282ZM202.323 45.82C202.99 45.82 203.593 45.9767 204.133 46.29C204.68 46.5967 205.11 47.0267 205.423 47.58C205.736 48.1267 205.893 48.7467 205.893 49.44C205.893 50.1333 205.733 50.7567 205.413 51.31C205.1 51.8633 204.67 52.2967 204.123 52.61C203.583 52.9167 202.983 53.07 202.323 53.07C201.663 53.07 201.06 52.9167 200.513 52.61C199.973 52.2967 199.543 51.8633 199.223 51.31C198.91 50.7567 198.753 50.1333 198.753 49.44C198.753 48.7467 198.91 48.1267 199.223 47.58C199.543 47.0267 199.973 46.5967 200.513 46.29C201.06 45.9767 201.663 45.82 202.323 45.82ZM202.323 47.41C201.763 47.41 201.316 47.5933 200.983 47.96C200.656 48.32 200.493 48.8133 200.493 49.44C200.493 50.06 200.656 50.5533 200.983 50.92C201.316 51.2867 201.763 51.47 202.323 51.47C202.876 51.47 203.32 51.2867 203.653 50.92C203.986 50.5533 204.153 50.06 204.153 49.44C204.153 48.82 203.986 48.3267 203.653 47.96C203.326 47.5933 202.883 47.41 202.323 47.41Z" fill="white"/><defs><linearGradient id="paint0_linear" x1="57.1273" y1="28.8015" x2="0.997337" y2="28.8015" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint1_linear" x1="163" y1="2" x2="163" y2="45" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="white"/><stop offset="1" stop-color="white" stop-opacity="0"/></linearGradient></defs></svg>
    </a>';
    echo $logo_svg;
}


function voicer_logo_svg () {
    $custom_logo_id = get_theme_mod('custom_logo');
    $image = wp_get_attachment_image_src( $custom_logo_id , 'full' );

    if ($image[0] == '') {
        $logo_svg = '<a class="header-logo" href="'.esc_url( home_url( '/' ) ).'" rel="home">
        <svg class="icon ch-icon-logo" width="258" height="59" viewBox="0 0 258 59" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M33.4942 54C31.9671 53.3232 31.5079 52.1387 31.5399 50.5206C31.6253 46.248 31.5933 41.9754 31.5719 37.7028C31.5613 35.8203 30.5467 34.7627 28.9021 34.7945C27.3536 34.8262 26.4459 35.8732 26.3818 37.7028C26.3712 38.1152 26.3818 38.5277 26.3818 38.9402C26.3818 42.8003 26.4032 46.6604 26.3925 50.5206C26.3818 52.5511 25.41 53.7145 23.7975 53.651C22.281 53.5981 21.3412 52.4136 21.3412 50.5206C21.3412 45.476 21.3626 40.4313 21.3626 35.3867C21.3626 34.8791 21.3946 34.3397 21.2665 33.8532C20.9034 32.5418 19.9743 31.8861 18.5967 31.9707C17.2831 32.0554 16.4608 32.7745 16.29 34.0542C16.1618 35.0166 16.2473 36.0107 16.1939 36.9836C16.0977 38.6229 15.0085 39.7439 13.5988 39.7016C12.2425 39.6593 11.2387 38.5594 11.1746 36.9836C11.1319 36.1059 11.196 35.2387 11.1639 34.3609C11.0999 32.6899 10.1067 31.6006 8.67569 31.5689C7.10584 31.5371 6.102 32.5736 6.01656 34.3397C6.00588 34.5935 6.02724 34.8579 5.98452 35.1117C5.76026 36.4549 4.69234 37.3432 3.38947 37.2903C2.07593 37.2375 1.06141 36.2962 1.04005 34.9002C0.986651 31.9707 0.986651 29.0307 1.04005 26.1012C1.06141 24.6841 2.20408 23.6265 3.49627 23.6265C4.74574 23.6265 5.80298 24.5995 5.98452 25.9532C6.02724 26.3127 5.98453 26.6723 6.01656 27.0319C6.14471 28.4385 7.19128 29.3903 8.60093 29.3797C9.98923 29.3691 11.0892 28.4067 11.1426 27.0002C11.2173 25.308 11.1639 23.6053 11.1853 21.9027C11.2067 20.1365 12.2212 18.9309 13.6415 18.9097C15.1153 18.8886 16.1084 20.0202 16.1832 21.8075C16.2045 22.368 16.1832 22.9391 16.1939 23.5102C16.2259 25.5196 17.1763 26.6829 18.7782 26.6935C20.3908 26.704 21.384 25.5196 21.384 23.5419C21.3946 20.5067 21.3626 17.4714 21.4053 14.4362C21.4267 12.522 22.8684 11.2952 24.5023 11.7711C25.8265 12.1624 26.3818 13.1248 26.3712 14.4573C26.3605 16.9744 26.3605 19.502 26.3712 22.019C26.3818 24.2293 27.3536 25.4878 29.0196 25.4667C30.6642 25.4455 31.5719 24.2716 31.5719 22.093C31.5826 15.9697 31.5826 9.84632 31.5826 3.72297C31.5826 3.36339 31.5719 3.00382 31.5826 2.64424C31.668 1.03673 32.6185 0.0214629 34.0281 0.000311481C35.5232 -0.02084 36.5271 1.03673 36.5271 2.71827C36.5484 7.96384 36.5484 13.22 36.5591 18.4655C36.5591 18.7194 36.5378 18.9838 36.5591 19.2376C36.6873 20.6759 37.6804 21.6488 39.0687 21.6806C40.5318 21.7229 41.6424 20.7499 41.7065 19.227C41.7919 16.9109 41.7492 14.5948 41.7813 12.2787C41.8133 10.3963 42.8278 9.22235 44.3549 9.26465C45.818 9.30695 46.7685 10.4597 46.7791 12.2787C46.8005 15.6207 46.7791 18.9732 46.8112 22.3151C46.8325 24.2399 47.783 25.308 49.3849 25.2975C50.9867 25.2869 51.8838 24.2082 51.9265 22.2728C51.9372 21.9132 51.9158 21.5537 51.9586 21.1941C52.1401 19.7346 53.176 18.7722 54.5216 18.804C55.8992 18.8357 56.9137 19.7981 56.9458 21.2998C57.0098 24.0284 56.9885 26.7569 56.9885 29.4855C56.9885 30.9766 57.0205 32.4678 56.9778 33.959C56.9351 35.6723 55.9739 36.7087 54.4895 36.7193C52.9304 36.7404 51.9479 35.6617 51.9052 33.8744C51.8838 33.0495 51.9372 32.2246 51.8945 31.4102C51.8197 29.8344 50.8372 28.8826 49.3421 28.8932C47.8471 28.9038 46.8432 29.845 46.8325 31.442C46.8005 35.1963 46.8325 38.9507 46.8325 42.7157C46.8325 43.181 46.8539 43.6464 46.7791 44.1011C46.5442 45.4231 45.4229 46.3537 44.152 46.2586C42.7851 46.1528 41.8881 45.3808 41.7813 44.0271C41.6531 42.4407 41.7279 40.8438 41.7172 39.2469C41.7065 37.1846 40.8201 36.0741 39.1755 36.0636C37.4989 36.053 36.5805 37.1423 36.5805 39.194C36.5698 42.9484 36.5271 46.7133 36.6232 50.4677C36.6659 52.0858 36.1853 53.2597 34.7116 54C34.3272 54 33.9107 54 33.4942 54Z" fill="url(#paint0_linear1)"/><path d="M76.946 6.264L83.666 27.684L90.344 6.264H99.122L88.958 36H78.332L68.168 6.264H76.946ZM113.365 5.802C116.165 5.802 118.713 6.46 121.009 7.776C123.333 9.064 125.153 10.87 126.469 13.194C127.813 15.518 128.485 18.136 128.485 21.048C128.485 23.96 127.813 26.578 126.469 28.902C125.125 31.226 123.291 33.046 120.967 34.362C118.671 35.65 116.137 36.294 113.365 36.294C110.593 36.294 108.045 35.65 105.721 34.362C103.397 33.046 101.563 31.226 100.219 28.902C98.8749 26.578 98.2029 23.96 98.2029 21.048C98.2029 18.136 98.8749 15.518 100.219 13.194C101.563 10.87 103.397 9.064 105.721 7.776C108.045 6.46 110.593 5.802 113.365 5.802ZM113.365 13.446C111.265 13.446 109.613 14.132 108.409 15.504C107.205 16.848 106.603 18.696 106.603 21.048C106.603 23.344 107.205 25.178 108.409 26.55C109.613 27.922 111.265 28.608 113.365 28.608C115.437 28.608 117.075 27.922 118.279 26.55C119.483 25.178 120.085 23.344 120.085 21.048C120.085 18.696 119.483 16.848 118.279 15.504C117.103 14.132 115.465 13.446 113.365 13.446ZM137.938 6.264V36H129.664V6.264H137.938ZM153.715 5.97C156.263 5.97 158.531 6.446 160.519 7.398C162.535 8.322 164.173 9.652 165.433 11.388C166.693 13.096 167.547 15.084 167.995 17.352H159.301C158.825 16.176 158.083 15.266 157.075 14.622C156.067 13.95 154.905 13.614 153.589 13.614C151.769 13.614 150.299 14.3 149.179 15.672C148.059 17.016 147.499 18.822 147.499 21.09C147.499 23.358 148.059 25.178 149.179 26.55C150.299 27.922 151.769 28.608 153.589 28.608C154.905 28.608 156.067 28.272 157.075 27.6C158.083 26.928 158.825 26.004 159.301 24.828H167.995C167.323 28.3 165.727 31.072 163.207 33.144C160.715 35.188 157.551 36.21 153.715 36.21C150.775 36.21 148.199 35.58 145.987 34.32C143.803 33.032 142.109 31.24 140.905 28.944C139.729 26.648 139.141 24.03 139.141 21.09C139.141 18.15 139.729 15.532 140.905 13.236C142.109 10.94 143.803 9.162 145.987 7.902C148.199 6.614 150.775 5.97 153.715 5.97ZM177.441 12.858V17.772H187.059V24.03H177.441V29.406H188.319V36H169.167V6.264H188.319V12.858H177.441ZM204.694 36L198.688 25.038H197.848V36H189.574V6.264H202.636C205.016 6.264 207.032 6.684 208.684 7.524C210.364 8.336 211.624 9.47 212.464 10.926C213.304 12.382 213.724 14.02 213.724 15.84C213.724 17.912 213.15 19.718 212.002 21.258C210.854 22.77 209.202 23.834 207.046 24.45L213.808 36H204.694ZM197.848 19.494H201.922C204.218 19.494 205.366 18.458 205.366 16.386C205.366 15.406 205.072 14.636 204.484 14.076C203.924 13.516 203.07 13.236 201.922 13.236H197.848V19.494Z" fill="#CECECE"/><path d="M76.946 6.264L83.666 27.684L90.344 6.264H99.122L88.958 36H78.332L68.168 6.264H76.946ZM113.365 5.802C116.165 5.802 118.713 6.46 121.009 7.776C123.333 9.064 125.153 10.87 126.469 13.194C127.813 15.518 128.485 18.136 128.485 21.048C128.485 23.96 127.813 26.578 126.469 28.902C125.125 31.226 123.291 33.046 120.967 34.362C118.671 35.65 116.137 36.294 113.365 36.294C110.593 36.294 108.045 35.65 105.721 34.362C103.397 33.046 101.563 31.226 100.219 28.902C98.8749 26.578 98.2029 23.96 98.2029 21.048C98.2029 18.136 98.8749 15.518 100.219 13.194C101.563 10.87 103.397 9.064 105.721 7.776C108.045 6.46 110.593 5.802 113.365 5.802ZM113.365 13.446C111.265 13.446 109.613 14.132 108.409 15.504C107.205 16.848 106.603 18.696 106.603 21.048C106.603 23.344 107.205 25.178 108.409 26.55C109.613 27.922 111.265 28.608 113.365 28.608C115.437 28.608 117.075 27.922 118.279 26.55C119.483 25.178 120.085 23.344 120.085 21.048C120.085 18.696 119.483 16.848 118.279 15.504C117.103 14.132 115.465 13.446 113.365 13.446ZM137.938 6.264V36H129.664V6.264H137.938ZM153.715 5.97C156.263 5.97 158.531 6.446 160.519 7.398C162.535 8.322 164.173 9.652 165.433 11.388C166.693 13.096 167.547 15.084 167.995 17.352H159.301C158.825 16.176 158.083 15.266 157.075 14.622C156.067 13.95 154.905 13.614 153.589 13.614C151.769 13.614 150.299 14.3 149.179 15.672C148.059 17.016 147.499 18.822 147.499 21.09C147.499 23.358 148.059 25.178 149.179 26.55C150.299 27.922 151.769 28.608 153.589 28.608C154.905 28.608 156.067 28.272 157.075 27.6C158.083 26.928 158.825 26.004 159.301 24.828H167.995C167.323 28.3 165.727 31.072 163.207 33.144C160.715 35.188 157.551 36.21 153.715 36.21C150.775 36.21 148.199 35.58 145.987 34.32C143.803 33.032 142.109 31.24 140.905 28.944C139.729 26.648 139.141 24.03 139.141 21.09C139.141 18.15 139.729 15.532 140.905 13.236C142.109 10.94 143.803 9.162 145.987 7.902C148.199 6.614 150.775 5.97 153.715 5.97ZM177.441 12.858V17.772H187.059V24.03H177.441V29.406H188.319V36H169.167V6.264H188.319V12.858H177.441ZM204.694 36L198.688 25.038H197.848V36H189.574V6.264H202.636C205.016 6.264 207.032 6.684 208.684 7.524C210.364 8.336 211.624 9.47 212.464 10.926C213.304 12.382 213.724 14.02 213.724 15.84C213.724 17.912 213.15 19.718 212.002 21.258C210.854 22.77 209.202 23.834 207.046 24.45L213.808 36H204.694ZM197.848 19.494H201.922C204.218 19.494 205.366 18.458 205.366 16.386C205.366 15.406 205.072 14.636 204.484 14.076C203.924 13.516 203.07 13.236 201.922 13.236H197.848V19.494Z" fill="url(#paint1_linear1)"/><path d="M75.22 53L73.69 50.33H73.3V53H71.59V45.93H74.51C75.07 45.93 75.5433 46.0267 75.93 46.22C76.3167 46.4133 76.6067 46.68 76.8 47.02C76.9933 47.3533 77.09 47.7367 77.09 48.17C77.09 48.6833 76.9467 49.12 76.66 49.48C76.38 49.84 75.97 50.0867 75.43 50.22L77.11 53H75.22ZM73.3 49.16H74.36C74.7 49.16 74.95 49.0867 75.11 48.94C75.27 48.7867 75.35 48.5633 75.35 48.27C75.35 47.99 75.2667 47.77 75.1 47.61C74.94 47.45 74.6933 47.37 74.36 47.37H73.3V49.16ZM82.1574 47.29V48.77H84.5474V50.06H82.1574V51.63H84.8474V53H80.4474V45.93H84.8474V47.29H82.1574ZM91.5485 45.86C92.4485 45.86 93.1918 46.0967 93.7785 46.57C94.3718 47.0433 94.7552 47.6833 94.9285 48.49H93.1185C92.9852 48.1633 92.7785 47.9067 92.4985 47.72C92.2252 47.5333 91.8985 47.44 91.5185 47.44C91.0185 47.44 90.6152 47.6233 90.3085 47.99C90.0018 48.3567 89.8485 48.8467 89.8485 49.46C89.8485 50.0733 90.0018 50.5633 90.3085 50.93C90.6152 51.29 91.0185 51.47 91.5185 51.47C91.8985 51.47 92.2252 51.3767 92.4985 51.19C92.7785 51.0033 92.9852 50.75 93.1185 50.43H94.9285C94.7552 51.23 94.3718 51.87 93.7785 52.35C93.1918 52.8233 92.4485 53.06 91.5485 53.06C90.8618 53.06 90.2585 52.91 89.7385 52.61C89.2185 52.3033 88.8152 51.8767 88.5285 51.33C88.2485 50.7833 88.1085 50.16 88.1085 49.46C88.1085 48.76 88.2485 48.1367 88.5285 47.59C88.8152 47.0433 89.2185 46.62 89.7385 46.32C90.2585 46.0133 90.8618 45.86 91.5485 45.86ZM101.747 45.82C102.414 45.82 103.017 45.9767 103.557 46.29C104.104 46.5967 104.534 47.0267 104.847 47.58C105.16 48.1267 105.317 48.7467 105.317 49.44C105.317 50.1333 105.157 50.7567 104.837 51.31C104.524 51.8633 104.094 52.2967 103.547 52.61C103.007 52.9167 102.407 53.07 101.747 53.07C101.087 53.07 100.484 52.9167 99.9369 52.61C99.3969 52.2967 98.9669 51.8633 98.6469 51.31C98.3335 50.7567 98.1769 50.1333 98.1769 49.44C98.1769 48.7467 98.3335 48.1267 98.6469 47.58C98.9669 47.0267 99.3969 46.5967 99.9369 46.29C100.484 45.9767 101.087 45.82 101.747 45.82ZM101.747 47.41C101.187 47.41 100.74 47.5933 100.407 47.96C100.08 48.32 99.9169 48.8133 99.9169 49.44C99.9169 50.06 100.08 50.5533 100.407 50.92C100.74 51.2867 101.187 51.47 101.747 51.47C102.3 51.47 102.744 51.2867 103.077 50.92C103.41 50.5533 103.577 50.06 103.577 49.44C103.577 48.82 103.41 48.3267 103.077 47.96C102.75 47.5933 102.307 47.41 101.747 47.41ZM112.408 53L110.878 50.33H110.488V53H108.778V45.93H111.698C112.258 45.93 112.731 46.0267 113.118 46.22C113.504 46.4133 113.794 46.68 113.988 47.02C114.181 47.3533 114.278 47.7367 114.278 48.17C114.278 48.6833 114.134 49.12 113.848 49.48C113.568 49.84 113.158 50.0867 112.618 50.22L114.298 53H112.408ZM110.488 49.16H111.548C111.888 49.16 112.138 49.0867 112.298 48.94C112.458 48.7867 112.538 48.5633 112.538 48.27C112.538 47.99 112.454 47.77 112.288 47.61C112.128 47.45 111.881 47.37 111.548 47.37H110.488V49.16ZM123.995 49.45C123.995 50.1433 123.845 50.76 123.545 51.3C123.252 51.8333 122.825 52.25 122.265 52.55C121.712 52.85 121.058 53 120.305 53H117.635V45.93H120.305C121.065 45.93 121.722 46.0767 122.275 46.37C122.828 46.6633 123.252 47.0767 123.545 47.61C123.845 48.1433 123.995 48.7567 123.995 49.45ZM120.155 51.47C120.822 51.47 121.338 51.2933 121.705 50.94C122.078 50.5867 122.265 50.09 122.265 49.45C122.265 48.81 122.078 48.3133 121.705 47.96C121.338 47.6067 120.822 47.43 120.155 47.43H119.345V51.47H120.155ZM129.179 45.93V53H127.469V45.93H129.179ZM139.14 53H137.43L134.57 48.66V53H132.86V45.93H134.57L137.43 50.31V45.93H139.14V53ZM146.13 45.86C147.017 45.86 147.747 46.0767 148.32 46.51C148.894 46.9433 149.25 47.53 149.39 48.27H147.58C147.46 48.0167 147.277 47.8167 147.03 47.67C146.784 47.5167 146.487 47.44 146.14 47.44C145.6 47.44 145.167 47.6233 144.84 47.99C144.514 48.35 144.35 48.84 144.35 49.46C144.35 50.1333 144.52 50.65 144.86 51.01C145.207 51.37 145.697 51.55 146.33 51.55C146.737 51.55 147.094 51.44 147.4 51.22C147.707 50.9933 147.924 50.6733 148.05 50.26H145.89V49.03H149.48V50.72C149.347 51.1333 149.134 51.5167 148.84 51.87C148.547 52.2233 148.17 52.51 147.71 52.73C147.257 52.95 146.737 53.06 146.15 53.06C145.437 53.06 144.814 52.91 144.28 52.61C143.747 52.3033 143.334 51.8767 143.04 51.33C142.754 50.7833 142.61 50.16 142.61 49.46C142.61 48.76 142.754 48.1367 143.04 47.59C143.334 47.0433 143.744 46.62 144.27 46.32C144.804 46.0133 145.424 45.86 146.13 45.86ZM162.52 51.01C162.52 51.3833 162.423 51.7267 162.23 52.04C162.043 52.3533 161.763 52.6033 161.39 52.79C161.023 52.9767 160.576 53.07 160.05 53.07C159.256 53.07 158.603 52.8767 158.09 52.49C157.576 52.1033 157.296 51.5633 157.25 50.87H159.07C159.096 51.1367 159.19 51.3467 159.35 51.5C159.516 51.6533 159.726 51.73 159.98 51.73C160.2 51.73 160.373 51.67 160.5 51.55C160.626 51.43 160.69 51.27 160.69 51.07C160.69 50.89 160.63 50.74 160.51 50.62C160.396 50.5 160.253 50.4033 160.08 50.33C159.906 50.25 159.666 50.1567 159.36 50.05C158.913 49.8967 158.546 49.75 158.26 49.61C157.98 49.4633 157.736 49.25 157.53 48.97C157.33 48.6833 157.23 48.3133 157.23 47.86C157.23 47.44 157.336 47.0767 157.55 46.77C157.763 46.4633 158.056 46.23 158.43 46.07C158.81 45.9033 159.243 45.82 159.73 45.82C160.516 45.82 161.14 46.0067 161.6 46.38C162.066 46.7533 162.33 47.2667 162.39 47.92H160.54C160.506 47.6867 160.42 47.5033 160.28 47.37C160.146 47.23 159.963 47.16 159.73 47.16C159.53 47.16 159.366 47.2133 159.24 47.32C159.12 47.4267 159.06 47.5833 159.06 47.79C159.06 47.9567 159.113 48.1 159.22 48.22C159.333 48.3333 159.473 48.4267 159.64 48.5C159.806 48.5733 160.046 48.6667 160.36 48.78C160.813 48.9333 161.183 49.0867 161.47 49.24C161.756 49.3867 162.003 49.6033 162.21 49.89C162.416 50.1767 162.52 50.55 162.52 51.01ZM171.045 45.93V47.29H169.125V53H167.405V47.29H165.505V45.93H171.045ZM175.926 45.93V50.01C175.926 50.4767 176.029 50.8333 176.236 51.08C176.449 51.3267 176.756 51.45 177.156 51.45C177.556 51.45 177.859 51.3267 178.066 51.08C178.279 50.8333 178.386 50.4767 178.386 50.01V45.93H180.096V50.01C180.096 50.6767 179.966 51.24 179.706 51.7C179.446 52.1533 179.089 52.4967 178.636 52.73C178.189 52.9567 177.682 53.07 177.116 53.07C176.549 53.07 176.049 52.9567 175.616 52.73C175.182 52.5033 174.842 52.16 174.596 51.7C174.349 51.24 174.226 50.6767 174.226 50.01V45.93H175.926ZM190.098 49.45C190.098 50.1433 189.948 50.76 189.648 51.3C189.355 51.8333 188.928 52.25 188.368 52.55C187.815 52.85 187.162 53 186.408 53H183.738V45.93H186.408C187.168 45.93 187.825 46.0767 188.378 46.37C188.932 46.6633 189.355 47.0767 189.648 47.61C189.948 48.1433 190.098 48.7567 190.098 49.45ZM186.258 51.47C186.925 51.47 187.442 51.2933 187.808 50.94C188.182 50.5867 188.368 50.09 188.368 49.45C188.368 48.81 188.182 48.3133 187.808 47.96C187.442 47.6067 186.925 47.43 186.258 47.43H185.448V51.47H186.258ZM195.282 45.93V53H193.572V45.93H195.282ZM202.323 45.82C202.99 45.82 203.593 45.9767 204.133 46.29C204.68 46.5967 205.11 47.0267 205.423 47.58C205.736 48.1267 205.893 48.7467 205.893 49.44C205.893 50.1333 205.733 50.7567 205.413 51.31C205.1 51.8633 204.67 52.2967 204.123 52.61C203.583 52.9167 202.983 53.07 202.323 53.07C201.663 53.07 201.06 52.9167 200.513 52.61C199.973 52.2967 199.543 51.8633 199.223 51.31C198.91 50.7567 198.753 50.1333 198.753 49.44C198.753 48.7467 198.91 48.1267 199.223 47.58C199.543 47.0267 199.973 46.5967 200.513 46.29C201.06 45.9767 201.663 45.82 202.323 45.82ZM202.323 47.41C201.763 47.41 201.316 47.5933 200.983 47.96C200.656 48.32 200.493 48.8133 200.493 49.44C200.493 50.06 200.656 50.5533 200.983 50.92C201.316 51.2867 201.763 51.47 202.323 51.47C202.876 51.47 203.32 51.2867 203.653 50.92C203.986 50.5533 204.153 50.06 204.153 49.44C204.153 48.82 203.986 48.3267 203.653 47.96C203.326 47.5933 202.883 47.41 202.323 47.41Z" fill="white"/><defs><linearGradient id="paint0_linear1" x1="57.1273" y1="28.8015" x2="0.997337" y2="28.8015" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#FF6600"/><stop offset="1" stop-color="#7B16D9"/></linearGradient><linearGradient id="paint1_linear1" x1="163" y1="2" x2="163" y2="45" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="white"/><stop offset="1" stop-color="white" stop-opacity="0"/></linearGradient></defs></svg>
        </a>';

        if ( is_front_page() ) :
            echo '<h1 class="p-0"><span>&nbsp;</span>'.$logo_svg.'</h1>';
        else :
            echo $logo_svg;
        endif;

    } else {
        return the_custom_logo();
    }

}

