<?php
add_action( 'vc_before_init', 'voicer_pre_init' );
function voicer_pre_init() {
    if( function_exists('vc_set_shortcodes_templates_dir') ){
        vc_set_shortcodes_templates_dir( plugin_dir_path( __FILE__ ).'vc_elements' );
    }
}
add_action( 'vc_after_init', 'voicer_post_init' );
function voicer_post_init() {
    $voicer_vc_column_new_params = array(
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Clean Classes Box', 'voicer-layout' ),
            'param_name' => 'rsclass',
            'description' => esc_html__( 'Write "clean" to remove all default classes', 'voicer-layout' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Voicer Settings','voicer-layout')
        ),
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Add Inner Block', 'voicer-layout' ),
            'param_name' => 'rsinner',
            'description' => esc_html__( 'Write some css style if you want to add innver block. If you left the field empty Inner Block will not be added', 'voicer-layout' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 0,
            'group' => esc_html__('Voicer Settings','voicer-layout')
        ),
    );
    $voicer_vc_row_new_params = array(
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Clean Classes Box', 'voicer-layout' ),
            'param_name' => 'rsclass',
            'description' => esc_html__( 'Write "clean" to remove all default classes', 'voicer-layout' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Voicer Settings','voicer-layout')
        ),
    );
    $voicer_vc_column_inner_new_params = array(
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Clean Classes Box', 'voicer-layout' ),
            'param_name' => 'rsclass',
            'description' => esc_html__( 'Write "clean" to remove all default classes', 'voicer-layout' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 2,
            'group' => esc_html__('Voicer Settings','voicer-layout')
        ),
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Add Inner Block', 'voicer-layout' ),
            'param_name' => 'rsinner',
            'description' => esc_html__( 'Write some css style if you want to add inner block. If you left the field empty Inner Block will not be added', 'voicer-layout' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Voicer Settings','voicer-layout')
        ),
    );
    $voicer_vc_row_inner_new_params = array(
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Clean Classes Box', 'voicer-layout' ),
            'param_name' => 'rsclass',
            'description' => esc_html__( 'Write "clean" to remove all default classes', 'voicer-layout' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Voicer Settings','voicer-layout')
        ),
    );
    $voicer_vc_column_text = array(
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Clean Classes Box', 'voicer-layout' ),
            'param_name' => 'rsclass',
            'description' => esc_html__( 'Write "clean" to remove all default classes', 'voicer-layout' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Voicer Settings','voicer-layout')
        ),
    );
    $voicer_vc_section_params = array(
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Clean Classes Box', 'voicer-layout' ),
            'param_name' => 'rsclass',
            'description' => esc_html__( 'Write "clean" to remove all default classes', 'voicer-layout' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Voicer Settings','voicer-layout')
        ),
    );
    $voicer_vc_single_image_params = array(
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Clean Classes Box', 'voicer-layout' ),
            'param_name' => 'rsclass',
            'description' => esc_html__( 'Write "clean" to remove all default classes', 'voicer-layout' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Voicer Settings','voicer-layout')
        ),
    );
    $voicer_vc_hoverbox_params = array(
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Clean Classes Box', 'voicer-layout' ),
            'param_name' => 'rsclass',
            'description' => esc_html__( 'Write "clean" to remove some Hover Box default functionality: tab General - block width, block alignment, Reverse blocks, CSS Animation, tab Hover Block - Hover title, Hover title alignment, Background Color, Use custom font, Add button, all tab Design Options.', 'voicer-layout' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Voicer Settings','voicer-layout')
        ),
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Extra class name for Image Wrapper', 'voicer-layout' ),
            'param_name' => 'rsiclass',
            'description' => esc_html__( 'Extra class name for Outer Image Wrapper', 'voicer-layout' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => '',
            'group' => '',
        ),
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Extra class name for Text Wrapper', 'voicer-layout' ),
            'param_name' => 'rstclass',
            'description' => esc_html__( 'Extra class name for Outer Text Wrapper', 'voicer-layout' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => '',
            'group' => '',
        ),
    );
    $voicer_vc_custom_heading_params = array(
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Add Outer Wrapper Block', 'voicer-layout' ),
            'param_name' => 'rsouter',
            'description' => esc_html__( 'Write some css style if you want to add outer wrapper block. If you left the field empty Outer Block will not be added', 'voicer-layout' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 0,
            'group' => '',
        ),
    );
    vc_add_params( 'vc_column', $voicer_vc_column_new_params );
    vc_add_params( 'vc_row', $voicer_vc_row_new_params );
    vc_add_params( 'vc_column_inner', $voicer_vc_column_inner_new_params );
    vc_add_params( 'vc_row_inner', $voicer_vc_row_inner_new_params );
    vc_add_params( 'vc_column_text', $voicer_vc_column_text );
    vc_add_params( 'vc_section', $voicer_vc_section_params );
    vc_add_params( 'vc_single_image', $voicer_vc_single_image_params );
    vc_add_params( 'vc_custom_heading', $voicer_vc_custom_heading_params );
    vc_add_params( 'vc_hoverbox', $voicer_vc_hoverbox_params );
}