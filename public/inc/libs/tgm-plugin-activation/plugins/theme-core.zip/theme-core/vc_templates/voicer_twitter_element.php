<?php
if ( ! defined( 'ABSPATH' ) ) {
    die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $twitter_account
 * @var $limit
 * @var $el_id
 * @var $el_class
 */

$attributes = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $attributes );
$twitter_account = ($twitter_account != '' ? $twitter_account : 'envato');
$limit = ($limit != '' ? $limit : 1);

echo '<div class="'.$el_class.'">';
echo '<a class="twitter-timeline" id="'.$el_id.'" href="https://twitter.com/'.$twitter_account.'" data-chrome="nofooter noborders noheader noscrollbar" data-tweet-limit="'.$limit.'">Tweets by @'.$twitter_account.'</a>';
echo '</div>';
?>
<div>
    <script type="text/javascript">
        ! function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0],
                p = /^http:/.test(d.location) ? 'http' : 'https';
            if (!d.getElementById(id)) {
                js = d.createElement(s);
                js.id = id;
                js.src = p + "://platform.twitter.com/widgets.js";
                fjs.parentNode.insertBefore(js, fjs);
            }
        }(document, "script", "twitter-wjs");
    </script>
</div>
