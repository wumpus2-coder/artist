<?php
if ( ! defined( 'ABSPATH' ) ) {
    die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $access_token
 * @var $limit
 * @var $resolution
 * @var $sort_by
 * @var $user_id
 * @var $content
 * @var $el_id
 * @var $el_class
 */

$attributes = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $attributes );

$access_token = ($access_token != '' ? $access_token : '3483630941.1677ed0.66c4618b32444ac08a70cb2fe84c1bf8');
$limit = ($limit != '' ? $limit : 9);
$resolution = ($resolution != '' ? $resolution : 'low_resolution');
$sort_by = ($sort_by != '' ? $sort_by : 'most-recent');
$user_id = ($user_id != '' ? $user_id : 'self');


$ins_object = array(
    'accessToken' => esc_js($access_token),
    'limit' => esc_js($limit),
    'resolution' => esc_js($resolution),
    'sort_by' => esc_js($sort_by),
    'user_id' => esc_js($user_id),
    'el_id' => esc_js($el_id)
);



wp_enqueue_script('rtext_element_inst');
wp_localize_script('rtext_element_inst', 'el_id', $el_id);

wp_enqueue_script('voicer_gallery_element_scr');
wp_localize_script('voicer_gallery_element_scr', 'insObject', $ins_object);

echo '<div id="'.$el_id.'" class="'.$el_class.'"></div>';