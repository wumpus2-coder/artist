<?php
if ( ! defined( 'ABSPATH' ) ) {
    die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $title
 * @var $source
 * @var $type
 * @var $onclick
 * @var $custom_links
 * @var $custom_links_target
 * @var $img_size
 * @var $external_img_size
 * @var $images
 * @var $custom_srcs
 * @var $el_class
 * @var $el_id
 * @var $interval
 * @var $css
 * @var $custom_titles
 * @var $custom_ttitles
 * @var $image_bind
 * @var $content
 */

$thumbnail = '';
$title = $source = $type = $onclick = $custom_links = $custom_links_target = $img_size = $external_img_size = $images = $custom_srcs = $custom_titles = $track_urls = $artists = $custom_ttitles = $image_bind = $el_class = $el_id = $interval = $css = $css_animation = '';
$large_img_src = '';

$attributes = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $attributes );

$default_src = vc_asset_url( 'vc/no_image.png' );

$gal_images = '';
$link_start = '';
$link_end = '';
$el_start = '';
$el_end = '';
$slides_wrap_start = '';
$slides_wrap_end = '';
$rs_title = '';
$rs_block = '';
$artist = '';

$el_class = $this->getExtraClass( $el_class );
if ( 'nivo' === $type ) {
    $type = ' wpb_slider_nivo theme-default';
    wp_enqueue_script( 'nivo-slider' );
    wp_enqueue_style( 'nivo-slider-css' );
    wp_enqueue_style( 'nivo-slider-theme' );

    $slides_wrap_start = '<div class="nivoSlider">';
    $slides_wrap_end = '</div>';
} elseif ( 'flexslider' === $type || 'flexslider_fade' === $type || 'flexslider_slide' === $type || 'fading' === $type ) {
    $el_start = '<li>';
    $el_end = '</li>';
    $slides_wrap_start = '<ul class="slides">';
    $slides_wrap_end = '</ul>';
    wp_enqueue_style( 'flexslider' );
    wp_enqueue_script( 'flexslider' );

} elseif ( 'image_grid' === $type ||  'image_tgrid' === $type || 'image_tgrid_m' === $type) {
    wp_enqueue_script( 'vc_grid-js-imagesloaded' );
    $el_end = '</div></div>';

    $slides_wrap_start = '<div class="row '.('image_tgrid_m' === $type ? 'project' : 'gallery').'-grid"><div class="filtr-container">';
    $slides_wrap_end = '</div></div>';
}
$flex_fx = '';
if ( 'flexslider' === $type || 'flexslider_fade' === $type || 'fading' === $type ) {
    $type = ' wpb_flexslider flexslider_fade flexslider';
    $flex_fx = ' data-flex_fx="fade"';
} elseif ( 'flexslider_slide' === $type ) {
    $type = ' wpb_flexslider flexslider_slide flexslider';
    $flex_fx = ' data-flex_fx="slide"';
}

if ( '' === $images ) {
    $images = '-1,-2,-3';
}

$pretty_rel_random = ' data-rel="prettyPhoto[rel-' . get_the_ID() . '-' . rand() . ']"';

if ( 'custom_link' === $onclick ) {
    $custom_links = vc_value_from_safe( $custom_links );
    $custom_links = explode( ',', $custom_links );
}

switch ( $source ) {
    case 'media_library':
        $images = explode( ',', $images );
        break;

    case 'external_link':
        $images = vc_value_from_safe( $custom_srcs );
        $images = explode( ',', $images );

        break;
}
foreach ( $images as $i => $image ) {
    switch ( $source ) {
        case 'media_library':
            if ( $image > 0 ) {
                $img = wpb_getImageBySize( array(
                    'attach_id' => $image,
                    'thumb_size' => $img_size,
                ) );
                $thumbnail = $img['thumbnail'];
                $large_img_src = $img['p_img_large'][0];
            } else {
                $large_img_src = $default_src;
                $thumbnail = '<div><img src="' . $default_src . '" /></div>';
            }
            break;

        case 'external_link':
            $image = esc_attr( $image );
            $dimensions = vcExtractDimensions( $external_img_size );
            $hwstring = $dimensions ? image_hwstring( $dimensions[0], $dimensions[1] ) : '';
            $thumbnail = '<div><img ' . $hwstring . ' src="' . $image . '" /></div>';
            $large_img_src = $image;
            break;
    }

    $link_start = $link_end = '';

    switch ( $onclick ) {
        case 'img_link_large':
            $link_start = '<a href="' . $large_img_src . '" target="' . $custom_links_target . '">';
            $link_end = '</a>';
            break;
        case 'link_image':
            $link_start = '<div data-mfp-src="' . $large_img_src . '" class="open-popup-image" data-effect="mfp-zoom-in">';
            $link_end = '</div>';
            break;
        case 'custom_link':
            if ( ! empty( $custom_links[ $i ] ) ) {
                $link_start = '<a href="' . $custom_links[ $i ] . '"' . ( ! empty( $custom_links_target ) ? ' target="' . $custom_links_target . '"' : '' ) . '>';
                $link_end = '</a>';
            }
            break;
    }

    if ('image_tgrid_m' === $type) :
        $link_start = '<div data-track="'.($i + 1).'" class="popup-player-link open-popup-link" data-effect="mfp-zoom-in" data-mfp-src="#playerPopup">';
        $link_end = '</div>';
    endif;

    $rs_titles = vc_value_from_safe( $custom_titles );
    $rs_titles = explode( ',', $rs_titles );

    if (!empty( $rs_titles[ $i ] ) ) {
        $rs_title = '<div class="'.('image_tgrid_m' === $type ? 'project' : 'gallery').'-grid-item-title">'.$rs_titles[ $i ].'</div>';
    }

    $icon_insta =  '<svg class="icon icon-instagram" width="20" height="21" viewBox="0 0 20 21" xmlns="http://www.w3.org/2000/svg"><path d="M14.9024 20.25H5.09767C4.39454 20.25 3.73048 20.1133 3.10548 19.8398C2.4935 19.5794 1.95314 19.2214 1.48439 18.7656C1.02866 18.2969 0.664075 17.7565 0.390637 17.1445C0.130221 16.5195 1.23978e-05 15.849 1.23978e-05 15.1328V5.34766C1.23978e-05 4.64453 0.130221 3.98698 0.390637 3.375C0.664075 2.75 1.02866 2.20964 1.48439 1.75391C1.95314 1.28516 2.4935 0.920573 3.10548 0.660156C3.73048 0.386719 4.39454 0.25 5.09767 0.25H14.9024C15.6055 0.25 16.263 0.386719 16.875 0.660156C17.5 0.920573 18.0404 1.28516 18.4961 1.75391C18.9649 2.20964 19.3294 2.75 19.5899 3.375C19.8633 3.98698 20 4.64453 20 5.34766V15.1328C20 15.849 19.8633 16.5195 19.5899 17.1445C19.3294 17.7565 18.9649 18.2969 18.4961 18.7656C18.0404 19.2214 17.5 19.5794 16.875 19.8398C16.263 20.1133 15.6055 20.25 14.9024 20.25ZM5.09767 1.38281C4.56381 1.38281 4.056 1.48698 3.57423 1.69531C3.09246 1.90365 2.66928 2.1901 2.3047 2.55469C1.94012 2.91927 1.65366 3.34245 1.44532 3.82422C1.25001 4.29297 1.15236 4.80078 1.15236 5.34766V15.1328C1.15236 15.6797 1.25001 16.194 1.44532 16.6758C1.65366 17.1576 1.94012 17.5807 2.3047 17.9453C2.66928 18.2969 3.09246 18.5768 3.57423 18.7852C4.056 18.9935 4.56381 19.0977 5.09767 19.0977H14.9024C15.4362 19.0977 15.944 18.9935 16.4258 18.7852C16.9076 18.5768 17.3307 18.2969 17.6953 17.9453C18.0599 17.5807 18.3399 17.1576 18.5352 16.6758C18.7435 16.194 18.8477 15.6797 18.8477 15.1328V5.34766C18.8477 4.80078 18.7435 4.29297 18.5352 3.82422C18.3399 3.34245 18.0599 2.91927 17.6953 2.55469C17.3307 2.1901 16.9076 1.91016 16.4258 1.71484C15.944 1.50651 15.4362 1.40234 14.9024 1.40234H5.09767V1.38281ZM19.4336 7.75H12.3828C12.2266 7.75 12.0899 7.69792 11.9727 7.59375C11.8685 7.47656 11.8164 7.33984 11.8164 7.18359C11.8164 7.02734 11.8685 6.89714 11.9727 6.79297C12.0899 6.67578 12.2266 6.61719 12.3828 6.61719H19.4336C19.5899 6.61719 19.7201 6.67578 19.8242 6.79297C19.9414 6.89714 20 7.02734 20 7.18359C20 7.33984 19.9414 7.47656 19.8242 7.59375C19.7201 7.69792 19.5899 7.75 19.4336 7.75ZM7.46095 7.75H0.566419C0.410169 7.75 0.27345 7.69792 0.156262 7.59375C0.0520957 7.47656 1.23978e-05 7.33984 1.23978e-05 7.18359C1.23978e-05 7.02734 0.0520957 6.89714 0.156262 6.79297C0.27345 6.67578 0.410169 6.61719 0.566419 6.61719H7.46095C7.6172 6.61719 7.75392 6.67578 7.87111 6.79297C7.98829 6.89714 8.04689 7.02734 8.04689 7.18359C8.04689 7.33984 7.98829 7.47656 7.87111 7.59375C7.75392 7.69792 7.6172 7.75 7.46095 7.75ZM10 14.7031C9.38803 14.7031 8.80861 14.5859 8.26173 14.3516C7.72788 14.1172 7.25913 13.7982 6.85548 13.3945C6.45184 12.9909 6.13282 12.5221 5.89845 11.9883C5.66407 11.4414 5.54689 10.862 5.54689 10.25C5.54689 9.63802 5.66407 9.0651 5.89845 8.53125C6.13282 7.98438 6.45184 7.50911 6.85548 7.10547C7.25913 6.70182 7.72788 6.38281 8.26173 6.14844C8.80861 5.91406 9.38803 5.79688 10 5.79688C10.612 5.79688 11.1849 5.91406 11.7188 6.14844C12.2656 6.38281 12.7409 6.70182 13.1445 7.10547C13.5482 7.50911 13.8672 7.98438 14.1016 8.53125C14.3359 9.0651 14.4531 9.63802 14.4531 10.25C14.4531 10.862 14.3359 11.4414 14.1016 11.9883C13.8672 12.5221 13.5482 12.9909 13.1445 13.3945C12.7409 13.7982 12.2656 14.1172 11.7188 14.3516C11.1849 14.5859 10.612 14.7031 10 14.7031ZM10 6.92969C9.08855 6.92969 8.3073 7.25521 7.65626 7.90625C7.00522 8.55729 6.6797 9.33854 6.6797 10.25C6.6797 11.1615 7.00522 11.9427 7.65626 12.5938C8.3073 13.2448 9.08855 13.5703 10 13.5703C10.9115 13.5703 11.6927 13.2448 12.3438 12.5938C12.9948 11.9427 13.3203 11.1615 13.3203 10.25C13.3203 9.33854 12.9948 8.55729 12.3438 7.90625C11.6927 7.25521 10.9115 6.92969 10 6.92969ZM16.4649 6.28516H13.8867C13.7305 6.28516 13.5938 6.23307 13.4766 6.12891C13.3724 6.01172 13.3203 5.86849 13.3203 5.69922V3.14062C13.3203 2.98438 13.3724 2.84766 13.4766 2.73047C13.5938 2.61328 13.7305 2.55469 13.8867 2.55469H16.4649C16.6211 2.55469 16.7513 2.61328 16.8555 2.73047C16.9727 2.84766 17.0313 2.98438 17.0313 3.14062V5.69922C17.0313 5.86849 16.9727 6.01172 16.8555 6.12891C16.7513 6.23307 16.6211 6.28516 16.4649 6.28516ZM14.4531 5.13281H15.8789V3.70703H14.4531V5.13281Z"/></svg>';
    $rs_title_svg = '<div class="'.('image_tgrid_m' === $type ? 'project' : 'gallery').'-grid-item-title">'.$icon_insta.'</div>';



    if ('image_tgrid_m' === $type) :
        $rs_artists = vc_value_from_safe($artists);
        $rs_artists = explode(',', $rs_artists );
        if (!empty( $rs_artists[$i] ) ) {
            $artist = '<div class="project-grid-item-artist">'.$rs_artists[ $i ].'</div>';
        }
    endif;

    $menu_name = 'Social Media Profiles - Gallery grid';
    $menu_object = wp_get_nav_menu_object( $menu_name );

    if ($menu_object) {
        $rs_social_block = wp_nav_menu(array(
            'menu' => $menu_name,
            'container' => 'div',
            'container_class' => 'footer-menu text-center',
            'menu_class' => '',
            'fallback_cb' => 'default_expanded_footer',
            'echo' => false
        ));
        $rs_social_block = '<div class="link-social tt-social-media-profiles-menu">'.voicer_clean_custom_menus($menu_object->slug).'</div>';
    } else {
       $rs_social_block = '';
    }

    $rs_social_block = '';
    $rs_block = '<div class="'.('image_tgrid_m' === $type ? 'project' : 'gallery').'-grid-item-caption">'.$rs_title_svg.$rs_title.$artist.$rs_social_block.'</div>';

    $image_bind_numbers = vc_value_from_safe($image_bind);
    $image_bind_numbers = explode( ',', $image_bind_numbers);

    if (!empty( $image_bind_numbers[ $i ] ) ) {
        $el_start = '<div class="'.('image_tgrid_m' === $type ? 'col-sm-4 col-md-20' : 'col-sm-6 col-md-4 col-lg-3').' filtr-item" data-category="'.$image_bind_numbers[$i].'" data-sort="value"><div class="'.('image_tgrid_m' === $type ? 'project' : 'gallery').'-grid-item">';
    } else {
        $el_start = '<div class="'.('image_tgrid_m' === $type ? 'col-sm-4 col-md-20' : 'col-sm-6 col-md-4 col-lg-3').' filtr-item" data-category="1" data-sort="value"><div class="'.('image_tgrid_m' === $type ? 'project' : 'gallery').'-grid-item">';
    }

    $gal_images .= $el_start.$link_start.'<div>'.$thumbnail.'</div>'.('image_tgrid_m' === $type ? '' : $rs_title_svg).$rs_block.$link_end.$el_end;
}

$class_to_filter = '';

$class_to_filter .= vc_shortcode_custom_css_class( $css, ' ' ) . $this->getExtraClass( $el_class ) . $this->getCSSAnimation( $css_animation );
$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class_to_filter, $this->settings['base'], $atts );
$wrapper_attributes = array();
if ( ! empty( $el_id ) ) {
    $wrapper_attributes[] = 'id="' . esc_attr( $el_id ) . '"';
}
$output = '';
$output .= '<div class="custom_css ' . $css_class . '" ' . implode( ' ', $wrapper_attributes ) . '>';
$output .= '<div class="container">';

$output .= wpb_widget_title( array(
    'title' => $title,
    'extraclass' => 'wpb_gallery_heading',
) );

$rs_t_titles = vc_value_from_safe( $custom_ttitles );
$rs_t_titles = explode( ',', $rs_t_titles);

if (!empty($rs_t_titles)) {
    $output .= '<ul class="filtr-row text-center">';
    $output .= '<li class="active" data-filter="all"><span>'.$rs_t_titles[0].'</li>';

    $rs_t_titles1 = array_shift($rs_t_titles);

    foreach ($rs_t_titles as $k => $rs_t_title) :
        $k = $k + 1;
        $output .= '<li data-filter="'.$k.'"><span>'.$rs_t_title.'</span></li>';
    endforeach;
    $output .= '</ul>';
}
$output .= $slides_wrap_start . $gal_images . $slides_wrap_end;
$output .= '</div></div>';

$output .= wpb_js_remove_wpautop( $content, true );

if ('image_tgrid_m' === $type) :

    $output .= '<div id="playerPopup" class="awp-player-popup mfp-with-anim">
		<div class="mfp-inside">
			<div id="awp-grid-player">
				<div class="awp-player-thumb"></div>
				<div class="awp-player-holder">
					<div class="awp-info">
						<div class="awp-player-artist"></div>
						<div class="awp-player-title"></div>
					</div>
					<div class="awp-waveform-wrap">
						<div class="awp-waveform awp-hidden"></div>
						<div class="awp-waveform-img awp-hidden">
							<div class="awp-waveform-img-load"></div>
							<div class="awp-waveform-img-progress-wrap">
								<div class="awp-waveform-img-progress"></div>
							</div>
						</div>
						<span class="awp-waveform-preloader"></span>
					</div>
					<div class="awp-player-controls">
						<div class="awp-prev-toggle awp-contr-btn"><i class="icon-prev-track awp-contr-btn-i awp-icon-color"></i></div>
						<div class="awp-playback-toggle awp-contr-btn"><i class="icon-play-circle awp-contr-btn-i awp-icon-color"></i></div>
						<div class="awp-next-toggle awp-contr-btn"><i class="icon-next-track awp-contr-btn-i awp-icon-color"></i></div>
						<div class="awp-volume-wrapper">
							<div class="awp-player-volume"><i class="icon icon-music-equalizer-1"></i></div>
							<div class="awp-volume-seekbar awp-tooltip-top">
								<div class="awp-volume-bg"></div>
								<div class="awp-volume-level"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div id="awp-grid-playlist">
				<ul id="playlist-3">';

    $aw_artist = '';
    $aw_title = '';
    $aw_track_url = '';

    $aw_artists = vc_value_from_safe($artists);
    $aw_artists = explode(',', $aw_artists );

    $aw_titles = vc_value_from_safe($custom_titles);
    $aw_titles = explode(',', $aw_titles );

    $aw_track_urls = vc_value_from_safe($track_urls);
    $aw_track_urls = explode(',', $aw_track_urls );

    foreach ( $images as $i => $image ) {
        if ($image > 0) {
            $img = wpb_getImageBySize( array('attach_id' => $image,'thumb_size' => $img_size));
            $aw_image_src = $img['p_img_large'][0];
        } else {
            $aw_image_src = $default_src;
        }

        if (!empty($aw_track_urls[$i] ) ) {$aw_track_url = $aw_track_urls[$i];}

        if (!empty($aw_artists[$i] ) ) {$aw_artist = $aw_artists[$i];}

        if (!empty($aw_titles[$i] ) ) {$aw_title = $aw_titles[$i];}

        $output .= '<li class="awp-playlist-item" data-type="audio" data-mp3="'.$aw_track_url.'" data-artist="'.$aw_artist.'" data-title="'.$aw_title.'" data-thumb="'.$aw_image_src.'"	data-download="'.$aw_track_url.'"></li>';
    }

    $output .= '
				</ul>
			</div>
		</div>
	</div>';
endif;
echo $output;