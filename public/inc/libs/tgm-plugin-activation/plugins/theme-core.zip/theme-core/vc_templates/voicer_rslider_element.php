<?php
if ( ! defined( 'ABSPATH' ) ) {
    die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $gm_width
 * @var $gm_height
 * @var $gm_type
 * @var $gm_latitude
 * @var $gm_longitude
 * @var $gm_zoom
 * @var $gm_text
 * @var $gm_marker
 * @var $el_id
 * @var $el_class
 * @var $content
 */
$default_src = vc_asset_url('vc/no_image.png');
$el_class = $el_id = $rs_num = $rs_img_size = $rs_loader = $arrows = $dots = $autoplay = $autoplayspeed = $fade = $speed = $output = '';

$attributes = vc_map_get_attributes($this->getShortcode(), $atts);
extract($attributes);
$rs_texts_output = explode('{slide}', $content );

$rs_num = ($rs_num =='' || $rs_num = 0 ? 2 : intval($rs_num));
$el_id = ($el_id != '' ? $el_id : 'mainSlider');


$rs_object = array(
    'el_id' => $el_id,
    'arrows' => $arrows,
    'dots' => $dots,
    'autoplay' => $autoplay,
    'autoplayspeed' => $autoplayspeed,
    'fade' => $fade,
    'speed' => $speed
);

$rs_images = explode( ',', $attributes['rs_images'] );


wp_enqueue_script('voicer-rslider-element');
wp_localize_script('voicer-rslider-element', 'rsObject', $rs_object);

$output .= '<div class="mainSliderWrapper">
    <div class="loader-wrapper"><div class="loader-container"><div class="rectangle-1">&nbsp;</div><div class="rectangle-2">&nbsp;</div><div class="rectangle-3">&nbsp;</div><div class="rectangle-4">&nbsp;</div><div class="rectangle-5">&nbsp;</div><div class="rectangle-6">&nbsp;</div><div class="rectangle-5">&nbsp;</div><div class="rectangle-4">&nbsp;</div><div class="rectangle-3">&nbsp;</div><div class="rectangle-2">&nbsp;</div><div class="rectangle-1">&nbsp;</div></div></div>
    <div id="'.$el_id.'" class="mainSlider">';

for ($i = 0; $i < $attributes['rs_num']; $i++) :
    if (isset($rs_images[$i])) {
        $img = wpb_getImageBySize( array(
            'attach_id' => $rs_images[$i],
            'thumb_size' => 'full',
        ) );
        $image_src = $img['p_img_large'][0];
    } else {
        $image_src = $default_src;
    }

    $output .= '<div class="slide"><div class="img--holder" style="background-image: url('.$image_src.')"></div>';

    if (isset($rs_texts_output[$i])) :
    $output .= '
            <div class="slide-content center">
                <div class="vert-wrap container">
                    <div class="vert">
                        <div class="container">
                            <div class="slide-caption">'.wpb_js_remove_wpautop($rs_texts_output[$i], true ).'</div>
                        </div>
                    </div>
                </div>
            </div>';
    endif;

    $output .= '</div>';
endfor;

$output .= '</div></div>';

echo $output;

