<?php
if ( ! defined( 'ABSPATH' ) ) {
    die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $facebook_account
 * @var $hide_cover
 * @var $tabs
 * @var $show_facepile
 * @var $adapt_container_width
 * @var $small_header
 * @var $width
 * @var $height
 * @var $el_class
 */
$attributes = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $attributes );

$facebook_account = ($facebook_account != '' ? $facebook_account : 'envato');
$hide_cover = $hide_cover != '' ? $hide_cover : 'false';
$tabs = $tabs != '' ? $tabs : 'timeline';
$show_facepile = $show_facepile != '' ? $show_facepile : 'true';
$adapt_container_width = $adapt_container_width != '' ? $adapt_container_width : 'true';
$small_header = $small_header != '' ? $small_header : 'true';
$width = $width != '' ? $width : '340';
$height = $height != '' ? $height : '360';

echo '<div class="'.$el_class.'">';
echo '<iframe class="iframe-facebook" src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2F'.$facebook_account.'%2F&tabs='.$tabs.'&width='.$width.'&height='.$height.'&small_header='.$small_header.'&adapt_container_width='.$adapt_container_width.'&hide_cover='.$hide_cover.'&show_facepile='.$show_facepile.'&appId=653691078039193"></iframe>';
echo '</div>';