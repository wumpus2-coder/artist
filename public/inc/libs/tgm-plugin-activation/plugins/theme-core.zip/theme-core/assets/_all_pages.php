<!--Home page slider-->
[vc_row rsclass="clean"][vc_column rsclass="clean"][voicer_rslider_element arrows="false" dots="false" rs_images="200,201" class="``h-gradient``" data-animation="``fadeIn``"]
<h4 data-animation="fadeIn" data-animation-delay="0s">Recording Music. Recording History.</h4>
<h2 data-animation="fadeIn" data-animation-delay="0s"><span class="h-gradient">WE CAN RECORD</span></h2>
<h2 data-animation="fadeIn" data-animation-delay="0s">Anything</h2>
<div class="btn-wrapper"><a class="btn btn--fill">know more</a></div>
{slide}
<h4 data-animation="fadeIn" data-animation-delay="0s">Bring music to life</h4>
<h2 data-animation="fadeIn" data-animation-delay="0s"><span class="h-gradient">NO STUDIO YET?</span></h2>
<h2 data-animation="fadeIn" data-animation-delay="0s">No Problem.</h2>
<div class="btn-wrapper"><a class="btn btn--fill">know more</a></div>
[/voicer_rslider_element][vc_column_text rsclass="clean"][aw_player type="home"]<ul id="playlist-2">
    <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/2/01.mp3" data-artist="Soundroll" data-title="Needs Your Music"></li>
    <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/2/02.mp3" data-artist="Soundroll" data-title="Needs Your Music"></li>
    <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/2/03.mp3" data-artist="Soundroll" data-title="Needs Your Music"></li>
</ul>[/aw_player][/vc_column_text][/vc_column][/vc_row]



<!--Home compressed-->
[vc_row rsclass="clean"][vc_column rsclass="clean"][voicer_rslider_element arrows="false" dots="false" rs_images="200,201" class="``h-gradient``" data-animation="``fadeIn``"]<h4 data-animation="fadeIn" data-animation-delay="0s">Recording Music. Recording History.</h4><h2 data-animation="fadeIn" data-animation-delay="0s"><span class="h-gradient">WE CAN RECORD</span></h2><h2 data-animation="fadeIn" data-animation-delay="0s">Anything</h2><div class="btn-wrapper"><a class="btn btn--fill">know more</a></div>{slide}<h4 data-animation="fadeIn" data-animation-delay="0s">Bring music to life</h4><h2 data-animation="fadeIn" data-animation-delay="0s"><span class="h-gradient">NO STUDIO YET?</span></h2><h2 data-animation="fadeIn" data-animation-delay="0s">No Problem.</h2><div class="btn-wrapper"><a class="btn btn--fill">know more</a></div>[/voicer_rslider_element][vc_column_text rsclass="clean"][aw_player type="home"]<ul id="playlist-2"> <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/2/01.mp3" data-artist="Soundroll" data-title="Needs Your Music"></li> <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/2/02.mp3" data-artist="Soundroll" data-title="Needs Your Music"></li> <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/2/03.mp3" data-artist="Soundroll" data-title="Needs Your Music"></li></ul>[/aw_player][/vc_column_text][/vc_column][/vc_row]


[vc_row rsclass="clean" el_class="block block--bgcover block-bg-welcome ch-separator"][vc_column rsclass="clean" el_class="container"][vc_row_inner rsclass="clean" el_class="row blocks-reverse"][vc_column_inner el_class="col-sm-6 ch-block-welcome-left" width="1/2" rsclass="clean"][vc_column_text rsclass="clean"]<h2 class="heading heading-separator hidden-xs"><span class="ch">Welcome to Voicer</span></h2>[/vc_column_text][vc_column_text rsclass="clean"]<p class="p--lg">The Voicer is the brainchild of musicians who understand<br class="hidden-xs hidden-sm hidden-md" />that the best art comesfrom the best environment</p>[/vc_column_text][vc_column_text rsclass="clean"]<p class="ch">They know that to make great music, you need great surroundings — a combination of top-notch gear, comfortable work and lounge areas, a relaxing setting, and knowledgeable, capable staff who can work with artists of any level. A place without distractions, yet accessible, where development is encouraged and prices aren’t prohibitive, but quality is<br class="hidden-xs hidden-sm hidden-md" />never sacrificed and clients are treated with respect.</p>[voicer_icon icon="icon-sign"][/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-6 mt-md-0 ch-block-welcome-right" width="1/2" rsclass="clean"][vc_column_text rsclass="clean"]<h2 class="heading heading-separator visible-xs mt-0 pt-0"><span class="ch">Welcome to Voicer</span></h2>[/vc_column_text][vc_single_image image="202" img_size="full" onclick="custom_link" img_link_target="_blank" rsclass="clean" link="#" el_class="ch-video-block"][vc_column_text rsclass="clean"]<div class="ch-video-block__btn ch-pulse"><a class="" href="//themeforest.net" target="_blank" rel="noopener noreferrer">[voicer_icon icon="icon-video-play"]</a></div>[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner rsclass="clean" el_class="banner-booking row"][vc_column_inner el_class="col-md-7 col-lg-8" width="1/2" rsclass="clean" rsinner="text-right text-xs-center text-sm-center"][vc_column_text rsclass="clean"]<h2 class="ch">Need a <span class="h-gradient">QUALITY</span> Sound?</h2><p class="p--lg color-invert">We deliver the very best service and amenities signed artists and independent musicians.</p>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-md-5 col-lg-4" width="1/2" rsclass="clean" rsinner="text-center"][vc_column_text rsclass="clean" el_class="btn-wrap"]<div class="ch"><a class="btn btn--white open-popup-link" href="#" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup">[voicer_icon icon="icon-mic"]book session now</a></div><p class="p--sm">And get a one recording hour for <span class="theme-color"><b>FREE</b></span>*</p>[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="form-popup mfp-with-anim" el_id="bookingPopup"][vc_column rsclass="clean" el_class="form-popup-inside mfp-inside"][vc_column_text rsclass="clean"]<div class="ch"><button class="close" aria-label="Close" data-dismiss="modal">[voicer_icon icon="icon-close"]</button></div>[/vc_column_text][vc_custom_heading text="Book Your Session" font_container="tag:h3|text_align:center" use_theme_fonts="yes"][contact-form-7 id="371"][/vc_column][/vc_row]


[vc_row rsclass="clean" el_class="block block--darkbg block--full ch-block-rstudios ch-separator"][vc_column rsclass="clean"][vc_column_text rsclass="clean" el_class=" container title-wrap text-center color-invert font-n"]<h2 class="color-invert">Recording Studios</h2><p class="p--lg">The Voicer is a 2,000 square foot facility with 1 control room, 2 live <br class="hidden-xs" />rooms, and 1 vocal booth</p>[/vc_column_text][vc_row_inner rsclass="clean" el_class="studio-gallery ini-studio-gallery"][vc_column_inner el_class="studio-item" width="1/3" rsclass="clean"][vc_single_image image="170" img_size="full" rsclass="clean" el_class="studio-item-photo"][vc_column_text rsclass="clean"]<h4 class="studio-item-title"><span class="tt">Studio A</span> – Recording Studio</h4><p class="studio-item-info">Our 30m2 tracking room hosts a pristine Neve VR36 console with Flying Faders,<br class="hidden-xs hidden-sm" />ATC monitors, Prism ADA-8XR’s converters and a stunning rack of world class outboard.</p>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="studio-item" width="1/3" rsclass="clean"][vc_single_image image="171" img_size="full" rsclass="clean" el_class="studio-item-photo"][vc_column_text rsclass="clean"]<h4 class="studio-item-title"><span class="tt">Studio B</span> – Tracking Studio</h4><p class="studio-item-info">Our 30m2 tracking room hosts a pristine Neve VR36 console with Flying Faders,<br class="hidden-xs hidden-sm" />ATC monitors, Prism ADA-8XR’s converters and a stunning rack of world class outboard.</p>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="studio-item" width="1/3" rsclass="clean"][vc_single_image image="172" img_size="full" rsclass="clean" el_class="studio-item-photo"][vc_column_text rsclass="clean"]<h4 class="studio-item-title"><span class="tt">Studio C</span> – Mastering Studio</h4><p class="studio-item-info">Our 30m2 tracking room hosts a pristine Neve VR36 console with Flying Faders,<br class="hidden-xs hidden-sm" />ATC monitors, Prism ADA-8XR’s converters and a stunning rack of world class outboard.</p>[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]


[vc_row rsclass="clean" el_class="block block--fullbg block--bgcover block-bg-projects ch-block-projects ch-separator"][vc_column rsclass="clean" el_class="container"][vc_column_text rsclass="clean" el_class="title-wrap text-center"]<h2 class="entry-title7 ">Our Projects</h2><p class="p--lg">We are very proud of our client base and the lasting relationships <br class="hidden-xs" />we have forged over many years.</p>[/vc_column_text][vc_row_inner rsclass="clean" el_class="project-slider ini-project-slider"][vc_column_inner el_class="project-item" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]<div class="project-item-photo popup-player-link open-popup-link" data-track="1" data-effect="mfp-zoom-in" data-mfp-src="#playerPopup"><img class="img-responsive alignnone wp-image-917 size-full" src="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/01.jpg" alt="Project Cover" /></div>[/vc_column_text][vc_column_text rsclass="clean"]<div class="project-item-title">American Girl</div><div class="project-item-author">Bonnie McKee</div>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="project-item" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]<div class="project-item-photo popup-player-link open-popup-link" data-track="2" data-effect="mfp-zoom-in" data-mfp-src="#playerPopup"><img class="img-responsive alignnone wp-image-917 size-full" src="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/02.jpg" alt="Project Cover" /></div>[/vc_column_text][vc_column_text rsclass="clean"]<div class="project-item-title">Into The Sun</div><div class="project-item-author">Robben Ford</div>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="project-item" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]<div class="project-item-photo popup-player-link open-popup-link" data-track="2" data-effect="mfp-zoom-in" data-mfp-src="#playerPopup"><img class="img-responsive alignnone wp-image-917 size-full" src="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/03.jpg" alt="Project Cover" /></div>[/vc_column_text][vc_column_text rsclass="clean"]<div class="project-item-title">Better Nature</div><div class="project-item-author">Silversun Pickups</div>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="project-item" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]<div class="project-item-photo popup-player-link open-popup-link" data-track="2" data-effect="mfp-zoom-in" data-mfp-src="#playerPopup"><img class="img-responsive alignnone wp-image-917 size-full" src="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/04_01.jpg" alt="Project Cover" /></div>[/vc_column_text][vc_column_text rsclass="clean"]<div class="project-item-title">I Don't Care</div><div class="project-item-author">Nicki J.</div>[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner rsclass="clean" el_class="wrapper-btn-border1-icon"][vc_column_inner el_class="text-center" rsclass="clean"][vc_column_text rsclass="clean"]<div class="ch"><a class="btn btn--border1" href="projects">[voicer_icon icon="icon-spectr"]view all projects</a></div>[/vc_column_text][vc_column_text rsclass="clean"][aw_player type="popup"]<ul id="playlist-3"> <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/3/01.mp3" data-artist="Artist Name" data-title="Track Title" data-thumb="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/01.jpg" data-download="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/01.mp3"></li> <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/02.mp3" data-artist="Artist Name" data-title="Track Title" data-thumb="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/02.jpg" data-download="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/1/02.mp3"></li> <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/03.mp3" data-artist="Artist Name" data-title="Track Title" data-thumb="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/03.jpg" data-download="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/1/03.mp3"></li> <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/04.mp3" data-artist="Artist Name" data-title="Track Title" data-thumb="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/04.jpg" data-download="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/1/04.mp3"></li> <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/05.mp3" data-artist="Artist Name" data-title="Track Title" data-thumb="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/05.jpg" data-download="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/1/05.mp3"></li></ul>[/aw_player][/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]


[vc_row rsclass="clean" el_class="block block--fullbg block--bgcover block--darkbg block-bg-clients ch-block-clients ch-separator"][vc_column rsclass="clean" el_class="container"][vc_column_text rsclass="clean" el_class="text-center title-wrap"]<h2 class="color-white">Our Clients</h2><div class="cd-headline letters"><ul class="cd-words-wrapper"> <li class="is-visible">Michael Earle</li> <li>Ann Houston</li> <li>Natasha Ward</li> <li>Katie Dunnv</li> <li>Roger Hoehne</li> <li>Thomas Elliott</li> <li>Bobby Hodge</li> <li>Lisa Cook</li> <li>Nathalie Smith</li> <li>Ben Worrell</li> <li>Jane Wilcher</li> <li>Pauline Day</li> <li>Gabriel Chau</li> <li>Galen Martin</li></ul></div>[/vc_column_text][vc_row_inner rsclass="clean" el_class="row"][vc_column_inner el_class="col-sm-4 col-md-3" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]<ul class="clients-list"> <li>Michael Earle</li> <li>Michael Vazquez</li> <li>Matthew Duncan</li> <li>Rickey Campbell</li> <li>Jonathan Ku</li> <li>Theresa Ochoa</li> <li>Angela Hunley</li></ul>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4 col-md-3" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]<ul class="clients-list"> <li>Beverly Pleasants</li> <li>Louis Shay</li> <li>Stephen Rivers</li> <li>Alan Doody</li> <li>Betty Cochran</li> <li>Marlene Fowler</li> <li>Lois Olson</li></ul>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4 col-md-3" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]<ul class="clients-list"> <li>Dorothy Riddle</li> <li>Katie Dunnv</li> <li>Roger Hoehne</li> <li>Thomas Elliott</li> <li>Bobby Hodge</li> <li>Ashley Greene</li> <li>Dorothy Shepherd</li></ul>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4 col-md-3" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]<ul class="clients-list"> <li>Theresa Blanding</li> <li>George Norsworthy</li> <li>Nathalie Smith</li> <li>Ben Worrell</li> <li>Jane Wilcher</li> <li>Pena</li> <li>Orville Thompson</li></ul>[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_column_text rsclass="clean" el_class="text-center offset-30 visible-xs visible-sm"]<div class="tt"><a class="btn btn--border1" href="#" data-show-sm="collapse-clients">[voicer_icon icon="icon-spectr"]view all clients</a></div>[/vc_column_text][/vc_column][/vc_row]



[vc_row rsclass="clean" el_class="block ch-block-news bg-pages bg-home-latest-news"][vc_column rsclass="clean" el_class="container"][vc_column_text rsclass="clean" el_class="title-wrap text-center"]<h2 class="entry-title7 ">Latest News</h2><p class="p--lg">Find out about everything happening here at Voicer. Keep an eye out<br class="hidden-xs" />here for all of our upcoming events</p>[/vc_column_text][vc_row_inner el_class="row news-slider ini-news-slider-mobile tt-block-news" rsclass="clean"][vc_column_inner el_class="col-sm-4 news-item" width="1/3" rsclass="clean" rsinner="news-item-inside"][vc_single_image image="173" img_size="full" onclick="custom_link" img_link_target="_blank" rsclass="clean" link="the-voicer-in-la-times/" el_class="news-item-photo"][vc_column_text rsclass="clean"]<div class="news-item-date">[voicer_icon icon="icon-time"]10.10.2017</div><h5 class="news-item-title"><a href="about"><strong class="ch">Recording Checklist for Bands/Artists</strong></a></h5><p class="ch">We are always trying to help out bands and artists get a great sounding...</p><div class="wrapper-btn-link-icon-text"><a class="link-icon-text" href="blog-page">[voicer_icon icon="icon-video-play"]read more</a></div>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4 news-item" width="1/3" rsclass="clean" rsinner="news-item-inside"][vc_single_image image="174" img_size="full" onclick="custom_link" img_link_target="_blank" rsclass="clean" link="the-voicer-in-la-times/" el_class="news-item-photo"][vc_column_text rsclass="clean"]<div class="news-item-date">[voicer_icon icon="icon-time"]10.10.2017</div><h5 class="news-item-title"><a href="about"><strong class="ch">Spitfire on a Roll With New Orchestral</strong></a></h5><p class="ch">The final parts of Spitfire's Studio Orchestra Library are released...</p><div class="wrapper-btn-link-icon-text"><a class="link-icon-text" href="blog-page">[voicer_icon icon="icon-video-play"]read more</a></div>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4 news-item" width="1/3" rsclass="clean" rsinner="news-item-inside"][vc_single_image image="175" img_size="full" onclick="custom_link" img_link_target="_blank" rsclass="clean" link="the-voicer-in-la-times/" el_class="news-item-photo"][vc_column_text rsclass="clean"]<div class="news-item-date">[voicer_icon icon="icon-time"]10.10.2017</div><h5 class="news-item-title"><a href="about"><strong class="ch">Roger Mayer Updates Classic Mastering </strong></a></h5><p class="ch">Respected electronics engineer Roger Mayer updates his much-loved RM58...</p><div class="wrapper-btn-link-icon-text"><a class="link-icon-text" href="blog-page">[voicer_icon icon="icon-video-play"]read more</a></div>[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]


[vc_row rsclass="clean" el_class="block block--darkbg block--fullbg ch-block-reviews ch-separator"][vc_column rsclass="clean" el_class="container"][vc_column_text rsclass="clean" el_class="title-wrap"]<h2 class="heading heading-separator hidden visible-xs"><span class="ch">What Voicer Customers Say</span></h2>[/vc_column_text][vc_row_inner rsclass="clean" el_class="reviews-slider-2 ini-reviews-slider"][vc_column_inner el_class="review-item" width="1/3" rsclass="clean"][vc_column_text rsclass="clean" el_class="review-item-content"]<h2 class="heading heading-separator hidden-xs"><span class="ch">What Voicer Customers Say</span></h2><p class="p--lg color-invert review-item-text">The products I have produced with their help have been accounted outstanding, both in terms of music and graphics. I recommend Voicer unreservedly and unqualifiedly.</p><p class="p--md theme-color review-item-author-name">- Ida A. Wakefield</p>[/vc_column_text][vc_single_image image="176" img_size="full" rsclass="clean" el_class="review-item-author-photo"][/vc_column_inner][vc_column_inner el_class="review-item" width="1/3" rsclass="clean"][vc_column_text rsclass="clean" el_class="review-item-content"]<h2 class="heading heading-separator hidden-xs"><span class="ch">What Voicer Customers Say</span></h2><p class="p--lg color-invert review-item-text">My first initial session to record a demo for my publisher was meant to be a one-off. I was so impressed with the standard and level of service that I went back to record songs</p><p class="p--md theme-color review-item-author-name">- Ida A. Wakefield</p>[/vc_column_text][vc_single_image image="176" img_size="full" rsclass="clean" el_class="review-item-author-photo"][/vc_column_inner][vc_column_inner el_class="review-item" width="1/3" rsclass="clean"][vc_column_text rsclass="clean" el_class="review-item-content"]<h2 class="heading heading-separator hidden-xs"><span class="ch">What Voicer Customers Say</span></h2><p class="p--lg color-invert review-item-text">I wanted to drop you a brief but sincere couple of lines of thanks for all the hard work you put into making the music &amp; sound behind Economy Gastronomy such a success. Despite having a brief thrown</p><p class="p--md theme-color review-item-author-name">- Ida A. Wakefield</p>[/vc_column_text][vc_single_image image="176" img_size="full" rsclass="clean" el_class="review-item-author-photo"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]


[vc_row rsclass="clean" el_class="block block--fullbg block--bgcover block-bg-engineer ch-separator"][vc_column rsclass="clean" el_class="container"][vc_column_text rsclass="clean" el_class="title-wrap text-center"]<h2 class="entry-title7 ">Our Engineers</h2><p class="p--lg">At Voicer we believe that the calibre of your engineers &amp; producers <br class="hidden-xs" />is just as important as the quality of the studio you work in</p>[/vc_column_text][vc_row_inner rsclass="clean" el_class="row team-grid ini-team-slider-mobile"][vc_column_inner el_class="col-sm-6 col-lg-4 team-member" width="1/6" rsclass="clean" rsinner="team-member-inside"][vc_column_text rsclass="clean" el_class="team-member-info"]<h4 class="team-member-name">Bryan Johnson</h4><p class="team-member-position">Engineer / Owner</p><div class="wrapper-btn-link-icon-text"><div class="wrapper-btn-link-icon-text"><a class="link-icon-text" href="blog-page">[voicer_icon icon="icon-video-play"]know more</a></div></div>[/vc_column_text][vc_single_image image="353" img_size="full" rsclass="clean" el_class="team-member-photo"][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-lg-4 team-member" width="1/6" rsclass="clean" rsinner="team-member-inside"][vc_column_text rsclass="clean" el_class="team-member-info"]<h4 class="team-member-name">Linda Thomas</h4><p class="team-member-position">Engineer / Owner</p><div class="wrapper-btn-link-icon-text"><div class="wrapper-btn-link-icon-text"><a class="link-icon-text" href="blog-page">[voicer_icon icon="icon-video-play"]know more</a></div></div>[/vc_column_text][vc_single_image image="178" img_size="full" rsclass="clean" el_class="team-member-photo"][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-lg-4 team-member" width="1/6" rsclass="clean" rsinner="team-member-inside"][vc_column_text rsclass="clean" el_class="team-member-info"]<h4 class="team-member-name">Jessie Ramirez</h4><p class="team-member-position">Engineer</p><div class="wrapper-btn-link-icon-text"><div class="wrapper-btn-link-icon-text"><a class="link-icon-text" href="blog-page">[voicer_icon icon="icon-video-play"]know more</a></div></div>[/vc_column_text][vc_single_image image="179" img_size="full" rsclass="clean" el_class="team-member-photo"][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-lg-4 team-member" width="1/6" rsclass="clean" rsinner="team-member-inside"][vc_column_text rsclass="clean" el_class="team-member-info"]<h4 class="team-member-name">David Reyna</h4><p class="team-member-position">Producer</p><div class="wrapper-btn-link-icon-text"><div class="wrapper-btn-link-icon-text"><a class="link-icon-text" href="blog-page">[voicer_icon icon="icon-video-play"]know more</a></div></div>[/vc_column_text][vc_single_image image="180" img_size="full" rsclass="clean" el_class="team-member-photo"][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-lg-4 team-member" width="1/6" rsclass="clean" rsinner="team-member-inside"][vc_column_text rsclass="clean" el_class="team-member-info"]<h4 class="team-member-name">Michael Hadlock</h4><p class="team-member-position">Engineer</p><div class="wrapper-btn-link-icon-text"><div class="wrapper-btn-link-icon-text"><a class="link-icon-text" href="blog-page">[voicer_icon icon="icon-video-play"]know more</a></div></div>[/vc_column_text][vc_single_image image="181" img_size="full" rsclass="clean" el_class="team-member-photo"][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-lg-4 team-member" width="1/6" rsclass="clean" rsinner="team-member-inside"][vc_column_text rsclass="clean" el_class="team-member-info"]<h4 class="team-member-name">Evelyn Schultz</h4><p class="team-member-position">Producer</p><div class="wrapper-btn-link-icon-text"><div class="wrapper-btn-link-icon-text"><a class="link-icon-text" href="blog-page">[voicer_icon icon="icon-video-play"]know more</a></div></div>[/vc_column_text][vc_single_image image="182" img_size="full" rsclass="clean" el_class="team-member-photo"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]


[vc_row rsclass="clean" el_class="block block--darkbg bottom-null block--full ch-block-inst ch-separator"][vc_column rsclass="clean"][vc_column_text rsclass="clean" el_class="title-wrap text-center"]<h2 class="ch">Instagram <span class="theme-color">@Voicer</span></h2>[/vc_column_text][voicer_instagram_element access_token="8334873284.47cde00.1682e1c3d5614f3c95d0a4d68474d953" limit="16" el_class="ch-instagram-grid instagram-grid-full"][vc_column_text rsclass="clean" el_class="text-center btn-wrapper visible-xs visible-sm"]<div class="tt"><a class="btn btn--border1" href="#" data-show-sm="collapse-clients">[voicer_icon icon="icon-spectr"]more photos</a></div>[/vc_column_text][/vc_column][/vc_row]

[vc_row rsclass="clean" el_class="block ch-block-booking ch-separator"][vc_column rsclass="clean" el_class="container"][vc_column_text rsclass="clean" el_class="title-wrap text-center"]<h2 class="entry-title7 ">Booking</h2><p class="p--lg">Select your session and book online instantly. If you have any<br class="hidden-xs" />questions, you give us a call or email us</p>[/vc_column_text][vc_row_inner rsclass="clean" el_class="row tt-booking-blocks"][vc_column_inner el_class="col-sm-4 booking-block" width="1/3" rsclass="clean"][vc_column_text rsclass="clean"]<div class="tt"><div class="booking-link open-popup-link" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup"><div class="booking-link-inside"><h4 class="booking-link-title">[voicer_icon icon="icon-equalizer1"]Book Engineer Session</h4><div class="booking-link-price">from <span class="tt"><strong class="tt">$95 / hour</strong></span></div></div></div></div>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4 booking-block" width="1/3" rsclass="clean"][vc_column_text rsclass="clean"]<div class="tt"><div class="booking-link open-popup-link" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup"><div class="booking-link-inside"><h4 class="booking-link-title">[voicer_icon icon="icon-notes"]Book Producer Session</h4><div class="booking-link-price">from <span class="tt"><strong class="tt">$195 / hour</strong></span></div></div></div></div>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4 booking-block" width="1/3" rsclass="clean"][vc_column_text rsclass="clean"]<div class="tt"><div class="booking-link open-popup-link" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup"><div class="booking-link-inside"><h4 class="booking-link-title">[voicer_icon icon="icon-megaphone"]Book Assistant Session</h4><div class="booking-link-price">from <span class="tt"><strong class="tt">$75 / hour</strong></span></div></div></div></div>[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]



<!--Home fully compressed-->
[vc_row rsclass="clean" el_class="block bottom-null block--slider ch-block-slider pt-0"][vc_column rsclass="clean"][voicer_rslider_element arrows="false" dots="false" rs_images="200,201" class="``h-gradient``" data-animation="``fadeIn``"]<h4 data-animation="fadeIn" data-animation-delay="0s">Recording Music. Recording History.</h4><h2 data-animation="fadeIn" data-animation-delay="0s"><span class="h-gradient">WE CAN RECORD</span></h2><h2 data-animation="fadeIn" data-animation-delay="0s">Anything</h2><div class="btn-wrapper"><a class="btn btn--fill">know more</a></div>{slide}<h4 data-animation="fadeIn" data-animation-delay="0s">Bring music to life</h4><h2 data-animation="fadeIn" data-animation-delay="0s"><span class="h-gradient">NO STUDIO YET?</span></h2><h2 data-animation="fadeIn" data-animation-delay="0s">No Problem.</h2><div class="btn-wrapper"><a class="btn btn--fill">know more</a></div>[/voicer_rslider_element][vc_column_text rsclass="clean"][aw_player type="home"]<ul id="playlist-2"> <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/2/01.mp3" data-artist="Soundroll" data-title="Needs Your Music"></li> <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/2/02.mp3" data-artist="Soundroll" data-title="Needs Your Music"></li> <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/2/03.mp3" data-artist="Soundroll" data-title="Needs Your Music"></li></ul>[/aw_player][/vc_column_text][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block block--bgcover block-bg-welcome ch-separator"][vc_column rsclass="clean" el_class="container"][vc_row_inner rsclass="clean" el_class="row blocks-reverse"][vc_column_inner el_class="col-sm-6 ch-block-welcome-left" width="1/2" rsclass="clean"][vc_column_text rsclass="clean"]<h2 class="heading heading-separator hidden-xs"><span class="ch">Welcome to Voicer</span></h2>[/vc_column_text][vc_column_text rsclass="clean"]<p class="p--lg">The Voicer is the brainchild of musicians who understand<br class="hidden-xs hidden-sm hidden-md" />that the best art comesfrom the best environment</p>[/vc_column_text][vc_column_text rsclass="clean"]<p class="ch">They know that to make great music, you need great surroundings — a combination of top-notch gear, comfortable work and lounge areas, a relaxing setting, and knowledgeable, capable staff who can work with artists of any level. A place without distractions, yet accessible, where development is encouraged and prices aren’t prohibitive, but quality is<br class="hidden-xs hidden-sm hidden-md" />never sacrificed and clients are treated with respect.</p>[voicer_icon icon="icon-sign"][/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-6 mt-md-0 ch-block-welcome-right" width="1/2" rsclass="clean"][vc_column_text rsclass="clean"]<h2 class="heading heading-separator visible-xs mt-0 pt-0"><span class="ch">Welcome to Voicer</span></h2>[/vc_column_text][vc_single_image image="202" img_size="full" onclick="custom_link" img_link_target="_blank" rsclass="clean" link="#" el_class="ch-video-block"][vc_column_text rsclass="clean"]<div class="ch-video-block__btn ch-pulse"><a class="" href="//themeforest.net" target="_blank" rel="noopener noreferrer">[voicer_icon icon="icon-video-play"]</a></div>[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner rsclass="clean" el_class="banner-booking row"][vc_column_inner el_class="col-md-7 col-lg-8" width="1/2" rsclass="clean" rsinner="text-right text-xs-center text-sm-center"][vc_column_text rsclass="clean"]<h2 class="ch">Need a <span class="h-gradient">QUALITY</span> Sound?</h2><p class="p--lg color-invert">We deliver the very best service and amenities signed artists and independent musicians.</p>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-md-5 col-lg-4" width="1/2" rsclass="clean" rsinner="text-center"][vc_column_text rsclass="clean" el_class="btn-wrap"]<div class="ch"><a class="btn btn--white open-popup-link" href="#" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup">[voicer_icon icon="icon-mic"]book session now</a></div><p class="p--sm">And get a one recording hour for <span class="theme-color"><b>FREE</b></span>*</p>[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="form-popup mfp-with-anim" el_id="bookingPopup"][vc_column rsclass="clean" el_class="form-popup-inside mfp-inside"][vc_column_text rsclass="clean"]<div class="ch"><button class="close" aria-label="Close" data-dismiss="modal">[voicer_icon icon="icon-close"]</button></div>[/vc_column_text][vc_custom_heading text="Book Your Session" font_container="tag:h3|text_align:center" use_theme_fonts="yes"][contact-form-7 id="371"][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block block--darkbg block--full ch-block-rstudios ch-separator"][vc_column rsclass="clean"][vc_column_text rsclass="clean" el_class=" container title-wrap text-center color-invert font-n"]<h2 class="color-invert">Recording Studios</h2><p class="p--lg">The Voicer is a 2,000 square foot facility with 1 control room, 2 live <br class="hidden-xs" />rooms, and 1 vocal booth</p>[/vc_column_text][vc_row_inner rsclass="clean" el_class="studio-gallery ini-studio-gallery"][vc_column_inner el_class="studio-item" width="1/3" rsclass="clean"][vc_single_image image="170" img_size="full" rsclass="clean" el_class="studio-item-photo"][vc_column_text rsclass="clean"]<h4 class="studio-item-title"><span class="tt">Studio A</span> – Recording Studio</h4><p class="studio-item-info">Our 30m2 tracking room hosts a pristine Neve VR36 console with Flying Faders,<br class="hidden-xs hidden-sm" />ATC monitors, Prism ADA-8XR’s converters and a stunning rack of world class outboard.</p>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="studio-item" width="1/3" rsclass="clean"][vc_single_image image="171" img_size="full" rsclass="clean" el_class="studio-item-photo"][vc_column_text rsclass="clean"]<h4 class="studio-item-title"><span class="tt">Studio B</span> – Tracking Studio</h4><p class="studio-item-info">Our 30m2 tracking room hosts a pristine Neve VR36 console with Flying Faders,<br class="hidden-xs hidden-sm" />ATC monitors, Prism ADA-8XR’s converters and a stunning rack of world class outboard.</p>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="studio-item" width="1/3" rsclass="clean"][vc_single_image image="172" img_size="full" rsclass="clean" el_class="studio-item-photo"][vc_column_text rsclass="clean"]<h4 class="studio-item-title"><span class="tt">Studio C</span> – Mastering Studio</h4><p class="studio-item-info">Our 30m2 tracking room hosts a pristine Neve VR36 console with Flying Faders,<br class="hidden-xs hidden-sm" />ATC monitors, Prism ADA-8XR’s converters and a stunning rack of world class outboard.</p>[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block block--fullbg block--bgcover block-bg-projects ch-block-projects ch-separator"][vc_column rsclass="clean" el_class="container"][vc_column_text rsclass="clean" el_class="title-wrap text-center"]<h2 class="entry-title7 ">Our Projects</h2><p class="p--lg">We are very proud of our client base and the lasting relationships <br class="hidden-xs" />we have forged over many years.</p>[/vc_column_text][vc_row_inner rsclass="clean" el_class="project-slider ini-project-slider"][vc_column_inner el_class="project-item" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]<div class="project-item-photo popup-player-link open-popup-link" data-track="1" data-effect="mfp-zoom-in" data-mfp-src="#playerPopup"><img class="img-responsive alignnone wp-image-917 size-full" src="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/01.jpg" alt="Project Cover" /></div>[/vc_column_text][vc_column_text rsclass="clean"]<div class="project-item-title">American Girl</div><div class="project-item-author">Bonnie McKee</div>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="project-item" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]<div class="project-item-photo popup-player-link open-popup-link" data-track="2" data-effect="mfp-zoom-in" data-mfp-src="#playerPopup"><img class="img-responsive alignnone wp-image-917 size-full" src="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/02.jpg" alt="Project Cover" /></div>[/vc_column_text][vc_column_text rsclass="clean"]<div class="project-item-title">Into The Sun</div><div class="project-item-author">Robben Ford</div>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="project-item" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]<div class="project-item-photo popup-player-link open-popup-link" data-track="2" data-effect="mfp-zoom-in" data-mfp-src="#playerPopup"><img class="img-responsive alignnone wp-image-917 size-full" src="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/03.jpg" alt="Project Cover" /></div>[/vc_column_text][vc_column_text rsclass="clean"]<div class="project-item-title">Better Nature</div><div class="project-item-author">Silversun Pickups</div>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="project-item" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]<div class="project-item-photo popup-player-link open-popup-link" data-track="2" data-effect="mfp-zoom-in" data-mfp-src="#playerPopup"><img class="img-responsive alignnone wp-image-917 size-full" src="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/04_01.jpg" alt="Project Cover" /></div>[/vc_column_text][vc_column_text rsclass="clean"]<div class="project-item-title">I Don't Care</div><div class="project-item-author">Nicki J.</div>[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner rsclass="clean" el_class="wrapper-btn-border1-icon"][vc_column_inner el_class="text-center" rsclass="clean"][vc_column_text rsclass="clean"]<div class="ch"><a class="btn btn--border1" href="projects">[voicer_icon icon="icon-spectr"]view all projects</a></div>[/vc_column_text][vc_column_text rsclass="clean"][aw_player type="popup"]<ul id="playlist-3"> <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/3/01.mp3" data-artist="Artist Name" data-title="Track Title" data-thumb="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/01.jpg" data-download="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/01.mp3"></li> <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/02.mp3" data-artist="Artist Name" data-title="Track Title" data-thumb="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/02.jpg" data-download="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/1/02.mp3"></li> <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/03.mp3" data-artist="Artist Name" data-title="Track Title" data-thumb="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/03.jpg" data-download="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/1/03.mp3"></li> <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/04.mp3" data-artist="Artist Name" data-title="Track Title" data-thumb="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/04.jpg" data-download="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/1/04.mp3"></li> <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/05.mp3" data-artist="Artist Name" data-title="Track Title" data-thumb="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/3/05.jpg" data-download="http://websmirno.site/wp/dev/music/wp-content/themes/voicer/media/audio/1/05.mp3"></li></ul>[/aw_player][/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block block--fullbg block--bgcover block--darkbg block-bg-clients ch-block-clients ch-separator"][vc_column rsclass="clean" el_class="container"][vc_column_text rsclass="clean" el_class="text-center title-wrap"]<h2 class="color-white">Our Clients</h2><div class="cd-headline letters"><ul class="cd-words-wrapper"> <li class="is-visible">Michael Earle</li> <li>Ann Houston</li> <li>Natasha Ward</li> <li>Katie Dunnv</li> <li>Roger Hoehne</li> <li>Thomas Elliott</li> <li>Bobby Hodge</li> <li>Lisa Cook</li> <li>Nathalie Smith</li> <li>Ben Worrell</li> <li>Jane Wilcher</li> <li>Pauline Day</li> <li>Gabriel Chau</li> <li>Galen Martin</li></ul></div>[/vc_column_text][vc_row_inner rsclass="clean" el_class="row"][vc_column_inner el_class="col-sm-4 col-md-3" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]<ul class="clients-list"> <li>Michael Earle</li> <li>Michael Vazquez</li> <li>Matthew Duncan</li> <li>Rickey Campbell</li> <li>Jonathan Ku</li> <li>Theresa Ochoa</li> <li>Angela Hunley</li></ul>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4 col-md-3" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]<ul class="clients-list"> <li>Beverly Pleasants</li> <li>Louis Shay</li> <li>Stephen Rivers</li> <li>Alan Doody</li> <li>Betty Cochran</li> <li>Marlene Fowler</li> <li>Lois Olson</li></ul>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4 col-md-3" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]<ul class="clients-list"> <li>Dorothy Riddle</li> <li>Katie Dunnv</li> <li>Roger Hoehne</li> <li>Thomas Elliott</li> <li>Bobby Hodge</li> <li>Ashley Greene</li> <li>Dorothy Shepherd</li></ul>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4 col-md-3" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]<ul class="clients-list"> <li>Theresa Blanding</li> <li>George Norsworthy</li> <li>Nathalie Smith</li> <li>Ben Worrell</li> <li>Jane Wilcher</li> <li>Pena</li> <li>Orville Thompson</li></ul>[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_column_text rsclass="clean" el_class="text-center offset-30 visible-xs visible-sm"]<div class="tt"><a class="btn btn--border1" href="#" data-show-sm="collapse-clients">[voicer_icon icon="icon-spectr"]view all clients</a></div>[/vc_column_text][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block ch-block-news bg-pages bg-home-latest-news"][vc_column rsclass="clean" el_class="container"][vc_column_text rsclass="clean" el_class="title-wrap text-center"]<h2 class="entry-title7 ">Latest News</h2><p class="p--lg">Find out about everything happening here at Voicer. Keep an eye out<br class="hidden-xs" />here for all of our upcoming events</p>[/vc_column_text][vc_row_inner el_class="row news-slider ini-news-slider-mobile tt-block-news" rsclass="clean"][vc_column_inner el_class="col-sm-4 news-item" width="1/3" rsclass="clean" rsinner="news-item-inside"][vc_single_image image="173" img_size="full" onclick="custom_link" img_link_target="_blank" rsclass="clean" link="the-voicer-in-la-times/" el_class="news-item-photo"][vc_column_text rsclass="clean"]<div class="news-item-date">[voicer_icon icon="icon-time"]10.10.2017</div><h5 class="news-item-title"><a href="about"><strong class="ch">Recording Checklist for Bands/Artists</strong></a></h5><p class="ch">We are always trying to help out bands and artists get a great sounding...</p><div class="wrapper-btn-link-icon-text"><a class="link-icon-text" href="blog-page">[voicer_icon icon="icon-video-play"]read more</a></div>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4 news-item" width="1/3" rsclass="clean" rsinner="news-item-inside"][vc_single_image image="174" img_size="full" onclick="custom_link" img_link_target="_blank" rsclass="clean" link="the-voicer-in-la-times/" el_class="news-item-photo"][vc_column_text rsclass="clean"]<div class="news-item-date">[voicer_icon icon="icon-time"]10.10.2017</div><h5 class="news-item-title"><a href="about"><strong class="ch">Spitfire on a Roll With New Orchestral</strong></a></h5><p class="ch">The final parts of Spitfire's Studio Orchestra Library are released...</p><div class="wrapper-btn-link-icon-text"><a class="link-icon-text" href="blog-page">[voicer_icon icon="icon-video-play"]read more</a></div>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4 news-item" width="1/3" rsclass="clean" rsinner="news-item-inside"][vc_single_image image="175" img_size="full" onclick="custom_link" img_link_target="_blank" rsclass="clean" link="the-voicer-in-la-times/" el_class="news-item-photo"][vc_column_text rsclass="clean"]<div class="news-item-date">[voicer_icon icon="icon-time"]10.10.2017</div><h5 class="news-item-title"><a href="about"><strong class="ch">Roger Mayer Updates Classic Mastering </strong></a></h5><p class="ch">Respected electronics engineer Roger Mayer updates his much-loved RM58...</p><div class="wrapper-btn-link-icon-text"><a class="link-icon-text" href="blog-page">[voicer_icon icon="icon-video-play"]read more</a></div>[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block block--darkbg block--fullbg ch-block-reviews ch-separator"][vc_column rsclass="clean" el_class="container"][vc_column_text rsclass="clean" el_class="title-wrap"]<h2 class="heading heading-separator hidden visible-xs"><span class="ch">What Voicer Customers Say</span></h2>[/vc_column_text][vc_row_inner rsclass="clean" el_class="reviews-slider-2 ini-reviews-slider"][vc_column_inner el_class="review-item" width="1/3" rsclass="clean"][vc_column_text rsclass="clean" el_class="review-item-content"]<h2 class="heading heading-separator hidden-xs"><span class="ch">What Voicer Customers Say</span></h2><p class="p--lg color-invert review-item-text">The products I have produced with their help have been accounted outstanding, both in terms of music and graphics. I recommend Voicer unreservedly and unqualifiedly.</p><p class="p--md theme-color review-item-author-name">- Ida A. Wakefield</p>[/vc_column_text][vc_single_image image="176" img_size="full" rsclass="clean" el_class="review-item-author-photo"][/vc_column_inner][vc_column_inner el_class="review-item" width="1/3" rsclass="clean"][vc_column_text rsclass="clean" el_class="review-item-content"]<h2 class="heading heading-separator hidden-xs"><span class="ch">What Voicer Customers Say</span></h2><p class="p--lg color-invert review-item-text">My first initial session to record a demo for my publisher was meant to be a one-off. I was so impressed with the standard and level of service that I went back to record songs</p><p class="p--md theme-color review-item-author-name">- Ida A. Wakefield</p>[/vc_column_text][vc_single_image image="176" img_size="full" rsclass="clean" el_class="review-item-author-photo"][/vc_column_inner][vc_column_inner el_class="review-item" width="1/3" rsclass="clean"][vc_column_text rsclass="clean" el_class="review-item-content"]<h2 class="heading heading-separator hidden-xs"><span class="ch">What Voicer Customers Say</span></h2><p class="p--lg color-invert review-item-text">I wanted to drop you a brief but sincere couple of lines of thanks for all the hard work you put into making the music &amp; sound behind Economy Gastronomy such a success. Despite having a brief thrown</p><p class="p--md theme-color review-item-author-name">- Ida A. Wakefield</p>[/vc_column_text][vc_single_image image="176" img_size="full" rsclass="clean" el_class="review-item-author-photo"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block block--fullbg block--bgcover block-bg-engineer ch-separator"][vc_column rsclass="clean" el_class="container"][vc_column_text rsclass="clean" el_class="title-wrap text-center"]<h2 class="entry-title7 ">Our Engineers</h2><p class="p--lg">At Voicer we believe that the calibre of your engineers &amp; producers <br class="hidden-xs" />is just as important as the quality of the studio you work in</p>[/vc_column_text][vc_row_inner rsclass="clean" el_class="row team-grid ini-team-slider-mobile"][vc_column_inner el_class="col-sm-6 col-lg-4 team-member" width="1/6" rsclass="clean" rsinner="team-member-inside"][vc_column_text rsclass="clean" el_class="team-member-info"]<h4 class="team-member-name">Bryan Johnson</h4><p class="team-member-position">Engineer / Owner</p><div class="wrapper-btn-link-icon-text"><div class="wrapper-btn-link-icon-text"><a class="link-icon-text" href="blog-page">[voicer_icon icon="icon-video-play"]know more</a></div></div>[/vc_column_text][vc_single_image image="353" img_size="full" rsclass="clean" el_class="team-member-photo"][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-lg-4 team-member" width="1/6" rsclass="clean" rsinner="team-member-inside"][vc_column_text rsclass="clean" el_class="team-member-info"]<h4 class="team-member-name">Linda Thomas</h4><p class="team-member-position">Engineer / Owner</p><div class="wrapper-btn-link-icon-text"><div class="wrapper-btn-link-icon-text"><a class="link-icon-text" href="blog-page">[voicer_icon icon="icon-video-play"]know more</a></div></div>[/vc_column_text][vc_single_image image="178" img_size="full" rsclass="clean" el_class="team-member-photo"][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-lg-4 team-member" width="1/6" rsclass="clean" rsinner="team-member-inside"][vc_column_text rsclass="clean" el_class="team-member-info"]<h4 class="team-member-name">Jessie Ramirez</h4><p class="team-member-position">Engineer</p><div class="wrapper-btn-link-icon-text"><div class="wrapper-btn-link-icon-text"><a class="link-icon-text" href="blog-page">[voicer_icon icon="icon-video-play"]know more</a></div></div>[/vc_column_text][vc_single_image image="179" img_size="full" rsclass="clean" el_class="team-member-photo"][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-lg-4 team-member" width="1/6" rsclass="clean" rsinner="team-member-inside"][vc_column_text rsclass="clean" el_class="team-member-info"]<h4 class="team-member-name">David Reyna</h4><p class="team-member-position">Producer</p><div class="wrapper-btn-link-icon-text"><div class="wrapper-btn-link-icon-text"><a class="link-icon-text" href="blog-page">[voicer_icon icon="icon-video-play"]know more</a></div></div>[/vc_column_text][vc_single_image image="180" img_size="full" rsclass="clean" el_class="team-member-photo"][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-lg-4 team-member" width="1/6" rsclass="clean" rsinner="team-member-inside"][vc_column_text rsclass="clean" el_class="team-member-info"]<h4 class="team-member-name">Michael Hadlock</h4><p class="team-member-position">Engineer</p><div class="wrapper-btn-link-icon-text"><div class="wrapper-btn-link-icon-text"><a class="link-icon-text" href="blog-page">[voicer_icon icon="icon-video-play"]know more</a></div></div>[/vc_column_text][vc_single_image image="181" img_size="full" rsclass="clean" el_class="team-member-photo"][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-lg-4 team-member" width="1/6" rsclass="clean" rsinner="team-member-inside"][vc_column_text rsclass="clean" el_class="team-member-info"]<h4 class="team-member-name">Evelyn Schultz</h4><p class="team-member-position">Producer</p><div class="wrapper-btn-link-icon-text"><div class="wrapper-btn-link-icon-text"><a class="link-icon-text" href="blog-page">[voicer_icon icon="icon-video-play"]know more</a></div></div>[/vc_column_text][vc_single_image image="182" img_size="full" rsclass="clean" el_class="team-member-photo"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block block--darkbg bottom-null block--full ch-block-inst ch-separator"][vc_column rsclass="clean"][vc_column_text rsclass="clean" el_class="title-wrap text-center"]<h2 class="ch">Instagram <span class="theme-color">@Voicer</span></h2>[/vc_column_text][voicer_instagram_element access_token="8334873284.47cde00.1682e1c3d5614f3c95d0a4d68474d953" limit="16" el_class="ch-instagram-grid instagram-grid-full"][vc_column_text rsclass="clean" el_class="text-center btn-wrapper visible-xs visible-sm"]<div class="tt"><a class="btn btn--border1" href="#" data-show-sm="collapse-clients">[voicer_icon icon="icon-spectr"]more photos</a></div>[/vc_column_text][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block ch-block-booking ch-separator"][vc_column rsclass="clean" el_class="container"][vc_column_text rsclass="clean" el_class="title-wrap text-center"]<h2 class="entry-title7 ">Booking</h2><p class="p--lg">Select your session and book online instantly. If you have any<br class="hidden-xs" />questions, you give us a call or email us</p>[/vc_column_text][vc_row_inner rsclass="clean" el_class="row tt-booking-blocks"][vc_column_inner el_class="col-sm-4 booking-block" width="1/3" rsclass="clean"][vc_column_text rsclass="clean"]<div class="tt"><div class="booking-link open-popup-link" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup"><div class="booking-link-inside"><h4 class="booking-link-title">[voicer_icon icon="icon-equalizer1"]Book Engineer Session</h4><div class="booking-link-price">from <span class="tt"><strong class="tt">$95 / hour</strong></span></div></div></div></div>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4 booking-block" width="1/3" rsclass="clean"][vc_column_text rsclass="clean"]<div class="tt"><div class="booking-link open-popup-link" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup"><div class="booking-link-inside"><h4 class="booking-link-title">[voicer_icon icon="icon-notes"]Book Producer Session</h4><div class="booking-link-price">from <span class="tt"><strong class="tt">$195 / hour</strong></span></div></div></div></div>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4 booking-block" width="1/3" rsclass="clean"][vc_column_text rsclass="clean"]<div class="tt"><div class="booking-link open-popup-link" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup"><div class="booking-link-inside"><h4 class="booking-link-title">[voicer_icon icon="icon-megaphone"]Book Assistant Session</h4><div class="booking-link-price">from <span class="tt"><strong class="tt">$75 / hour</strong></span></div></div></div></div>[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]




<!--page About Us-->
<p>[vc_row rsclass="clean" el_class="block block-about-welcome pb-0 bg-page bg-page-about1"][vc_column el_class="container" rsclass="clean"][vc_row_inner rsclass="clean" el_class="row"][vc_column_inner el_class="col-md-6 text-center" width="5/12" rsclass="clean"][vc_single_image image="450" img_size="full" rsclass="clean" el_class="img-responsive pt-4"][/vc_column_inner][vc_column_inner el_class="divider visible-xs visible-sm" width="1/12" rsclass="clean"][/vc_column_inner][vc_column_inner el_class="col-md-6" width="1/2" rsclass="clean"][vc_column_text rsclass="clean"]</p>
<h2 class="heading heading-separator"><span class="ch">We are the brainchild of musicians</span></h2>
<p>[/vc_column_text][vc_column_text rsclass="clean"]</p>
<p class="p--lg">Voicer Recording Studio is a full service recording studio, owned and operated by Grammy award winning mixer John Smith.</p>
<p class="ch">Voicer Recording Studio has three fully equipped studios, with a spacious tracking room, iso rooms, and a world class blend of state of the art and vintage gear. Our dedicated staff of engineers offers recording, mixing, mastering, post-production, ISDN, transfers, mobile recording, live sound, video production, and even small scale cd-manufacturing with print.</p>
<p class="ch">Our studios are equipped to handle your project from beginning to end. We have top notch trained musicians at our fingertips, so if your music is lacking that extra edge, we can maximize sound to the fullest.</p>
<p>[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner rsclass="clean" el_class="row offset-80 icn-text-slider ini-icn-text-slider"][vc_column_inner el_class="col-sm-4" width="1/3" rsclass="clean" rsinner="icn-txt-box-icon icn-txt-box--style2"][vc_column_text rsclass="clean"]</p>
<div class="icn-txt-box-icon icn-txt-box-icon-bg bg-01">[voicer_icon icon="icon-mission"]</div>
<div class="icn-txt-box-text">
    <h4 class="ch"><strong class="ch">Our Mission</strong></h4>
    <p class="tt">To make your recording experience and music needs an easy one by using all resources available to fine tune the abilities of the local artists and musicians.</p>
</div>
<p>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4" width="1/3" rsclass="clean" rsinner="icn-txt-box icn-txt-box--style2"][vc_column_text rsclass="clean"]</p>
<div class="icn-txt-box-icon icn-txt-box-icon-bg bg-02">[voicer_icon icon="icon-vision"]</div>
<div class="icn-txt-box-text">
    <h4 class="ch"><strong class="ch">Our Vision</strong></h4>
    <p class="tt">Is to go beyond standard remit of a sound recording studio and to become a creative hub where artists, bands, songwriters, musicians and producers can realize their sonic potential.</p>
</div>
<p>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4" width="1/3" rsclass="clean" rsinner="icn-txt-box icn-txt-box--style2"][vc_column_text rsclass="clean"]</p>
<div class="icn-txt-box-icon icn-txt-box-icon-bg bg-03">[voicer_icon icon="icon-corevalues"]</div>
<div class="icn-txt-box-text">
    <h4 class="ch"><strong class="ch">Core Values</strong></h4>
    <ul class="circle-list">
        <li>The artist is at the center of the process</li>
        <li>The past inspires invention and innovation</li>
        <li>Experimentation requires artistic rigor and risk</li>
        <li>Collaboration activates growth</li>
    </ul>
</div>
<p>[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block pt-9 half-block-carousel pb-0" rsinner=""][vc_column rsclass="clean" el_class="projects--grid"][vc_row_inner rsclass="clean"][vc_column_inner el_class="title-wrap text-center" rsclass="clean"][vc_custom_heading text="Recording Studios" font_container="tag:h2|text_align:center" use_theme_fonts="yes"][vc_column_text rsclass="clean"]</p>
<p class="p--lg container">The Voicer is a 2,000 square foot facility with 1 control room, 2 live<br class="hidden-xs hidden-sm hidden-md" />rooms, and 1 vocal booth</p>
<p>[/vc_column_text][vc_column_text rsclass="clean"]</p>
<div class="ch">
    <ul class="filtr-row text-center">
        <li class="active" data-filter="1"><span class="ch">Stuido A</span></li>
        <li data-filter="2"><span class="ch">Studio B</span></li>
        <li data-filter="3"><span class="ch">Studio C</span></li>
    </ul>
</div>
<p>[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner el_class="row row--half bg-grey" rsclass="clean" el_id="row-id-test"][vc_column_inner el_class="half-bg-left block-bg-vc-01" width="1/2" rsclass="clean" css=".vc_custom_1507816911774{background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}"][/vc_column_inner][vc_column_inner el_class="col-sm-6 pull-right" width="1/2" rsclass="clean"][vc_column_text rsclass="clean"]</p>
<h4 class="color-white"><strong class="theme-color">Studio A</strong><strong class="ch"> - Mixing Studio</strong></h4>
<p class="ch">Voicer Studio A is a state-of-the-art music and post production studio with a large control room and a live tracking room. Equipped with a D-Control ICON, Pro Tools HDX, Tannoy System 215 DMT II mains, a multitude of new and vintage outboard gear, as well as a 110" retractable projection screen, 7.1 surround sound, and full HDMI routing capabilities, Studio A is suitable for any session.</p>
<p class="ch">Designed and tuned by the famed George Augspurger, Studio A is<br />
    great for any type of audio work.</p>
<p>[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block bg-page bg-page-about2"][vc_column rsclass="clean" el_class="container"][vc_column_text rsclass="clean" el_class="title-wrap text-center"]</p>
<h2 class="ch">Our History</h2>
<p class="p--lg">Our studio gained popularity for having the best drum sound<br class="hidden-xs hidden-sm hidden-md" />and became home to many of the nations top acts</p>
<p>[/vc_column_text][vc_row_inner rsclass="clean" el_class="timeline"][vc_column_inner el_class="timeline-left" width="1/2" rsclass="clean"][vc_column_text rsclass="clean"]</p>
<div class="timeline-item">
    <div class="timeline-item-date">October 2015</div>
    <h4 class="timeline-item-title">Ten years of recording, producing, mixing and mastering</h4>
    <div class="timeline-item-text">Construction of a sister studio, on the Voicer Recording Studio, began in the mid 1990’s attracting major artists from around the globe. Sadly, Hurricane Hugo devastated the island in 1989, and the studio was forced to close.</div>
</div>
<p>[/vc_column_text][vc_column_text rsclass="clean"]</p>
<div class="timeline-item">
    <div class="timeline-item-date">October 2015</div>
    <h4 class="timeline-item-title">voicer recording studio</h4>
    <div class="timeline-item-photo"><img class="img-responsive alignnone wp-image-455 size-full" src="http://websmirno.site/wp/dev/music/wp-content/uploads/2019/05/history1.jpg" alt="" width="940" height="419" /></div>
    <div class="timeline-item-text">Construction of a sister studio, on the Voicer Recording Studio, began in the mid 1990’s attracting major artists.</div>
</div>
<p>[/vc_column_text][vc_column_text rsclass="clean"]</p>
<div class="timeline-item">
    <div class="timeline-item-date">May 2016</div>
    <h4 class="timeline-item-title">Ten years of recording, producing, mixing and mastering</h4>
    <div class="timeline-item-photo"><img class="img-responsive alignnone wp-image-456 size-full" src="http://websmirno.site/wp/dev/music/wp-content/uploads/2019/05/history2.jpg" alt="" width="940" height="419" /></div>
    <div class="timeline-item-text">Construction of a sister studio, on the Voicer Recording Studio, began in the mid 1990’s attracting major artists from around the globe. Sadly, Hurricane Hugo devastated the island in 1989, and the studio was forced to close.</div>
</div>
<p>[/vc_column_text][vc_column_text rsclass="clean"]</p>
<div class="timeline-item">
    <div class="timeline-item-date">May2017</div>
    <h4 class="timeline-item-title">Ten years of recording, producing, mixing and mastering</h4>
    <div class="timeline-item-text">Construction of a sister studio, on the Voicer Recording Studio, began in the mid 1990’s attracting major artists from around the globe. Sadly, Hurricane Hugo devastated the island in 1989, and the studio was forced to close.</div>
</div>
<p>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="timeline-right" width="1/2" rsclass="clean"][vc_column_text rsclass="clean"]</p>
<div class="timeline-item">
    <div class="timeline-item-date">OCTOBER 2015</div>
    <h5 class="timeline-item-title text-uppercase">ten years of recording, producing, mixing and mastering,</h5>
    <div class="timeline-item-text">Construction of a sister studio, on the Voicer Recording Studio, began in the mid 1990's attracting major artists from around the globe. Sadly, Hurricane Hugo devastated the island in 1989, and the studio was forced to close.</div>
</div>
<p>[/vc_column_text][vc_column_text rsclass="clean"]</p>
<div class="timeline-item">
    <div class="timeline-item-date">December 2015</div>
    <h4 class="timeline-item-title">Voicer Recording Studio</h4>
    <div class="timeline-item-photo"><img class="img-responsive alignnone wp-image-455 size-full" src="http://websmirno.site/wp/dev/music/wp-content/uploads/2019/05/history1.jpg" alt="" width="940" height="419" /></div>
    <div class="timeline-item-text">Construction of a sister studio, on the Voicer Recording Studio, began in the mid 1990’s attracting major artists.</div>
</div>
<p>[/vc_column_text][vc_column_text rsclass="clean"]</p>
<div class="timeline-item">
    <div class="timeline-item-date">March 2015</div>
    <h4 class="timeline-item-title">Ten years of recording, producing, mixing and mastering</h4>
    <div class="timeline-item-photo"><img class="img-responsive alignnone wp-image-456 size-full" src="http://websmirno.site/wp/dev/music/wp-content/uploads/2019/05/history2.jpg" alt="" width="940" height="419" /></div>
    <div class="timeline-item-text">Construction of a sister studio, on the Voicer Recording Studio, began in the mid 1990’s attracting major artists from around the globe. Sadly, Hurricane Hugo devastated the island in 1989, and the studio was forced to close.</div>
</div>
<p>[/vc_column_text][vc_column_text rsclass="clean"]</p>
<div class="timeline-item">
    <div class="timeline-item-date">March 2017</div>
    <h4 class="timeline-item-title">Ten years of recording, producing, mixing and mastering</h4>
    <div class="timeline-item-text">Construction of a sister studio, on the Voicer Recording Studio, began in the mid 1990’s attracting major artists from around the globe. Sadly, Hurricane Hugo devastated the island in 1989, and the studio was forced to close.</div>
</div>
<p>[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block block--darkbg block--fullbg block--bgcover ch-separator block-bg-wanttorecord block-border-gradient"][vc_column rsclass="clean" el_class="container"][vc_row_inner rsclass="clean" el_class="title-wrap text-center mb-0"][vc_column_inner rsclass="clean"][vc_custom_heading text="Want to Record Your Own Hit?" font_container="tag:h2|text_align:center" use_theme_fonts="yes"][vc_custom_heading text="We are a full service studio featuring the latest technology for our all your projects." font_container="tag:p|text_align:center" use_theme_fonts="yes" el_class="p--lg"][/vc_column_inner][/vc_row_inner][vc_column_text rsclass="clean"]</p>
<h3 class="phone-lg text-center">[voicer_icon icon="icon-phone"]1-800-765-43-21</h3>
<p>[/vc_column_text][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block block--fullbg block--bgcover block-bg-team ch-separator"][vc_column rsclass="clean" el_class="container title-wrap"][vc_custom_heading text="Our Team" font_container="tag:h2|text_align:center" use_theme_fonts="yes"][vc_column_text rsclass="clean" el_class="text-center"]</p>
<p class="p--lg">At Voicer we believe that the calibre of your engineers &amp; producers<br class="hidden-xs hidden-sm hidden-md" />is just as important as the quality of the studio you work in</p>
<p>[/vc_column_text][vc_row_inner rsclass="clean" el_class="row team-grid ini-team-slider team-grid-nolink"][vc_column_inner el_class="col-sm-6 col-lg-4 team-member" width="1/3" rsclass="clean"][vc_hoverbox image="427" shape="square" reverse="true" rsclass="clean" rsiclass="team-member-photo" rstclass="team-member-info" el_class="team-member-inside"]</p>
<h4 class="team-member-name"><a href="#">Bryan Johnson</a></h4>
<p class="team-member-position">Engineer / Owner</p>
<p>[/vc_hoverbox][vc_column_text rsclass="clean"]</p>
<p class="team-member-text">Bryan began working as a freelance engineer, working in small project studios. In 2009, he obtained a degree in Audio Engineering and Production.</p>
<p>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-lg-4 team-member" width="1/3" rsclass="clean"][vc_hoverbox image="442" shape="square" reverse="true" rsclass="clean" rsiclass="team-member-photo" rstclass="team-member-info" el_class="team-member-inside"]</p>
<h4 class="team-member-name"><a href="#">Linda Thomas</a></h4>
<p class="team-member-position">Engineer / Owner</p>
<p>[/vc_hoverbox][vc_column_text rsclass="clean"]</p>
<p class="team-member-text">Linda began his musical career at an early age. In 2017 she further pursued his interest in music acquiring a formal degree in Audio Engineering.</p>
<p>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-lg-4 team-member" width="1/3" rsclass="clean"][vc_hoverbox image="443" shape="square" reverse="true" rsclass="clean" rsiclass="team-member-photo" rstclass="team-member-info" el_class="team-member-inside"]</p>
<h4 class="team-member-name"><a href="#">Jessie Ramirez</a></h4>
<p class="team-member-position">Engineer</p>
<p>[/vc_hoverbox][vc_column_text rsclass="clean"]</p>
<p class="team-member-text">In school he began building experience as an engineer by doing live sound for local concert series and recording solo artists and groups.</p>
<p>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-lg-4 team-member" width="1/3" rsclass="clean"][vc_hoverbox image="427" shape="square" reverse="true" rsclass="clean" rsiclass="team-member-photo" rstclass="team-member-info" el_class="team-member-inside"]</p>
<h4 class="team-member-name"><a href="#">Bryan Johnson</a></h4>
<p class="team-member-position">Engineer / Owner</p>
<p>[/vc_hoverbox][vc_column_text rsclass="clean"]</p>
<p class="team-member-text">Bryan began working as a freelance engineer, working in small project studios. In 2009, he obtained a degree in Audio Engineering and Production.</p>
<p>[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_column_text rsclass="clean" el_class="pt-9"]</p>
<h3 class="heading heading-separator"><span class="ch">Our Engineers</span></h3>
<p>[/vc_column_text][vc_row_inner rsclass="clean" el_class="row ch-eng-list-wide"][vc_column_inner el_class="col-xs-6 col-sm-3" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]</p>
<p class="ch"><a href="#">Michael Earle</a><br class="ch" /><a href="#">Michael Vazquez</a><br class="ch" /><a href="#">Matthew Duncan</a><br class="ch" /><a href="#">Rickey Campbell</a></p>
<p>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-xs-6 col-sm-3" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]</p>
<p class="ch"><a href="#">Jonathan Ku</a><br class="ch" /><a href="#">Theresa Ochoa</a><br class="ch" /><a href="#">Angela Hunley</a><br class="ch" /><a href="#">Colin Christopher</a></p>
<p>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-xs-6 col-sm-3" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]</p>
<p class="ch"><a href="#">Stephanie Davis</a><br class="ch" /><a href="#">Robert M. Sroka</a><br class="ch" /><a href="#">Ivan Salinas</a><br class="ch" /><a href="#">Dorothy Shepherd</a></p>
<p>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-xs-6 col-sm-3" width="1/4" rsclass="clean"][vc_column_text rsclass="clean"]</p>
<p class="ch"><a href="#">Lisa N. Cook</a><br class="ch" /><a href="#">Pauline Day</a><br class="ch" /><a href="#">Gabriel Chau</a><br class="ch" /><a href="#">Galen Martin</a></p>
<p>[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]</p>

<!--about us-->

<!--page Equipment-->
[vc_row rsclass="clean" el_class="block pt-0"][vc_column el_class="container" rsclass="clean"][vc_row_inner rsclass="clean" el_class="row"][vc_column_inner el_class="half-bg-left" width="1/2" rsclass="clean"][vc_single_image image="588" img_size="full" rsclass="clean" el_class="img-responsive"][/vc_column_inner][vc_column_inner el_class="col-sm-6 pull-right equipment-block-top-right-part" width="1/2" rsclass="clean"][vc_column_text rsclass="clean"]
<h2 class="heading heading-separator"><span class="ch">What We Use for<br class="ch" />Perfect Sound</span></h2>
[/vc_column_text][vc_column_text rsclass="clean"]
<p class="p--lg"><strong class="ch">Voicer Recording Studio offer clients an endless choice of great recording studio equipment</strong></p>
<p class="ch">To get a more comprehensive idea of the gear found in Voicer Studio, please see below for our full recording studio equipment list. Every piece of equipment we own can be found here on this list, and we update it regularly for new additions (we're always adapting to shifting musical landscape).</p>
<p class="ch">Whether you’re looking for a specific vintage ribbon mic or a rare 70's compressor, we hope this list gives you some clarification. If you like what you see, please get in touch to book in some studio time with Voicer.</p>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block7 bottom-null block--darkbg"][vc_column rsclass="clean" el_class="container"][vc_row_inner rsclass="clean" el_class="row row--half"][vc_column_inner el_class="half-bg-right block-bg-vc-eq-1" width="1/2" rsclass="clean"][/vc_column_inner][vc_column_inner el_class="col-sm-6" width="1/2" rsclass="clean"][vc_custom_heading text="Microphones" font_container="tag:h3|text_align:left" use_theme_fonts="yes"][vc_column_text rsclass="clean"]
<ul class="circle-list-md">
    <li>Neumann Tlm 102</li>
    <li>Se Electronics 4400a (2 pieces)</li>
    <li>Blue Baby Bottle</li>
    <li>AKG C451 (Stereoset)</li>
    <li>Golden Age R1 (2 pieces)</li>
    <li>Electrovoice RE20</li>
    <li>Senheisser MD421 (3 pieces)</li>
    <li>Senheisser E902</li>
    <li>Shure Beta 91A</li>
</ul>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block pt-0 bottom-null"][vc_column rsclass="clean" el_class="container"][vc_row_inner rsclass="clean" el_class="row row--half block--half__list"][vc_column_inner el_class="half-bg-left block-bg-vc-eq-2" width="1/2" rsclass="clean"][/vc_column_inner][vc_column_inner el_class="col-sm-6 pull-right" width="1/2" rsclass="clean"][vc_custom_heading text="Preamps / Channel Strips" font_container="tag:h3|text_align:left" use_theme_fonts="yes"][vc_column_text rsclass="clean"]
<ul class="circle-list-md">
    <li>A-Designs Pacifica (2 channels)</li>
    <li>Universal Audio 4-710 twinfinity / 1176 style comp</li>
    <li>Golden Age Pre73/comp54 (2 channels)</li>
    <li>Joemeek Twin Q /comp/EQ (2 channels)</li>
    <li>Audient asp 880 (8 channels)</li>
    <li>Rme ff800 (4 channels)</li>
    <li>Focusrite Saffire pro 40 (8 channels)</li>
    <li>Focusrite Octopre (8 channels)</li>
    <li>Soundcraft M8 console (8 Channels)</li>
</ul>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block pt-0 bottom-null"][vc_column rsclass="clean" el_class="container"][vc_row_inner rsclass="clean" el_class="row row--half block--half__list"][vc_column_inner el_class="half-bg-right block-bg-vc-eq-3" width="1/2" rsclass="clean"][/vc_column_inner][vc_column_inner el_class="col-sm-6 pull-left" width="1/2" rsclass="clean"][vc_custom_heading text="Monitoring" font_container="tag:h3|text_align:left" use_theme_fonts="yes"][vc_column_text rsclass="clean"]
<ul class="circle-list-md">
    <li>Focal Solo 6 + Sub ( Control Room A)</li>
    <li>Dangerous Music Monitor ST (Control Room A)</li>
    <li>Focal Alpha 50 (Control Room B)</li>
    <li>Avantone mixcubes (Control Room A)</li>
    <li>Yamaha NSF 150 (Control Room A)</li>
    <li>Shure SE315 in ear monitoring</li>
    <li>Senheiser HD 215 (2 pieces)</li>
    <li>AKG K44 (2 pieces)</li>
</ul>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block pt-0 bottom-null"][vc_column rsclass="clean" el_class="container"][vc_row_inner rsclass="clean" el_class="row row--half block--half__list"][vc_column_inner el_class="half-bg-left block-bg-vc-eq-4" width="1/2" rsclass="clean"][/vc_column_inner][vc_column_inner el_class="col-sm-6 pull-right" width="1/2" rsclass="clean"][vc_custom_heading text="Daw / Digital interface" font_container="tag:h3|text_align:left" use_theme_fonts="yes"][vc_column_text rsclass="clean"]
<ul class="circle-list-md">
    <li>Mac Pro 8 core (Control Room A)</li>
    <li>Imac 27′ I7 (Control Room B)</li>
    <li>RME Fireface 800 (Control Room A)</li>
    <li>24 Channels Mackie MCU Pro</li>
    <li>Logic Pro X, Cubase 8, Protools 10</li>
    <li>Native Instruments Kontakt Komplete Ultimate</li>
    <li>Softube Console 1</li>
    <li>Softube All plugins</li>
    <li>Soundtoys All plugins and numerous other plugins</li>
</ul>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block7 bottom-null block--darkbg"][vc_column rsclass="clean" el_class="container"][vc_row_inner rsclass="clean" el_class="row row--half"][vc_column_inner el_class="half-bg-right block-bg-vc-eq-5" width="1/2" rsclass="clean"][/vc_column_inner][vc_column_inner el_class="col-sm-6" width="1/2" rsclass="clean"][vc_custom_heading text="Guitar and Bass Amps" font_container="tag:h3|text_align:left" use_theme_fonts="yes"][vc_column_text rsclass="clean"]
<ul class="circle-list-md">
    <li>Diezel Einstein 100 Watt</li>
    <li>Marshall JCM 2000</li>
    <li>Supro 1624 Dualtone 24 Watt (combo)</li>
    <li>Peavey 6505 100 Watt</li>
    <li>Kourbis Custom Plexi Amp 50 Watt</li>
    <li>B-52 100 Watt</li>
    <li>Orange Tiny Terror 15 Watt</li>
    <li>Bugera 333 100 Watt (combo)</li>
    <li>Gallien Krueger 700 RB 2 480 watt</li>
</ul>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block ch-separator"][vc_column rsclass="clean" el_class="title-wrap text-center" rsinner="container"][vc_column_text rsclass="clean"]
<h2 class="heading"><span class="ch">Need Music Marketing &amp; Promotion?</span></h2>
[/vc_column_text][vc_column_text rsclass="clean"]
<p class="p--lg mb-0"><strong class="ch">Your Passion for Excellence Inspires &amp; Motivates Us</strong></p>
[/vc_column_text][vc_column_text rsclass="clean"]
<div class="price-box-btn"><a class="btn btn--border1 open-popup-link" href="#" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup">[voicer_icon icon="icon-mic"]book session now</a></div>
[/vc_column_text][/vc_column][/vc_row][vc_row rsclass="clean" el_class="form-popup mfp-with-anim" el_id="bookingPopup"][vc_column rsclass="clean" el_class="form-popup-inside mfp-inside"][vc_column_text rsclass="clean"]
<div class="ch"><button class="close" aria-label="Close" data-dismiss="modal">[voicer_icon icon="icon-close"]</button></div>
[/vc_column_text][vc_custom_heading text="Book Your Session" font_container="tag:h3|text_align:center" use_theme_fonts="yes"][contact-form-7 id="371"][/vc_column][/vc_row]



<!--page Projects-->
[vc_row rsclass="clean"][vc_column rsclass="clean" el_class="block inset-120 pb-0" rsinner="container"][vc_row_inner el_class="row" rsclass="clean"][vc_column_inner el_class="col-sm-6" width="1/2" rsclass="clean"][vc_column_text rsclass="clean" el_class="title-wrap"]
<h2 class="heading heading-separator"><span class="ch">Latest Projects</span></h2>
<p class="p--lg"><strong class="ch">The Voicer is the brainchild of musicians who understand<br class="hidden-xs hidden-sm hidden-md" />that the best art comesfrom the best environment</strong></p>
<p class="ch">They know that to make great music, you need great surroundings — a combination of top-notch gear, comfortable work and lounge areas, a relaxing setting, and knowledgeable, capable staff who can work with artists of any level. A place without distractions, yet accessible, where development is encouraged and prices aren’t prohibitive, but quality is<br class="hidden-xs hidden-sm hidden-md" />never sacrificed and clients are treated with respect.</p>
[/vc_column_text][vc_gallery type="image_grid" images="838,839,840,841,842,843,844,845,846,847" img_size="full" onclick="" el_class="projects-image-gallery"][/vc_column_inner][vc_column_inner el_class="col-sm-6" width="1/2" rsclass="clean" rsinner="awp-player-bg dark--bg"][vc_column_text rsclass="clean"][aw_player type="projects"]
<ul id="playlist-1">
    <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/01.mp3" data-artist="Tim McMorris" data-title="Successful Business Venture" data-thumb="//websmirno.site/wp/music/media/audio/1/01.jpg" data-download="//websmirno.site/wp/music/media/audio/1/01.mp3"></li>
    <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/02.mp3" data-artist="Tim McMorris" data-title="Happy Days Are Here To Stay" data-thumb="//websmirno.site/wp/music/media/audio/1/02.jpg" data-download="//websmirno.site/wp/music/media/audio/1/02.mp3"></li>
    <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/03.mp3" data-artist="Tim McMorris" data-title="A Bright And Hopeful Future" data-thumb="//websmirno.site/wp/music/media/audio/1/03.jpg" data-download="//websmirno.site/wp/music/media/audio/1/03.mp3"></li>
    <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/04.mp3" data-artist="Tim McMorris" data-title="Give Our Dreams Their Wings To Fly" data-thumb="//websmirno.site/wp/music/media/audio/1/04.jpg" data-download="//websmirno.site/wp/music/media/audio/1/04.mp3"></li>
    <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/05.mp3" data-artist="Tim McMorris" data-title="Marketing Advertising Music" data-thumb="//websmirno.site/wp/music/media/audio/1/05.jpg" data-download="//websmirno.site/wp/music/media/audio/1/05.mp3"></li>
    <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/01.mp3" data-artist="Tim McMorris" data-title="Successful Business Venture" data-thumb="//websmirno.site/wp/music/media/audio/1/01.jpg" data-download="//websmirno.site/wp/music/media/audio/1/01.mp3"></li>
    <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/02.mp3" data-artist="Tim McMorris" data-title="Happy Days Are Here To Stay" data-thumb="//websmirno.site/wp/music/media/audio/1/02.jpg" data-download="//websmirno.site/wp/music/media/audio/1/02.mp3"></li>
    <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/03.mp3" data-artist="Tim McMorris" data-title="A Bright And Hopeful Future" data-thumb="//websmirno.site/wp/music/media/audio/1/03.jpg" data-download="//websmirno.site/wp/music/media/audio/1/03.mp3"></li>
    <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/04.mp3" data-artist="Tim McMorris" data-title="Give Our Dreams Their Wings To Fly" data-thumb="//websmirno.site/wp/music/media/audio/1/04.jpg" data-download="//websmirno.site/wp/music/media/audio/1/04.mp3"></li>
    <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/05.mp3" data-artist="Tim McMorris" data-title="Marketing Advertising Music" data-thumb="//websmirno.site/wp/music/media/audio/1/05.jpg" data-download="//websmirno.site/wp/music/media/audio/1/05.mp3"></li>
    <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/01.mp3" data-artist="Tim McMorris" data-title="Successful Business Venture" data-thumb="//websmirno.site/wp/music/media/audio/1/01.jpg" data-download="//websmirno.site/wp/music/media/audio/1/01.mp3"></li>
    <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/02.mp3" data-artist="Tim McMorris" data-title="Happy Days Are Here To Stay" data-thumb="//websmirno.site/wp/music/media/audio/1/02.jpg" data-download="//websmirno.site/wp/music/media/audio/1/02.mp3"></li>
    <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/03.mp3" data-artist="Tim McMorris" data-title="A Bright And Hopeful Future" data-thumb="//websmirno.site/wp/music/media/audio/1/03.jpg" data-download="//websmirno.site/wp/music/media/audio/1/03.mp3"></li>
    <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/04.mp3" data-artist="Tim McMorris" data-title="Give Our Dreams Their Wings To Fly" data-thumb="//websmirno.site/wp/music/media/audio/1/04.jpg" data-download="//websmirno.site/wp/music/media/audio/1/04.mp3"></li>
    <li class="awp-playlist-item" data-type="audio" data-mp3="//websmirno.site/wp/music/media/audio/1/05.mp3" data-artist="Tim McMorris" data-title="Marketing Advertising Music" data-thumb="//websmirno.site/wp/music/media/audio/1/05.jpg" data-download="//websmirno.site/wp/music/media/audio/1/05.mp3"></li>
</ul>
[/aw_player][/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block inset-105 ch-separator"][vc_column rsclass="clean"][vc_row_inner rsclass="clean"][vc_column_inner el_class="title-wrap text-center" rsclass="clean"][vc_custom_heading text="Featured Sounds" font_container="tag:h2|text_align:center" use_theme_fonts="yes"][vc_column_text rsclass="clean"]
<p class="p--lg"><strong class="ch">We offer the best recording studio rates for true world-class<br class="hidden-xs hidden-sm hidden-md" />music production you will find anywhere</strong></p>
[/vc_column_text][/vc_column_inner][/vc_row_inner][voicer_gallery_element type="image_tgrid_m" images="808,809,810,811,812,813,814,815,816,817,818,819,820,821,822" img_size="full" custom_titles="Track Title,Track Title,Track Title,Track Title,Track Title,Track Title,Track Title,Track Title,Track Title,Track Title,Track Title,Track Title,Track Title,Track Title,Track Title" track_urls="//websmirno.site/wp/music/media/audio/2/01.mp3,//websmirno.site/wp/music/media/audio/2/02.mp3,//websmirno.site/wp/music/media/audio/2/03.mp3,//websmirno.site/wp/music/media/audio/2/04.mp3,//websmirno.site/wp/music/media/audio/2/01.mp3,//websmirno.site/wp/music/media/audio/2/05.mp3,//websmirno.site/wp/music/media/audio/2/01.mp3,//websmirno.site/wp/music/media/audio/2/05.mp3,//websmirno.site/wp/music/media/audio/2/02.mp3,//websmirno.site/wp/music/media/audio/2/03.mp3,//websmirno.site/wp/music/media/audio/2/04.mp3,//websmirno.site/wp/music/media/audio/2/05.mp3,//websmirno.site/wp/music/media/audio/2/01.mp3,//websmirno.site/wp/music/media/audio/2/02.mp3,//websmirno.site/wp/music/media/audio/2/03.mp3" artists="Artist Name,Artist Name,Artist Name,Artist Name,Artist Name,Artist Name,Artist Name,Artist Name,Artist Name,Artist Name,Artist Name,Artist Name,Artist Name,Artist Name,Artist Name" custom_ttitles="All Sounds,Behind The Scenes,Media,Music Productions,Video Productions" image_bind="1,2,3,4,3,3,2,1,2,2,4,1,2,3,4" el_class="projects--grid block--full no-pad-gutter"]
<div class="text-center btn--wrapper"><a class="btn btn--border1" href="projects">[voicer_icon icon="icon-spectr"]more projects</a></div>
[/voicer_gallery_element][/vc_column][/vc_row]



<!--page Services-->
[vc_section el_class="block block--full no-pad-gutter inset-125 pb-0" rsclass="clean"][vc_row rsclass="clean" el_class="container"][vc_column rsclass="clean"][vc_row_inner rsclass="clean" el_class="title-wrap text-center"][vc_column_inner el_class="title-wrap text-center container" rsclass="clean"][vc_column_text rsclass="clean"]
<h2 class="heading"><span class="ch">What We Do Best</span></h2>
<p class="p--lg"><strong class="ch">Our reputation comes from the artists we work with<br class="hidden-xs hidden-sm hidden-md" />and the records made in our studios</strong></p>
[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner rsclass="clean" el_class="row gutter-15 services-grid"][vc_column_inner el_class="col-sm-4" width="1/4" rsclass="clean"][vc_hoverbox image="700" primary_title="recording" primary_align="left" shape="square" hover_background_color="custom" rsclass="clean" rsiclass="service-item-photo" el_class="service-item" rstclass="service-item-caption"]
<div class="text-right">
    <div class="service-item-title"><span class="h-gradient">Recording</span></div>
    <div class="service-item-description"><span class="tt">24 channels of simultaneous recording in</span><span class="tt">three isolation booths and a big room.</span></div>
</div>
<div class="service-item-price"><span class="price-symbol">$</span><b>35</b><br class="ch" />hour</div>
[/vc_hoverbox][vc_hoverbox image="695" primary_title="engineering" hover_title="" hover_align="left" shape="square" hover_background_color="custom" align="left" rsclass="clean" el_class="service-item" rsiclass="service-item-photo" rstclass="service-item-caption service-item-description-no"]
<div class="text-right">
    <div class="service-item-title"><span class="h-gradient">Engineering</span></div>
</div>
<div class="service-item-price"><span class="price-symbol">$</span><b>75</b><br class="ch" />hour</div>
[/vc_hoverbox][/vc_column_inner][vc_column_inner el_class="col-sm-4" width="1/4" rsclass="clean"][vc_hoverbox image="697" primary_title="mixing" primary_align="left" shape="square" hover_background_color="custom" rsclass="clean" rsiclass="service-item-photo" el_class="service-item" rstclass="service-item-caption"]
<div class="text-right">
    <div class="service-item-title"><span class="h-gradient">Mixing</span></div>
    <div class="service-item-description"><span class="tt">Specializing in mixing for music.</span><span class="tt">Stereo and 5.1 capabilities</span></div>
</div>
<div class="service-item-price"><span class="price-symbol">$</span><b>55</b><br class="ch" />hour</div>
[/vc_hoverbox][vc_hoverbox image="699" primary_title="production" primary_align="left" shape="square" hover_background_color="custom" rsclass="clean" rsiclass="service-item-photo" el_class="service-item" rstclass="service-item-caption"]
<div class="text-right">
    <div class="service-item-title"><span class="h-gradient">Production</span></div>
    <div class="service-item-description"><span class="tt">Songwriting, arranging, session</span><span class="tt">playing, producing</span></div>
</div>
<div class="service-item-price"><span class="price-symbol">$</span><b>95</b><br class="ch" />hour</div>
[/vc_hoverbox][/vc_column_inner][vc_column_inner el_class="col-sm-4" width="1/4" rsclass="clean"][vc_hoverbox image="696" primary_title="mastering" primary_align="left" shape="square" hover_background_color="custom" rsclass="clean" rsiclass="service-item-photo" el_class="service-item" rstclass="service-item-caption"]
<div class="text-right">
    <div class="service-item-title"><span class="h-gradient">Mastering</span></div>
    <div class="service-item-description"><span class="tt">We outsource all mastering services.</span><span class="tt">Ask us who we use</span></div>
</div>
<div class="service-item-price"><span class="price-symbol">$</span><b>55</b><br class="ch" />hour</div>
[/vc_hoverbox][vc_hoverbox image="698" primary_title="post production" primary_align="left" shape="square" hover_background_color="custom" rsclass="clean" rsiclass="service-item-photo" el_class="service-item" rstclass="service-item-caption service-item-description-no"]
<div class="text-right">
    <div class="service-item-title"><span class="h-gradient">Post Production</span></div>
</div>
<div class="service-item-price"><span class="price-symbol">$</span><b>35</b><br class="ch" />hour</div>
[/vc_hoverbox][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][/vc_section][vc_section el_class="block inset-110" rsclass="clean"][vc_row rsclass="clean" el_class="container"][vc_column rsclass="clean"][vc_row_inner rsclass="clean"][vc_column_inner el_class="title-wrap text-center" rsclass="clean"][vc_column_text rsclass="clean"]
<h2 class="heading"><span class="ch">Book Session</span></h2>
<p class="p--lg"><strong class="ch">To book a session: choose your desired session length,<br class="hidden-xs hidden-sm hidden-md" />click 'Book It', and select an available date and time from the calendar</strong></p>
[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner rsclass="clean"][vc_column_inner el_class="table-responsive" rsclass="clean"][vc_column_text rsclass="clean"]
<table id="tableFix" class="table table--services">
    <tbody>
    <tr>
        <td><b>1 Hour</b><span class="hidden-xs"> of studio time</span></td>
        <td class="text-center">1 hr <span class="separator">|</span><span class="price">$45.00</span></td>
        <td class="text-right"><a class="btn btn--no--border open-popup-link" href="#" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup">[voicer_icon icon="icon-mic"]book now</a></td>
    </tr>
    <tr>
        <td><b>2 Hour</b><span class="hidden-xs"> of studio time</span></td>
        <td class="text-center">2 hr <span class="separator">|</span><span class="price"> $90.00</span></td>
        <td class="text-right"><a class="btn btn--no--border open-popup-link" href="#" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup">[voicer_icon icon="icon-mic"]book now</a></td>
    </tr>
    <tr>
        <td><b>4 Hour</b><span class="hidden-xs"> of studio time</span></td>
        <td class="text-center">4 hr <span class="separator">|</span><span class="price"> $180.00</span></td>
        <td class="text-right"><a class="btn btn--no--border open-popup-link" href="#" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup">[voicer_icon icon="icon-mic"]book now</a></td>
    </tr>
    <tr>
        <td><b>6 Hour</b><span class="hidden-xs"> of studio time</span></td>
        <td class="text-center">6 hr <span class="separator">|</span><span class="price"> $270.00</span></td>
        <td class="text-right"><a class="btn btn--no--border open-popup-link" href="#" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup">[voicer_icon icon="icon-mic"]book now</a></td>
    </tr>
    <tr>
        <td><b>8 Hour</b><span class="hidden-xs"> of studio time</span></td>
        <td class="text-center">8 hr <span class="separator">|</span><span class="price"> $360.00</span></td>
        <td class="text-right"><a class="btn btn--no--border open-popup-link" href="#" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup">[voicer_icon icon="icon-mic"]book now</a></td>
    </tr>
    <tr>
        <td><b>10 Hour</b><span class="hidden-xs"> of studio time</span></td>
        <td class="text-center">10 hr <span class="separator">|</span><span class="price"> $450.00</span></td>
        <td class="text-right"><a class="btn btn--no--border open-popup-link" href="#" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup">[voicer_icon icon="icon-mic"]book now</a></td>
    </tr>
    </tbody>
</table>
[/vc_column_text][vc_column_text rsclass="clean"]
<div id="bookingPopup" class="form-popup mfp-with-anim">
    <div class="form-popup-inside mfp-inside">
        <div class="ch"><button class="close" aria-label="Close" data-dismiss="modal">[voicer_icon icon="icon-close"]</button></div>
        <h3 class="text-center">Book Your Session</h3>
        [contact-form-7 title="Book Your Session"]

    </div>
</div>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][/vc_section][vc_section rsclass="clean" el_class="block block--darkbg block--fullbg block--bgcover block-border-gradient block-bg-booking ch-separator"][vc_row rsclass="clean" el_class="container"][vc_column rsclass="clean" el_class="text-center title-wrap color-invert booking--block--phone"][vc_column_text rsclass="clean"]
<h2 class="heading">[voicer_icon icon="icon-booking-grad"] Booking</h2>
<p class="p--lg"><strong class="ch">Book your own session. If you have any questions, you give us a call or email us</strong></p>
[/vc_column_text][vc_row_inner rsclass="clean" el_class="phone-lg text-center"][vc_column_inner rsclass="clean"][vc_column_text rsclass="clean"]
<div class="tt">[voicer_icon icon="icon-phone"] 1-800-765-43-21</div>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][/vc_section][vc_section rsclass="clean" el_class="block inset-125 ch-separator block--we--can--also"][vc_row rsclass="clean" el_class="container"][vc_column rsclass="clean"][vc_row_inner rsclass="clean"][vc_column_inner el_class="title-wrap text-center" rsclass="clean"][vc_custom_heading text="We Can Also..." font_container="tag:h2|text_align:center" use_theme_fonts="yes" rsicon="icon-promotion-1"][/vc_column_inner][/vc_row_inner][vc_row_inner rsclass="clean" el_class="row block--icons--center"][vc_column_inner el_class="col-sm-6 col-md-4" width="1/3" rsclass="clean" rsinner="icn-txt-box-icon icn-txt-box--style2 all--centered blocks--number6"][vc_column_text rsclass="clean"]
<div class="icn-txt-box-icon icn-txt-box-icon-bg bg-01">[voicer_icon icon="icon-recording-grad"]</div>
<div class="icn-txt-box-text">
    <h4 class="ch"><strong class="ch">Recording</strong></h4>
    <p class="tt">We work with rock bands, jazz ensembles, string sections, brass sections, big bands, gospel choirs, and everything in between.</p>

</div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-md-4" width="1/3" rsclass="clean" rsinner="icn-txt-box icn-txt-box--style2 all--centered blocks--number6"][vc_column_text rsclass="clean"]
<div class="icn-txt-box-icon icn-txt-box-icon-bg bg-02">[voicer_icon icon="icon-production-grad"]</div>
<div class="icn-txt-box-text">
    <h4 class="ch"><strong class="ch">Production</strong></h4>
    <p class="tt">Our in-house production team, can provide a variety of services depending on your music projects needs.</p>

</div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-md-4" width="1/3" rsclass="clean" rsinner="icn-txt-box icn-txt-box--style2 all--centered blocks--number6"][vc_column_text rsclass="clean"]
<div class="icn-txt-box-icon icn-txt-box-icon-bg bg-03">[voicer_icon icon="icon-equalizer-grad"]</div>
<div class="icn-txt-box-text">
    <h4 class="ch"><strong class="ch">Editing</strong></h4>
    <p class="ch">We offer vocal tuning, drum alignment, and a variety of ways to help clean up and organize your recording sessions.</p>

</div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-md-4" width="1/3" rsclass="clean" rsinner="icn-txt-box-icon icn-txt-box--style2 all--centered blocks--number6"][vc_column_text rsclass="clean"]
<div class="icn-txt-box-icon icn-txt-box-icon-bg bg-01">[voicer_icon icon="icon-video-grad"]</div>
<div class="icn-txt-box-text">
    <h4 class="ch"><strong class="ch">Video Shoots</strong></h4>
    <p class="tt">Voicer Recording Studio classic studio look and feel makes it the perfect place for bands to shoot music videos.</p>

</div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-md-4" width="1/3" rsclass="clean" rsinner="icn-txt-box-icon icn-txt-box--style2 all--centered blocks--number6"][vc_column_text rsclass="clean"]
<div class="icn-txt-box-icon icn-txt-box-icon-bg bg-01">[voicer_icon icon="icon-voice-grad"]</div>
<div class="icn-txt-box-text">
    <h4 class="ch"><strong class="ch">Voice Over</strong></h4>
    <p class="tt">We have all of the high end microphones and outboard to give the proper presence your voice over needs.</p>

</div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-md-4" width="1/3" rsclass="clean" rsinner="icn-txt-box-icon icn-txt-box--style2 all--centered blocks--number6"][vc_column_text rsclass="clean"]
<div class="icn-txt-box-icon icn-txt-box-icon-bg bg-01">[voicer_icon icon="icon-sound-design-grad"]</div>
<div class="icn-txt-box-text">
    <h4 class="ch"><strong class="ch">Sound Design</strong></h4>
    <p class="tt">Whether it is post production for film or a music track that needs a bigger sound, we can help bring to life whatever it is you hear in your head.</p>

</div>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][/vc_section]





<!--page Testimonials - not all-->
[vc_section rsclass="clean" el_class="block block--full bottom-null no-pad inset-top-125"][vc_row rsclass="clean"][vc_column rsclass="clean" el_class="title-wrap text-center"][vc_column_text rsclass="clean"]
<h2 class="heading"><span class="ch">Our Latest Clients</span></h2>
[/vc_column_text][vc_column_text rsclass="clean"]
<p class="p--lg"><strong class="ch">Our reputation comes from the artists we work with and<br class="hidden-xs hidden-sm hidden-md" />the records made in our studios</strong></p>
[/vc_column_text][vc_row_inner rsclass="clean" el_class="row clients-slider ini-client-slider"][vc_column_inner el_class="col-sm-6 col-md-3 client-item" width="1/6" rsclass="clean"][vc_single_image image="749" img_size="full" onclick="custom_link" rsclass="clean" link="#" el_class="client-item-photo"][vc_column_text rsclass="clean"]
<div class="client-item-name"><span class="tt">Margaret Smith</span></div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-md-3 client-item" width="1/6" rsclass="clean"][vc_single_image image="750" img_size="full" onclick="custom_link" rsclass="clean" link="#" el_class="client-item-photo"][vc_column_text rsclass="clean"]
<div class="client-item-name"><span class="tt">Bonnie McKee</span></div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-md-3 client-item" width="1/6" rsclass="clean"][vc_single_image image="751" img_size="full" onclick="custom_link" rsclass="clean" link="#" el_class="client-item-photo"][vc_column_text rsclass="clean"]
<div class="client-item-name"><span class="tt">Leland Duncan</span></div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-md-3 client-item" width="1/6" rsclass="clean"][vc_single_image image="752" img_size="full" onclick="custom_link" rsclass="clean" link="#" el_class="client-item-photo"][vc_column_text rsclass="clean"]
<div class="client-item-name"><span class="tt">Over The Board</span></div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-md-3 client-item" width="1/6" rsclass="clean"][vc_single_image image="753" img_size="full" onclick="custom_link" rsclass="clean" link="#" el_class="client-item-photo"][vc_column_text rsclass="clean"]
<div class="client-item-name"><span class="tt">Robert M. Weiss</span></div>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block ch-separator"][vc_column rsclass="clean" el_class="title-wrap text-center" rsinner="container"][vc_column_text rsclass="clean"]
<h2 class="heading"><span class="ch">Our Latest Clients</span></h2>
[/vc_column_text][vc_column_text rsclass="clean"]
<p class="p--lg mb-0"><strong class="ch">Our twenty years of music experience in a variety of styles</strong></p>
[/vc_column_text][vc_column_text rsclass="clean"]
<div class="price-box-btn"><a class="btn btn--border1 open-popup-link" href="#" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup">[voicer_icon icon="icon-mic"]book session now</a></div>
[/vc_column_text][/vc_column][/vc_row][/vc_section][vc_row rsclass="clean" el_class="form-popup mfp-with-anim" el_id="bookingPopup"][vc_column rsclass="clean" el_class="form-popup-inside mfp-inside"][vc_column_text rsclass="clean"]
<div class="ch"><button class="close" aria-label="Close" data-dismiss="modal">[voicer_icon icon="icon-close"]</button></div>
[/vc_column_text][vc_custom_heading text="Book Your Session" font_container="tag:h3|text_align:center" use_theme_fonts="yes"][contact-form-7 id="371"][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block block--darkbg block-bg-we-worked ch-separator"][vc_column rsclass="clean" el_class="container"][vc_custom_heading text="We Worked With" font_container="tag:h2|text_align:center" use_theme_fonts="yes" el_class="color-white" rsouter="text-center title-wrap"][vc_column_text rsclass="clean"]
<ul class="simple-filter text-center">
    <li class="active" data-filter="*"><span class="ch">All Clients</span></li>
    <li data-filter=".category1"><span class="ch">Music</span></li>
    <li data-filter=".category2"><span class="ch">Post Production</span></li>
    <li data-filter=".category3"><span class="ch">Feature Films</span></li>
</ul>
<ul class="clients-list-column">
    <li class="category1">Michael L. Earle</li>
    <li class="category2">Michael V. Vazquez</li>
    <li class="category3">Matthew J. Duncan</li>
    <li class="category1">Rickey T. Campbell</li>
    <li class="category2">Jonathan J. Ku</li>
    <li class="category3">Theresa R. Ochoa</li>
    <li class="category1">Ivan P. Salinas</li>
    <li class="category2">Jesse Brazier</li>
    <li class="category3">Jamie Wallace</li>
    <li class="category1">Ryan McNulty</li>
    <li class="category3">Jesse Brazier</li>
    <li class="category1">Jamie Wallace</li>
    <li class="category2">Ryan McNulty</li>
    <li class="category3">Marcus Smith</li>
    <li class="category1">James Miller</li>
    <li class="category2">Carrie Ryan</li>
    <li class="category3">JUSTIN MARKET</li>
    <li class="category1">Ty Da Snake</li>
    <li class="category2">Car Park Records</li>
    <li class="category3">Ricky’s Heart</li>
    <li class="category2">Tribe of Shamans</li>
    <li class="category3">Wasted Blood</li>
    <li class="category1">Cringe</li>
    <li class="category2">Vibe &amp; Direct</li>
    <li class="category3">Blacklister</li>
    <li class="category1">Beverly K. Pleasants</li>
    <li class="category2">Louis A. Shay</li>
    <li class="category3">Stephen D. Rivers</li>
    <li class="category1">Alan J. Doody</li>
    <li class="category2">Betty F. Cochran</li>
    <li class="category1">Lois D. Olson</li>
    <li class="category2">Ann R. Houston</li>
    <li class="category3">Natasha D. Ward</li>
    <li class="category1">Daniel L. Mitchell</li>
    <li class="category2">Ulysses J. McCall</li>
    <li class="category3">Signals Midwest</li>
    <li class="category1">Modern Baseball</li>
    <li class="category2">Senator Nina Turner</li>
    <li class="category3">Saintseneca</li>
    <li class="category1">Meridian</li>
</ul>
[/vc_column_text][vc_column_text rsclass="clean" el_class="text-center"]
<ul class="pagination">
    <li class="active"><a href="#">1</a></li>
    <li><a href="#">2</a></li>
    <li><a href="#">3</a></li>
    <li><a href="#">4</a></li>
</ul>
[/vc_column_text][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block ch-separator"][vc_column rsclass="clean" el_class="container"][vc_custom_heading text="What the Reviews Say" font_container="tag:h2|text_align:center" use_theme_fonts="yes" rsicon="icon-interface" rsouter="title-wrap text-center"][vc_row_inner rsclass="clean" el_class="row"][vc_column_inner el_class="col-sm-6" width="1/2" rsclass="clean"][vc_column_text rsclass="clean" el_class="testimonial testimonial--dark"]
<p class="tt">My band and I had a great time recording at Voicer. The staff were very friendly, personable and accommodating to all our requirements. The studio is quite spacious and well kitted out. Even better, it is used by experienced professionals who help to get the best out of you.</p>

<div class="review-item-rating"><span class="txt-gradient">[voicer_icon icon="icon-star"]</span></div>
[/vc_column_text][vc_hoverbox image="771" shape="square" rsclass="clean" el_class="testimonial-author" rsiclass="testimonial-author-photo"]
<div class="testimonial-author-name">Laura T. Harrington</div>
<div class="testimonial-author-position">Singer / Songwriter</div>
[/vc_hoverbox][vc_column_text rsclass="clean" el_class="testimonial"]
<p class="tt">I wanted to drop you a brief but sincere couple of lines of thanks for all the hard work you put into making the music &amp; sound behind Economy Gastronomy such a success. Despite having a new brief thrown at you seemingly every other week you<br class="ch" />behaved always with courtesy and professionalism. And you really nailed it.</p>

<div class="review-item-rating"><span class="txt-gradient">[voicer_icon icon="icon-star"]</span></div>
[/vc_column_text][vc_hoverbox image="773" shape="square" rsclass="clean" el_class="testimonial-author" rsiclass="testimonial-author-photo"]
<div class="testimonial-author-name">Allen R. McKelvey</div>
<div class="testimonial-author-position">Singer / Songwriter</div>
[/vc_hoverbox][vc_column_text rsclass="clean" el_class="testimonial testimonial--dark"]
<p class="tt">I love Voicer Recording Studio! Great state-of-the-art studio full of talented, supportive people. Excellent location at a good price. I was very happy with everything... I've already recommended it.</p>

<div class="review-item-rating"><span class="txt-gradient">[voicer_icon icon="icon-star"]</span></div>
[/vc_column_text][vc_hoverbox image="771" shape="square" rsclass="clean" el_class="testimonial-author" rsiclass="testimonial-author-photo"]
<div class="testimonial-author-name">Frances E. Hayes</div>
<div class="testimonial-author-position">Composer, Orchestrator</div>
[/vc_hoverbox][/vc_column_inner][vc_column_inner el_class="col-sm-6" width="1/2" rsclass="clean"][vc_column_text rsclass="clean" el_class="testimonial"]
<p class="tt">My first initial session to record a demo for my publisher was meant to be a one-off. I was so impressed with the standard and level of service that I went back to record songs some of which are on my soon to be released new album "Bring back the love". Apart from being a seasoned professional, is also a perfectionist and as such he ensures that he always gives 100% during the creative process. The end product/result is always of a high standard and quality. I highly recommend Voicer Records studios as it's value for money. You WILL NOT be disappointed!</p>

<div class="review-item-rating"><span class="txt-gradient">[voicer_icon icon="icon-star"]</span></div>
[/vc_column_text][vc_hoverbox image="772" shape="square" rsclass="clean" el_class="testimonial-author" rsiclass="testimonial-author-photo"]
<div class="testimonial-author-name">Scotty L. Salazar</div>
<div class="testimonial-author-position">Composer</div>
[/vc_hoverbox][vc_column_text rsclass="clean" el_class="testimonial testimonial--dark"]
<p class="tt">Thanks a lot for all your help, we would 100% use your expertise again in future projects. It was the first time we used a recording studio for a project and now I cant imagine doing it any other way.</p>

<div class="review-item-rating"><span class="txt-gradient">[voicer_icon icon="icon-star"]</span></div>
[/vc_column_text][vc_hoverbox image="771" shape="square" rsclass="clean" el_class="testimonial-author" rsiclass="testimonial-author-photo"]
<div class="testimonial-author-name">Elaine T. Stark</div>
<div class="testimonial-author-position">Series Producer</div>
[/vc_hoverbox][vc_column_text rsclass="clean" el_class="testimonial"]
<p class="tt">I just wanted to say a big thank you for our session the other day, both Vas and I really enjoyed ourselves and you were all so welcoming that it was so easy for Vas to overcome her nerves. It was a pleasure meeting you all and we'll be sure to come back.</p>

<div class="review-item-rating"><span class="txt-gradient">[voicer_icon icon="icon-star"]</span></div>
[/vc_column_text][vc_hoverbox image="774" shape="square" rsclass="clean" el_class="testimonial-author" rsiclass="testimonial-author-photo"]
<div class="testimonial-author-name">Joseph M. McAdams</div>
<div class="testimonial-author-position">Creative Director</div>
[/vc_hoverbox][/vc_column_inner][/vc_row_inner][vc_column_text rsclass="clean"]
<div class="text-center"><a class="btn btn--border1" href="#">[voicer_icon icon="icon-testimonials"]more testimonials</a></div>
[/vc_column_text][/vc_column][/vc_row]










<!--page Rates-->
[vc_row rsclass="clean" el_class="block inset-125 pb-0"][vc_column rsclass="clean" el_class="container"][vc_row_inner rsclass="clean"][vc_column_inner el_class="title-wrap text-center" rsclass="clean"][vc_column_text rsclass="clean"]
<h2 class="heading"><span class="ch">Our Prices Plans</span></h2>
[/vc_column_text][vc_column_text rsclass="clean"]
<p class="p--lg"><strong class="ch">We offer the best recording studio rates for true world-class<br class="hidden-xs hidden-sm hidden-md" />music production you will find anywhere</strong></p>
[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner rsclass="clean" el_class="row"][vc_column_inner el_class="col-sm-4" width="1/3" rsclass="clean" rsinner="price-box price-box-price-bg01"][vc_column_text rsclass="clean"][voicer_icon icon="icon-recording-rates" class="price-box-icon"]
<div class="price-box-price"><span class="price-symbol">$</span><b class="tt">75</b> <span class="tt">/ hour</span></div>
<div class="price-box-title"><span class="tt">Studio B</span> – Tracking</div>
<ul class="price-box-list">
    <li>Large Mic +</li>
    <li>3 Isolation Booths / Big Room</li>
    <li>Pro Tools HD3</li>
    <li>Tape Machine</li>
</ul>
<div class="price-box-btn"><a class="btn btn--border1 open-popup-link" href="#" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup">[voicer_icon icon="icon-mic"]book session</a></div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4" width="1/3" rsclass="clean" rsinner="price-box price-box--special price-box-price-bg02"][vc_column_text rsclass="clean"][voicer_icon icon="icon-equalizer-trans" class="price-box-icon"]
<div class="price-box-price"><span class="price-symbol">$</span><b class="tt">95</b> <span class="tt">/ hour</span></div>
<div class="price-box-title"><span class="tt">Studio A</span> – Mixing</div>
<ul class="price-box-list">
    <li>Genelec 8050's</li>
    <li>Waves Platinum Bundle</li>
    <li>Kontact</li>
    <li>Neve Summing</li>
    <li>SSL EQ</li>
</ul>
<div class="price-box-btn"><a class="btn btn--border1 btn--border--dark open-popup-link" href="#" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup">[voicer_icon icon="icon-mic"]book session</a></div>
[/vc_column_text][vc_column_text rsclass="clean"]
<div id="bookingPopup" class="form-popup mfp-with-anim">
    <div class="form-popup-inside mfp-inside">
        <h3>Book Your Session</h3>
        <div class="ch"><button class="close" aria-label="Close" data-dismiss="modal">[voicer_icon icon="icon-close"]</button></div>
        [contact-form-7 id="179" title="Book Your Session"]

    </div>
</div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4" width="1/3" rsclass="clean" rsinner="price-box price-box-price-bg01"][vc_column_text rsclass="clean"][voicer_icon icon="icon-headphones" class="price-box-icon"]
<div class="price-box-price"><span class="price-symbol">$</span><b class="tt">45</b> <span class="tt">/ hour</span></div>
<div class="price-box-title"><span class="tt">Studio C</span> – Mastering</div>
<ul class="price-box-list">
    <li>Pro Tools</li>
    <li>Logic</li>
    <li>Yamaha 801s</li>
    <li>Overdub Suite</li>
</ul>
<div class="price-box-btn"><a class="btn btn--border1 open-popup-link" href="#" data-effect="mfp-zoom-in" data-mfp-src="#bookingPopup">[voicer_icon icon="icon-mic"]book session</a></div>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block ch-separator inset-120"][vc_column rsclass="clean" el_class="container"][vc_row_inner rsclass="clean"][vc_column_inner el_class="title-wrap text-center" rsclass="clean"][vc_custom_heading text="Why Mix In Voicer?" font_container="tag:h2|text_align:center" use_theme_fonts="yes"][vc_column_text rsclass="clean"]
<p class="p--lg"><strong class="ch">We take pride in our hard work and dedication to give all projects the<br class="hidden-xs hidden-sm hidden-md" />high-quality treatment of a professional studio</strong></p>
[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner rsclass="clean" el_class="row"][vc_column_inner el_class="col-sm-6 col-md-4" width="1/3" rsclass="clean" rsinner="icn-txt-box-icon icn-txt-box--style2 all--centered"][vc_column_text rsclass="clean"]
<div class="icn-txt-box-icon icn-txt-box-icon-bg bg-01">[voicer_icon icon="icon-sound-grad"]</div>
<div class="icn-txt-box-text">
    <h4 class="ch"><strong class="ch">Sound</strong></h4>
    <p class="tt">Because here you will find always a valuable contribution in the selection of the sound of your project</p>

</div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-md-4" width="1/3" rsclass="clean" rsinner="icn-txt-box icn-txt-box--style2 all--centered"][vc_column_text rsclass="clean"]
<div class="icn-txt-box-icon icn-txt-box-icon-bg bg-02">[voicer_icon icon="icon-ideas-grad"]</div>
<div class="icn-txt-box-text">
    <h4 class="ch"><strong class="ch">Ideas</strong></h4>
    <p class="tt">Because there is an opinion on your work and solutions to make it more competitive in the industry</p>

</div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-6 col-md-4" width="1/3" rsclass="clean" rsinner="icn-txt-box icn-txt-box--style2 all--centered"][vc_column_text rsclass="clean"]
<div class="icn-txt-box-icon icn-txt-box-icon-bg bg-03">[voicer_icon icon="icon-reference-grad"]</div>
<div class="icn-txt-box-text">
    <h4 class="ch"><strong class="ch">Reference</strong></h4>
    <p class="ch">Because there is a reference which then not be able to do without it</p>

</div>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]


<!---page Gallery-->
[vc_row rsclass="clean" el_class="block ch-separator"][vc_column rsclass="clean"][voicer_gallery_element type="image_tgrid" images="910,911,912,913,914,915,916,917,918,919,920,921,922,923,924" img_size="full" onclick="custom_link" custom_links_target="_blank" custom_titles="#SkinnyListerRecording,#SkinnyListerRecording,#SkinnyListerRecording,#SkinnyListerRecording,#SkinnyListerRecording,#SkinnyListerRecording,#SkinnyListerRecording,#SkinnyListerRecording,#SkinnyListerRecording,#SkinnyListerRecording,#SkinnyListerRecording,#SkinnyListerRecording" custom_ttitles="All Gallery,#BehindTheScenes,#Media,#MusicProductions,#VideoProductions" image_bind="1,2,3,4,3,3,2,1,2,2,4,1" custom_links="#E-8_aHR0cHMlM0ElMkYlMkZ3d3cuaW5zdGFncmFtLmNvbSUyRiUyQ2h0dHBzJTNBJTJGJTJGd3d3Lmluc3RhZ3JhbS5jb20lMkYlMkNodHRwcyUzQSUyRiUyRnd3dy5pbnN0YWdyYW0uY29tJTJGJTJDaHR0cHMlM0ElMkYlMkZ3d3cuaW5zdGFncmFtLmNvbSUyRiUyQ2h0dHBzJTNBJTJGJTJGd3d3Lmluc3RhZ3JhbS5jb20lMkYlMkNodHRwcyUzQSUyRiUyRnd3dy5pbnN0YWdyYW0uY29tJTJGJTJDaHR0cHMlM0ElMkYlMkZ3d3cuaW5zdGFncmFtLmNvbSUyRiUyQ2h0dHBzJTNBJTJGJTJGd3d3Lmluc3RhZ3JhbS5jb20lMkYlMkNodHRwcyUzQSUyRiUyRnd3dy5pbnN0YWdyYW0uY29tJTJGJTJDaHR0cHMlM0ElMkYlMkZ3d3cuaW5zdGFncmFtLmNvbSUyRiUyQ2h0dHBzJTNBJTJGJTJGd3d3Lmluc3RhZ3JhbS5jb20lMkYlMkNodHRwcyUzQSUyRiUyRnd3dy5pbnN0YWdyYW0uY29tJTJG" el_class="block block--full no-pad-gutter pt-0 pb-0"]
<div class="text-center btn--wrapper pb-0"><a class="btn btn--border1" href="projects">[voicer_icon icon="icon-spectr"]view more photos</a></div>
[/voicer_gallery_element][/vc_column][/vc_row]


<!--page Contact us-->
<p>[vc_row rsclass="clean" el_class="block block--full p-0"][vc_column rsclass="clean"][vc_gmaps link="#E-8_JTNDaWZyYW1lJTIwc3JjJTNEJTIyaHR0cHMlM0ElMkYlMkZ3d3cuZ29vZ2xlLmNvbSUyRm1hcHMlMkZlbWJlZCUzRnBiJTNEJTIxMW0xOCUyMTFtMTIlMjExbTMlMjExZDQ5MzguMDcwNDAxNTY2MjIlMjEyZC0yLjM2OTMzMTkyMDk3MDY1NiUyMTNkNTEuNzY4OTYzNjU4MDkzMTU2JTIxMm0zJTIxMWYwJTIxMmYwJTIxM2YwJTIxM20yJTIxMWkxMDI0JTIxMmk3NjglMjE0ZjEzLjElMjEzbTMlMjExbTIlMjExczB4NDg3MWE3MTllNDI2ZmE5NyUyNTNBMHhlNWJhMmViODc1MjcyNmQ2JTIxMnNUaGUlMkJHcmVlbiUyNTJDJTJCRnJhbXB0b24lMkJvbiUyQlNldmVybiUyNTJDJTJCR2xvdWNlc3RlciUyNTJDJTJCVUslMjE1ZTAlMjEzbTIlMjExc2VuJTIxMnN1YSUyMTR2MTU2MDM1MDQzMzA4OCUyMTVtMiUyMTFzZW4lMjEyc3VhJTIyJTIwd2lkdGglM0QlMjI2MDAlMjIlMjBoZWlnaHQlM0QlMjI0NTAlMjIlMjBmcmFtZWJvcmRlciUzRCUyMjAlMjIlMjBzdHlsZSUzRCUyMmJvcmRlciUzQTAlMjIlMjBhbGxvd2Z1bGxzY3JlZW4lM0UlM0MlMkZpZnJhbWUlM0U=" el_class="contact-map"][/vc_column][/vc_row][vc_row el_class="block block--darkbg block-bg-contacts-touch block--fullbg block--bgcover inset-100 block--touch" css=".vc_custom_1560349952883{background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}" rsclass="clean"][vc_column rsclass="clean" el_class="container"][vc_custom_heading text="Get in Touch with Us" font_container="tag:h2|text_align:center" use_theme_fonts="yes" el_class="block--subtitle"][vc_row_inner rsclass="clean" el_class="row block-contact-info"][vc_column_inner el_class="col-sm-4 footer-info" width="1/3" rsclass="clean"][vc_column_text rsclass="clean"][voicer_icon icon="icon-place"]<strong>Voicer Studio Recording</strong>1035 N Sycamore<br />
    Avenue Hollywood, CA 90040[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4 footer-info" width="1/3" rsclass="clean"][vc_column_text rsclass="clean"][voicer_icon icon="icon-phone"]<strong>Contact Phones</strong>1 (800) 765-43-21, 765-43-21<br />
    1 (800) 765-43-23 (fax)[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-sm-4 footer-info" width="1/3" rsclass="clean"][vc_column_text rsclass="clean"][voicer_icon icon="icon-time"]<strong>Working Hours</strong>Mon-Fri: 9:00 am - 5:00 pm<br />
    Sat-Sun: 11:00 am - 16:00 pm[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="block inset-125 block-contact-info-form"][vc_column rsclass="clean" el_class="container"][vc_row_inner rsclass="clean" el_class="row"][vc_column_inner el_class="col-sm-6 block-contact-info-left" width="1/2" rsclass="clean"][vc_custom_heading text="Did You Know?" font_container="tag:h3|text_align:left" use_theme_fonts="yes" el_class="title"][vc_column_text rsclass="clean" el_class="block-contact-info small-info pt-0"]</p>
<ul class="circle-list norm">
    <li>We offer a voiceover coaching and demo-production service. Please contact <a class="theme-color" href="mailto:#info@voicerrecordingstudio.com">info@voicerrecordingstudio.com</a> for more information.</li>
    <li>You can listen in on, and contribute to, a Voicer recording session via Skype. Please add the Skype name "voicer" (without the quotation marks) to your contacts list.</li>
    <li>You can visit the studio to have a chat, discuss your upcoming project, or to direct your session. Please email us at <a class="theme-color" href="mailto:#info@voicerrecordingstudio.com">info@voicerrecordingstudio.com</a> to make arrangements.</li>
</ul>
<p>[/vc_column_text][vc_custom_heading text="Newsletter" font_container="tag:h3|text_align:left" use_theme_fonts="yes" el_class="title"][vc_custom_heading text="Keep up to date with what's happening at Voicer." font_container="tag:p|text_align:left" use_theme_fonts="yes"][contact-form-7 id="647"][/vc_column_inner][vc_column_inner el_class="divider visible-xs" rsclass="clean"][/vc_column_inner][vc_column_inner el_class="col-sm-6" width="1/2" rsclass="clean"][vc_custom_heading text="Contact Form" font_container="tag:h3|text_align:left" use_theme_fonts="yes"][contact-form-7 id="27" title="Contact form 1"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]</p>


<!--product page short description-->
<ul class="circle-list">
    <li>Eighteen track faders and one master fader allows instant access to any track without selecting pages or banks of faders.</li>
    <li>3.5" LCD screen and select, self-illuminated buttons - make it easy to keep an eye on your entire creative process.</li>
    <li>Built-in multi effects processor and mastering tools make it easy to go from demo to finished product.</li>
</ul>

<!--product page description-->
Superb sound technology for hi-fi music. The forone Bluetooth earbuds adopt V4.1+EDR APT-X audio decode tech, that you'll be able to distinguish between each individual beat, enjoy cd-like sound quality, the noise reduction technology ensures that you can enjoy your 'me' time without any interference from the outer world. Enjoy an impeccably comfortable, secure fit. The forone Bluetooth headset were expressly engineered to stay put during physical activity. Thanks to flexible stabilizing ear hooks, they'll not only stay firmly anchored to your ears, but also maintain a fit that's comfortable to all. The uniquely designed ear hooks mold to your ears, so you don't have to readjust them endlessly. That'll leave you free to enjoy a limitless number of outdoor and physical activities in any season. Super easy to use.