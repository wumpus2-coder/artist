(function($) {
    "use strict";

    var themeBlocks = {
        mainSlider: $("#" + rsObject['el_id'])
    };

    function mainSlider() {
        if (themeBlocks.mainSlider.length) {

            $("header.header").addClass("header--transparent");

            var $el = themeBlocks.mainSlider;
            $el.find('.slide').first().imagesLoaded({
                background: true
            }, function () {
                $('.mainSliderWrapper .loader-wrapper').addClass('disable');
            });
            $el.on('init', function (e, slick) {
                var $firstAnimatingElements = $('div.slide:first-child').find('[data-animation]');
                doAnimations($firstAnimatingElements);
            });
            $el.on('beforeChange', function (e, slick, currentSlide, nextSlide) {
                var $currentSlide = $('div.slide[data-slick-index="' + nextSlide + '"]');
                var $animatingElements = $currentSlide.find('[data-animation]');
                doAnimations($animatingElements);
            });
            $el.slick({
                arrows:rsObject['arrows'] == 'true' ? true : false,
                dots:rsObject['dots'] == 'true' ? true : false,
                autoplay:rsObject['autoplay'] == 'true' ? true : false,
                autoplaySpeed:rsObject['autoplayspeed'],
                fade:rsObject['fade'] == 'true' ? true : false,
                speed:rsObject['speed'],
                pauseOnHover: false,
                pauseOnDotsHover: true,
                responsive: [{
                    breakpoint: 1399,
                    settings: {
                        arrows: false
                    }
                }, {
                    breakpoint: 1025,
                    settings: {
                        dots: false,
                        arrows: false
                    }
                }]
            });
        }
    }

    function doAnimations(elements) {
        var animationEndEvents = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
        elements.each(function () {
            var $this = $(this);
            var $animationDelay = $this.data('animation-delay');
            var $animationType = 'animated ' + $this.data('animation');
            $this.css({
                'animation-delay': $animationDelay,
                '-webkit-animation-delay': $animationDelay
            });
            $this.addClass($animationType).one(animationEndEvents, function () {
                $this.removeClass($animationType);
            });
            if ($this.hasClass('animate')) {
                $this.removeClass('animation');
            }
        });
    }


    mainSlider();

})(jQuery);